import asyncio, pygame, sys, json, random
from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime
from collections import deque
from basic_bot import BasicBot

pygame.init()

VERSION="0.22.0-BASICBOT-V1.10"

MAX_GRID=13
FPS=60; MAX_GROUP=4
DOUBLE_TAP_MS=320                   # two taps on the same tile within this = "right click"

BG=(28,30,32); GRID_C=(74,77,80); TEXT=(235,235,235); MUTED=(165,165,165)
BASE_NEUTRAL=(90,90,90); HARVEST_ON=(214,188,76); HARVEST_OFF=(80,75,55)
SELECT=(245,245,245); SLOT_BG=(48,51,55)
FACTION_NAMES=["FBI","RUSSIAN MAFIA","ITALIAN MAFIA","CIA"]
PLAYER_COLORS=[
    (78,145,220),   # FBI — blue
    (220,150,55),   # Russian Mafia — amber / yellow-orange
    (205,80,155),   # Italian Mafia — magenta
    (80,190,120),   # CIA — green
]

def faction_name(p):
    if p is None:
        return "NEUTRAL"
    return FACTION_NAMES[p]
HARVEST_ORDER=("forest","oil","factory","fish")  # top, right, bottom, left


pygame.display.set_caption(f"GDG Mini v{VERSION}")
clock=pygame.time.Clock()

def load_font(size,bold=False,prefer_consolas=False):
    # A bundled font keeps text identical on desktop and in the browser
    # (system fonts like Consolas do not exist on phones / in the web build).
    if prefer_consolas:
        try:
            path=pygame.font.match_font("consolas",bold=bold)
            if path: return pygame.font.Font(path,size)
        except Exception:
            pass
        size=max(8,round(size*0.92))   # DejaVu is a little wider than Consolas
    name="DejaVuSansMono-Bold.ttf" if bold else "DejaVuSansMono.ttf"
    candidates=[]
    try: candidates.append(Path(__file__).with_name(name))
    except Exception: pass
    candidates.append(Path(name))
    for p in candidates:
        try:
            if p.exists(): return pygame.font.Font(str(p),size)
        except Exception:
            pass
    try: return pygame.font.SysFont("consolas,dejavusansmono,couriernew",size,bold=bold)
    except Exception: return pygame.font.Font(None,int(size*1.25))

# ---------- layouts ----------
# "pc"    = the classic v0.9 look (square-ish window, one sidebar column)
# "phone" = wide landscape layout (board left, two sidebar columns)
# Everything that depends on the layout is (re)set by set_layout().
LAYOUT_MODE=None
CELL=MARGIN=TOP=BOARD_W=WIDTH=HEIGHT=WRAP=SLOT=0
PS=1.0     # piece scale (bigger cells -> bigger pieces)
def ps(n): return max(1,round(n*PS))
L={}
screen=None
font=font_small=font_big=font_move=None

def set_layout(mode):
    global LAYOUT_MODE,CELL,MARGIN,TOP,BOARD_W,WIDTH,HEIGHT,WRAP,SLOT,L,screen,PS
    global font,font_small,font_big,font_move
    LAYOUT_MODE=mode
    PS=1.0
    if mode=="pc":
        CELL=62; MARGIN=26; TOP=70
        BOARD_W=MAX_GRID*CELL
        WIDTH=MARGIN*2+BOARD_W+430; HEIGHT=TOP+BOARD_W+MARGIN+130
        WRAP=38; SLOT=54
        font=load_font(18,False,True); font_small=load_font(14,False,True)
        font_big=load_font(28,True,True); font_move=load_font(34,True,True)
        px=MARGIN+BOARD_W+24; right=WIDTH-MARGIN
        L=dict(
            title=(MARGIN,24,"big"), player=(px,TOP), turn_right=(right,TOP), status_x=px,
            y_move_label=TOP+42, y_move_num=TOP+60,
            y_visible=TOP+112, y_harvest=TOP+140, y_bases=TOP+168, y_config=None,
            legend=[], y_taken=TOP+202,
            y_reserve_label=TOP+300, y_reserve_icons=TOP+324, harvest_dx=132, harvest_step=34,
            msg=(px,TOP+430), msg_line_h=18,
            container=(px,HEIGHT-285),
            end=pygame.Rect(px,HEIGHT-58,285,42), end_label="END TURN [ENTER]",
            restart=pygame.Rect(px,HEIGHT-58-52,150,40),
            result=(px,HEIGHT-245),
            setup=dict(title=(MARGIN,28), sub=(MARGIN,66), x0=95, y0=118, row=62, bh=40,
                       cx0=330, wmin=74, wpad=18, wchar=11, step=(365,42,64,7), summary=12,
                       start=pygame.Rect(WIDTH//2-120,HEIGHT-82,240,50)),
        )
    elif mode=="tablet":
        # Squarer screens (iPad, 4:3): big board, ONE narrow column, minimal text.
        CELL=57; MARGIN=14; TOP=14; PS=CELL/44
        BOARD_W=MAX_GRID*CELL
        WIDTH=1024; HEIGHT=MARGIN*2+BOARD_W
        WRAP=25; SLOT=58
        font=load_font(19); font_small=load_font(15)
        font_big=load_font(28,True); font_move=load_font(44,True)
        sx=MARGIN*2+BOARD_W+10; side_r=WIDTH-MARGIN
        L=dict(
            title=(sx,TOP+28,"small"), player=(sx,TOP), turn_right=(side_r,TOP), status_x=sx,
            y_move_label=TOP+58, y_move_num=TOP+76,
            y_visible=TOP+136, y_harvest=TOP+166, y_bases=TOP+196, y_config=None,
            legend=[], y_taken=TOP+290,
            y_reserve_label=TOP+234, y_reserve_icons=TOP+256, harvest_dx=100, harvest_step=30,
            msg=(sx,TOP+390), msg_line_h=20,
            container=(sx,TOP+500),
            end=pygame.Rect(sx,HEIGHT-MARGIN-56,side_r-sx,56), end_label="END TURN",
            restart=pygame.Rect(sx,HEIGHT-MARGIN-56-6-44,side_r-sx,44),
            result=(sx,TOP+576),
            setup=dict(title=(MARGIN+10,MARGIN), sub=(MARGIN+10,MARGIN+38), x0=150, y0=100, row=58, bh=46,
                       cx0=440, wmin=84, wpad=24, wchar=10, step=(440,52,72,6), summary=8,
                       start=pygame.Rect(WIDTH//2-130,HEIGHT-84,260,58)),
        )
    else:
        CELL=44; MARGIN=14; TOP=14
        BOARD_W=MAX_GRID*CELL
        WIDTH=1280
        # The playtest setup now has additional experimental rule rows.
        # Keep the board size unchanged but give the PC window enough vertical
        # room so steppers, summary and START button never overlap.
        HEIGHT=max(MARGIN*2+BOARD_W,760)
        WRAP=32; SLOT=58
        font=load_font(20); font_small=load_font(16)
        font_big=load_font(30,True); font_move=load_font(44,True)
        side_x=MARGIN*2+BOARD_W+10; side_r=WIDTH-MARGIN
        col_w=(side_r-side_x-20)//2
        col_a=side_x; col_b=side_r-col_w
        ya=TOP+40
        L=dict(
            title=(col_b,TOP+3,"small"), player=(col_a,TOP), turn_right=(side_r,TOP), status_x=col_a,
            y_move_label=ya, y_move_num=ya+18,
            y_visible=ya+78, y_harvest=ya+104, y_bases=ya+130, y_config=None,
            legend=[], y_taken=ya+168,
            y_reserve_label=ya+232, y_reserve_icons=ya+254, harvest_dx=132, harvest_step=34,
            msg=(col_b,ya), msg_line_h=20,
            container=(col_b,TOP+160),
            end=pygame.Rect(col_b,HEIGHT-MARGIN-56,col_w,56), end_label="END TURN",
            restart=pygame.Rect(col_a,HEIGHT-MARGIN-44,150,44),
            result=(col_a,HEIGHT-MARGIN-44-52),
            setup=dict(title=(MARGIN+10,MARGIN), sub=(MARGIN+10,MARGIN+38), x0=270, y0=82, row=48, bh=38,
                       cx0=560, wmin=84, wpad=24, wchar=10, step=(560,46,72,6), summary=6,
                       start=pygame.Rect(WIDTH//2-130,HEIGHT-72,260,52)),
        )
    # The window/canvas is always exactly the logical size. In the browser the
    # page fits it to the phone screen with CSS (see fit_web_canvas), which also
    # survives rotating the phone.
    screen=pygame.display.set_mode((WIDTH,HEIGHT))

# Browser only: make the canvas fit the screen (portrait or landscape) with the
# right proportions, stop double-tap zoom / scrolling, and keep it centered.
WEB_FIT_JS = """(function(){
if(document.getElementById('gdg-fit-style')) return;
var css = 'html,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;background:#1c1e20 !important;touch-action:none;overscroll-behavior:none;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;}'
 + 'canvas#canvas,canvas.emscripten{position:absolute !important;left:0 !important;right:0 !important;top:0 !important;bottom:0 !important;margin:auto !important;'
 + 'width:auto !important;height:auto !important;max-width:100vw !important;max-height:100vh !important;max-width:100dvw !important;max-height:100dvh !important;'
 + 'touch-action:none !important;background:#1c1e20 !important;}';
var st=document.createElement('style'); st.id='gdg-fit-style'; st.textContent=css; document.head.appendChild(st);
var m=document.querySelector('meta[name=viewport]');
if(m) m.setAttribute('content','width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no');
document.addEventListener('contextmenu',function(e){e.preventDefault();});
})();"""

def fit_web_canvas():
    if sys.platform!="emscripten": return
    try:
        import platform
        platform.window.eval(WEB_FIT_JS)
    except Exception as e:
        print("fit_web_canvas failed:",repr(e))

FULLSCREEN_JS = """(function(){
var d=document,e=d.documentElement;
var inFs=d.fullscreenElement||d.webkitFullscreenElement;
if(inFs){ var x=d.exitFullscreen||d.webkitExitFullscreen; if(x) x.call(d); return; }
var f=e.requestFullscreen||e.webkitRequestFullscreen;
if(!f) return;
var p=f.call(e);
var lock=function(){ try{ var o=screen.orientation; if(o&&o.lock){ var q=o.lock('landscape'); if(q&&q.catch) q.catch(function(){}); } }catch(x){} };
if(p&&p.then){ p.then(lock).catch(function(){}); } else { lock(); }
})();"""

def toggle_fullscreen():
    if sys.platform!="emscripten": return
    try:
        import platform
        platform.window.eval(FULLSCREEN_JS)
    except Exception as e:
        print("toggle_fullscreen failed:",repr(e))

def window_aspect():
    """Browser window width/height, or None when not in the browser."""
    if sys.platform!="emscripten": return None
    try:
        import platform
        w=float(platform.window.innerWidth); h=float(platform.window.innerHeight)
        return w/h if h>0 else None
    except Exception:
        return None

def auto_layout():
    """PC window on a desktop; in the browser pick by screen shape:
    wide (phone sideways) / portrait -> 'phone', squarer (iPad landscape) -> 'tablet'."""
    if sys.platform!="emscripten": return "pc"
    a=window_aspect()
    if a is not None and 1.0<a<1.6: return "tablet"
    return "phone"

# PC window on a desktop, phone layout in the browser. Changeable on the setup screen.
set_layout(auto_layout())
fit_web_canvas()

UI={"restart_until":0,"picked":False}   # restart button asks for a second tap within 2.5 s

@dataclass
class Person:
    owner:int
    leader:bool=False
    saboteur:bool=False
    @property
    def strength(self):
        if self.saboteur: return 0
        return 2 if self.leader else 1
    @property
    def regular(self):
        return not self.leader and not self.saboteur

@dataclass
class Token:
    owner:int
    x:int
    y:int
    people:list=field(default_factory=list)
    vehicle:bool=False
    def strength(self): return sum(p.strength for p in self.people)
    def has_leader(self): return any(p.leader for p in self.people)
    def has_saboteur(self): return any(p.saboteur for p in self.people)
    def regular_count(self): return sum(1 for p in self.people if p.regular)
    def visible_presence(self):
        return 1 if self.vehicle else len(self.people)

@dataclass
class Base:
    x:int
    y:int
    owner:int|None
    people:list=field(default_factory=list)
    # Leaders are never allowed inside bases. Saboteurs are allowed but add 0 DEF.
    def defense(self):
        return 1 + sum(p.strength for p in self.people)
    def has_leader(self): return False
    def has_saboteur(self): return any(p.saboteur for p in self.people)
    def regular_count(self): return sum(1 for p in self.people if p.regular)

class Game:
    def __init__(self,players=4,grid=9,base_move=2,unit_cap=6,
                 starting_pawns=3,starting_vehicle=True,draw_winner="defender",
                 basic_bot=True,randomize_faction_order=True,
                 bot_difficulty="medium",
                 harvest_reward_mode="ladder",
                 lose_last_base=False,
                 base_movement=False):
        self.players=players
        self.grid=grid
        self.base_move=base_move
        self.unit_cap=unit_cap
        self.starting_pawns=starting_pawns
        self.starting_vehicle=starting_vehicle
        self.draw_winner=draw_winner
        self.basic_bot=bool(basic_bot)
        self.bot_difficulty=("medium" if str(bot_difficulty).lower() in ("normal","medium") else str(bot_difficulty).lower()) if str(bot_difficulty).lower() in ("easy","normal","medium","hard") else "medium"
        self.randomize_faction_order=bool(randomize_faction_order)
        self.harvest_reward_mode=(
            harvest_reward_mode
            if harvest_reward_mode in (
                "progressive",   # 2 -> +1 pawn / push; 4 -> +3 / vehicle / saboteur
                "ladder",        # 2 -> +1 pawn / push; 3 -> vehicle/sab / push; 4 -> +3 pawns
                "clean_choice",  # 2 -> pawn/vehicle/sab / push; 4 -> +3 pawns
                "classic"        # 4 -> +2 pawns / vehicle / saboteur
            )
            else "progressive"
        )
        self.lose_last_base=bool(lose_last_base)
        self.base_movement=bool(base_movement)

        # Factions remain tied to their board seats/colors. What is randomized
        # is which faction the human controls and which faction gets turn 1.
        if self.basic_bot and self.randomize_faction_order:
            self.human_player=random.randrange(self.players)
        else:
            self.human_player=0

        self.bot_players=(
            {p for p in range(self.players) if p!=self.human_player}
            if self.basic_bot else set()
        )

        self.current=(
            random.randrange(self.players)
            if self.randomize_faction_order else 0
        )
        self.starting_player=self.current

        # self.turn remains the internal individual-player turn ("ply") counter.
        # global_turn is the full-table round shown in the UI:
        # all factions acting once = one global turn.
        self.turn=1
        self.global_turn=1
        self.tokens=[]; self.bases={}
        c=self.grid//2
        d=(c+1)//2
        self.harvest_tiles=[(c,c-d),(c+d,c),(c,c+d),(c-d,c)]
        self.harvest_active={p:{h:True for h in self.harvest_tiles} for p in range(players)}
        self.harvest_pending={p:{h:False for h in self.harvest_tiles} for p in range(players)}
        self.harvest_marks=[0]*players

        # Progressive harvest:
        #   2 marks -> optional +1 pawn cash-out OR commit to 4
        #   4 marks -> +3 pawns / +1 vehicle / recover Saboteur
        # Classic harvest:
        #   4 marks -> +2 pawns / +1 vehicle / recover Saboteur
        self.harvest_mid_offer=[False]*players
        self.harvest_committed_to_four=[False]*players
        self.harvest_cashouts=[0]*players
        self.harvest_full_cycles=[0]*players

        self.reinforcement_credits=[0]*players
        self.reserve=[0]*players
        self.reserve_vehicles=[0]*players
        self.saboteur_lost=[False]*players
        self.alive=[True]*players

        # Chess-like capture history. Each player keeps the enemy pieces they
        # personally removed in combat. Captured empty vehicles are tracked
        # separately because they are loot rather than destroyed pieces.
        self.taken=[[] for _ in range(players)]
        self.captured_vehicles=[[] for _ in range(players)]

        # Short-term combat memory.
        self.combat_markers=[]
        self.last_fight=None

        self.move_left=0
        self.action_taken=False
        self.selected=None
        self.selected_person_idx=None
        self.message=""
        self.privacy=True
        self.reveal_debug=False
        self.winner=None; self.draw=False
        self.log=[]
        # Detailed AI reasoning is kept separately from the omniscient engine log.
        self.ai_log=[]
        self._combat_context=None

        # SAFE-VIEW boundary. Bots may inspect only these observer-safe records
        # for opponents: board snapshots (outside circle positions + base owners)
        # and fight outcomes. The omniscient engine log remains debug/replay only.
        self.observer_snapshots=[]
        self.observer_fights=[]

        # Cheap turn-by-turn replay. Snapshots are compact primitive dicts and
        # are also written into the match JSON.
        self.replay_snapshots=[]
        self.replay_mode=False
        self.replay_index=0
        self.replay_start_index=0
        self.replay_playing=False
        self.replay_next_tick=0
        self.replay_interval_ms=2000

        # Replay knowledge perspective:
        # "you"        = original human faction's knowledge
        # "turn"       = faction whose turn the snapshot belongs to
        # "omniscient" = full true composition / all combat details
        self.replay_view_mode="you"

        self.human_elimination_snapshot=None

        self.setup_board()

    def setup_board(self):
        m=self.grid-1
        corners=[(0,0),(m,0),(m,m),(0,m)]
        vehicle_spots=[(0,1),(m,1),(m,m-1),(0,m-1)]
        # Leader starts diagonally next to its base (B2 when the base is A1).
        leader_spots=[(1,1),(m-1,1),(m-1,m-1),(1,m-1)]

        # Which corner each player sits in. 2 players face each other across the board.
        seats=[0,2] if self.players==2 else list(range(self.players))

        for i,pos in enumerate(corners):
            self.bases[pos]=Base(*pos,seats.index(i) if i in seats else None)

        c=self.grid//2
        self.bases[(c,c)]=Base(c,c,None)

        for p in range(self.players):
            s=seats[p]
            b=self.bases[corners[s]]

            # Saboteur starts hidden in the home base and occupies one of four slots.
            hidden_pawns=min(self.starting_pawns,3)
            b.people=[Person(p,False,False) for _ in range(hidden_pawns)]
            b.people.append(Person(p,False,True))

            lx,ly=leader_spots[s]
            self.tokens.append(Token(p,lx,ly,[Person(p,True,False)],False))

            if self.starting_vehicle:
                vx,vy=vehicle_spots[s]
                self.tokens.append(Token(p,vx,vy,[],True))

            # Preserve a 4-pawn test setting: the pawn displaced by the Saboteur
            # begins immediately outside the home base.
            overflow=max(0,self.starting_pawns-hidden_pawns)
            for _ in range(overflow):
                spot=self.find_spawn_outside_base(p)
                if spot is not None:
                    x,y=spot
                    self.tokens.append(Token(p,x,y,[Person(p,False,False)],False))
                else:
                    self.reserve[p]+=1

        self.start_turn()
        self.record_replay_snapshot("START")

    def _person_payload(self,p):
        return {
            "owner":p.owner,
            "leader":bool(p.leader),
            "saboteur":bool(p.saboteur),
        }

    def _person_from_payload(self,d):
        return Person(
            int(d["owner"]),
            bool(d.get("leader",False)),
            bool(d.get("saboteur",False)),
        )

    def snapshot_payload(self,label="TURN"):
        return {
            "label":label,
            "turn":self.turn,
            "global_turn":self.global_turn,
            "current":self.current,
            "move_left":self.move_left,
            "action_taken":bool(self.action_taken),
            "message":self.message,
            "winner":self.winner,
            "draw":bool(self.draw),
            "alive":list(self.alive),
            "harvest_marks":list(self.harvest_marks),
            "harvest_mid_offer":list(self.harvest_mid_offer),
            "harvest_committed_to_four":list(self.harvest_committed_to_four),
            "harvest_cashouts":list(self.harvest_cashouts),
            "harvest_full_cycles":list(self.harvest_full_cycles),
            "reinforcement_credits":list(self.reinforcement_credits),
            "reserve":list(self.reserve),
            "reserve_vehicles":list(self.reserve_vehicles),
            "saboteur_lost":list(self.saboteur_lost),
            "harvest_active":[
                [bool(self.harvest_active[p][h]) for h in self.harvest_tiles]
                for p in range(self.players)
            ],
            "harvest_pending":[
                [bool(self.harvest_pending[p][h]) for h in self.harvest_tiles]
                for p in range(self.players)
            ],
            "tokens":[
                {
                    "owner":t.owner,"x":t.x,"y":t.y,"vehicle":bool(t.vehicle),
                    "people":[self._person_payload(p) for p in t.people],
                }
                for t in self.tokens
            ],
            "bases":[
                {
                    "x":b.x,"y":b.y,"owner":b.owner,
                    "people":[self._person_payload(p) for p in b.people],
                }
                for b in self.bases.values()
            ],
            "taken":[list(x) for x in self.taken],
            "captured_vehicles":[list(x) for x in self.captured_vehicles],
            "combat_markers":[dict(x) for x in self.combat_markers],
            "last_fight":self.last_fight,
        }

    def record_replay_snapshot(self,label="TURN",force=False):
        snap=self.snapshot_payload(label)
        if not force and self.replay_snapshots:
            prev=self.replay_snapshots[-1]
            # Avoid exact duplicate frame spam.
            if (
                prev.get("turn")==snap.get("turn")
                and prev.get("current")==snap.get("current")
                and prev.get("tokens")==snap.get("tokens")
                and prev.get("bases")==snap.get("bases")
                and prev.get("winner")==snap.get("winner")
            ):
                return len(self.replay_snapshots)-1
        self.replay_snapshots.append(snap)
        return len(self.replay_snapshots)-1

    def restore_replay_snapshot(self,index):
        if not self.replay_snapshots:
            return
        index=max(0,min(index,len(self.replay_snapshots)-1))
        s=self.replay_snapshots[index]
        self.replay_index=index

        self.turn=int(s["turn"])
        self.global_turn=int(s.get("global_turn", ((self.turn-1)//max(1,self.players))+1))
        self.current=int(s["current"])
        self.move_left=int(s.get("move_left",0))
        self.action_taken=bool(s.get("action_taken",False))
        self.message=s.get("message","")
        self.winner=s.get("winner")
        self.draw=bool(s.get("draw",False))
        self.alive=list(s.get("alive",self.alive))
        self.harvest_marks=list(s.get("harvest_marks",self.harvest_marks))
        self.harvest_mid_offer=list(
            s.get("harvest_mid_offer",self.harvest_mid_offer)
        )
        self.harvest_committed_to_four=list(
            s.get("harvest_committed_to_four",self.harvest_committed_to_four)
        )
        self.harvest_cashouts=list(
            s.get("harvest_cashouts",self.harvest_cashouts)
        )
        self.harvest_full_cycles=list(
            s.get("harvest_full_cycles",self.harvest_full_cycles)
        )
        self.reinforcement_credits=list(
            s.get("reinforcement_credits",self.reinforcement_credits)
        )
        self.reserve=list(s.get("reserve",self.reserve))
        self.reserve_vehicles=list(s.get("reserve_vehicles",self.reserve_vehicles))
        self.saboteur_lost=list(s.get("saboteur_lost",self.saboteur_lost))

        for p in range(self.players):
            for i,h in enumerate(self.harvest_tiles):
                self.harvest_active[p][h]=bool(s["harvest_active"][p][i])
                self.harvest_pending[p][h]=bool(s["harvest_pending"][p][i])

        self.tokens=[
            Token(
                int(t["owner"]),int(t["x"]),int(t["y"]),
                [self._person_from_payload(p) for p in t.get("people",[])],
                bool(t.get("vehicle",False))
            )
            for t in s.get("tokens",[])
        ]

        self.bases={}
        for b in s.get("bases",[]):
            base=Base(int(b["x"]),int(b["y"]),b.get("owner"))
            base.people=[self._person_from_payload(p) for p in b.get("people",[])]
            self.bases[(base.x,base.y)]=base

        self.taken=[list(x) for x in s.get("taken",[[] for _ in range(self.players)])]
        self.captured_vehicles=[
            list(x) for x in s.get("captured_vehicles",[[] for _ in range(self.players)])
        ]
        self.combat_markers=[dict(x) for x in s.get("combat_markers",[])]
        self.last_fight=s.get("last_fight")
        self.selected=None
        self.selected_person_idx=None
        self.privacy=False

    def enter_replay_mode(self,start_at_end=True):
        if not self.replay_snapshots:
            return
        self.replay_mode=True
        self.replay_playing=False
        self.replay_next_tick=0
        self.replay_start_index=0
        self.replay_view_mode="you"

        index=(len(self.replay_snapshots)-1) if start_at_end else 0
        self.restore_replay_snapshot(index)

    def log_event(self,event_type,**data):
        self.log.append({"turn":self.turn,"player":self.current,"kind":event_type,**data})

    def controlled_bases(self,p):
        return [b for b in self.bases.values() if b.owner==p]

    def token_at(self,x,y):
        return next((t for t in self.tokens if t.x==x and t.y==y),None)

    def visible_regulars(self,p):
        return sum(t.regular_count() for t in self.tokens if t.owner==p and not t.vehicle)

    def visible_units(self,p):
        """
        Visible UNIT cap:
        - each exposed person outside a vehicle/base = 1
        - each vehicle token = 1, regardless of occupants
        Hidden occupants add 0.
        """
        total=0
        for t in self.tokens:
            if t.owner!=p:
                continue
            total += 1 if t.vehicle else len(t.people)
        return total

    def visible_presence(self,p):
        # The same visible-unit count generates movement.
        return self.visible_units(p)

    def movement_pool_for(self,p):
        if self.base_movement:
            return 1 + len(self.controlled_bases(p)) + self.visible_presence(p)
        return self.base_move + self.visible_presence(p)

    def adjacent(self,a,b):
        return abs(a[0]-b[0])+abs(a[1]-b[1])==1

    def observer_snapshot(self, actor=None, phase="observe"):
        """Return exactly the board information any player can see.

        Enemy composition, token identity, base contents, harvest state, MOV,
        reserves and action history are intentionally absent. MOV must be
        inferred by the observer from visible circles + owned bases.
        """
        return {
            "seq": len(self.observer_snapshots),
            "global_turn": self.global_turn,
            "actor": actor,
            "phase": phase,
            "outside": {
                p: [[t.x,t.y] for t in self.tokens if t.owner==p]
                for p in range(self.players)
            },
            "base_owners": {
                f"{pos[0]},{pos[1]}": b.owner for pos,b in self.bases.items()
            },
        }

    def record_observer_snapshot(self, actor=None, phase="observe"):
        snap=self.observer_snapshot(actor,phase)
        self.observer_snapshots.append(snap)
        return snap

    def observer_view(self, observer):
        """Canonical safe information channel for AI perception."""
        fights=[]
        for item in self.observer_fights:
            out={"seq":item["seq"],"public":dict(item["public"])}
            if observer in item.get("private_for",()):
                out["private"]=dict(item.get("private",{}))
            fights.append(out)
        return {
            "current": self.observer_snapshot(phase="current"),
            "snapshots": list(self.observer_snapshots),
            "fights": fights,
        }

    def public_tokens_for(self,p):
        """Strict public board snapshot: only visible token coordinates.

        A token's underlying type/composition is hidden information. Vehicle,
        leader, pawn, saboteur and cargo identity must NEVER be exposed here.
        Hard bots may infer identity only from public history/evidence.
        """
        return [
            {"pos":[t.x,t.y]}
            for t in self.tokens if t.owner==p
        ]

    def start_turn(self):
        if self.winner is not None or self.draw: return
        self.move_left=self.movement_pool_for(self.current)
        self.action_taken=False
        self.selected=None; self.selected_person_idx=None
        self.message=f"{faction_name(self.current)}: {self.move_left} movement."
        # Public-only snapshot used by Hard bots to reconstruct what an expert
        # observer could infer from board transitions. No token-type, cargo, or identity leaks.
        self.record_observer_snapshot(self.current,"turn_start")
        self.check_victory()

    def end_turn_allowed(self):
        if not self.action_taken:
            return False
        if self.harvest_mid_offer[self.current]:
            return False
        if self.reinforcement_credits[self.current]>0 and self.controlled_bases(self.current):
            return False
        return True

    def next_turn(self):
        if self.winner is not None or self.draw: return
        if not self.end_turn_allowed():
            if not self.action_taken:
                self.message="You must make at least one move before ending your turn."
            elif self.harvest_mid_offer[self.current]:
                marks=self.harvest_marks[self.current]
                self.message=f"Resolve your {marks}-harvest reward choice first."
            else:
                self.message="Choose your reinforcement before ending the turn."
            return

        # Snapshot before end-turn harvest/reward bookkeeping. This exposes only
        # what every player can see on the board plus the public MOV budget.
        self.record_observer_snapshot(self.current,"turn_end")
        before_credits=self.reinforcement_credits[self.current]
        before_mid=self.harvest_mid_offer[self.current]
        self.collect_end_turn_harvests(self.current)
        new_mid=self.harvest_mid_offer[self.current] and not before_mid
        new_credit=self.reinforcement_credits[self.current] > before_credits

        if new_mid:
            # Stay on the current turn so the player can cash out or push to 4.
            return

        if new_credit and self.controlled_bases(self.current):
            # Stay on the current turn so the player can choose the reward first.
            return

        self.resolve_harvest_respawns(self.current)
        self.record_replay_snapshot("TURN_END")

        old_phase=(self.current-self.starting_player)%self.players
        for _ in range(self.players):
            self.current=(self.current+1)%self.players
            if self.alive[self.current]:
                break
        new_phase=(self.current-self.starting_player)%self.players

        # Crossing the cyclic start boundary means every seat in this round
        # has had its opportunity, including eliminated seats that are skipped.
        if new_phase<=old_phase:
            self.global_turn+=1

        self.turn+=1
        self.combat_markers=[
            m for m in self.combat_markers if m["expires"]>=self.turn
        ]
        self.privacy=True
        self.start_turn()

    def combat_loss_kinds(self,people=None,vehicle=False):
        kinds=[]
        for p in list(people or []):
            if p.leader: kinds.append("leader")
            elif p.saboteur: kinds.append("saboteur")
            else: kinds.append("pawn")
        if vehicle:
            kinds.append("vehicle")
        return kinds

    def add_combat_marker(self,x,y,owner,kinds):
        if owner is None or not kinds:
            return
        self.combat_markers.append({
            "x":x,"y":y,"owner":owner,"kinds":list(kinds),
            "expires":self.turn+self.players+1
        })

    def set_last_fight(self,attacker,defender,atk_value,def_value,result,losses):
        # UI state.
        winner=None
        if isinstance(result,str) and result.startswith("P"):
            try:
                winner=int(result.split()[0][1:])-1
            except Exception:
                winner=None
        elif isinstance(result,str) and result.startswith("BASE HOLDS"):
            winner=defender

        ctx=self._combat_context or {}
        location=ctx.get("location")
        is_base=bool(ctx.get("base",False))

        self.last_fight={
            "attacker":attacker,"defender":defender,
            "atk":atk_value,"def":def_value,
            "result":result,"winner":winner,
            "losses":list(losses),
            "location":location,"base":is_base,
        }

        # Observer-safe intelligence stream.
        # PUBLIC: everybody may know a fight happened, the participants/location,
        # and the winner. PRIVATE: only attacker/defender get combat values/losses.
        public={
            "attacker":attacker,
            "defender":defender,
            "winner":winner,
            "location":location,
            "base":is_base,
            "attacker_from":ctx.get("attacker_from"),
        }
        private={
            "atk":atk_value,
            "def":def_value,
            "losses":[[owner,list(kinds)] for owner,kinds in losses],
            "result":result,
        }
        private_for=[p for p in (attacker,defender) if p is not None]
        self.observer_fights.append({
            "seq":len(self.observer_fights),
            "public":dict(public),
            "private_for":list(private_for),
            "private":dict(private),
        })
        self.log_event(
            "combat_result",
            public=public,
            private_for=private_for,
            private=private,
        )

    def record_taken(self,killer,victim_owner,people=None,vehicle=False):
        """Record pieces physically removed by another player in combat."""
        if killer is None or victim_owner is None:
            return
        if not (0 <= killer < self.players) or killer==victim_owner:
            return
        for person in list(people or []):
            kind="leader" if person.leader else ("saboteur" if person.saboteur else "pawn")
            self.taken[killer].append({"kind":kind,"owner":victim_owner})
            if person.saboteur:
                self.saboteur_lost[victim_owner]=True
        if vehicle:
            self.taken[killer].append({"kind":"vehicle","owner":victim_owner})

    def record_captured_vehicle(self,captor,previous_owner):
        if captor is None or previous_owner is None or captor==previous_owner:
            return
        if 0 <= captor < self.players:
            self.captured_vehicles[captor].append(previous_owner)

    def remove_one_regular(self,people):
        for i,p in enumerate(people):
            if p.regular:
                people.pop(i); return True
        return False

    def remove_one_saboteur(self,people,owner):
        for i,p in enumerate(people):
            if p.saboteur:
                people.pop(i)
                self.saboteur_lost[owner]=True
                return True
        return False

    def remove_dead_player_assets(self,p):
        self.tokens=[t for t in self.tokens if t.owner!=p]
        for b in self.bases.values():
            if b.owner==p:
                b.owner=None; b.people=[]

    def eliminate_for_last_base(self,p):
        """Optional GDG-style elimination when a player loses their final base."""
        if not self.lose_last_base:
            return False
        if not (0<=p<self.players) or not self.alive[p]:
            return False
        if self.controlled_bases(p):
            return False

        self.alive[p]=False
        self.log_event("last_base_lost",victim=p)
        self.remove_dead_player_assets(p)

        living=[q for q in range(self.players) if self.alive[q]]
        if len(living)==0:
            self.draw=True
            self.finish_game("simultaneous_elimination",None)
        elif len(living)==1:
            self.winner=living[0]
            self.finish_game("last_base",self.winner)
        else:
            self.check_victory()
        return True

    def eliminate_players_simultaneously(self,players):
        victims={p for p in players if 0<=p<self.players and self.alive[p]}
        for p in victims:
            self.alive[p]=False
            self.log_event("leader_killed",victim=p)
        for p in victims:
            self.remove_dead_player_assets(p)
        self.check_victory()

    def check_victory(self):
        if self.winner is not None or self.draw: return
        living=[p for p in range(self.players) if self.alive[p]]
        if len(living)==0:
            self.draw=True; self.finish_game("simultaneous_leader_death",None); return
        if len(living)==1:
            self.winner=living[0]; self.finish_game("last_leader",self.winner); return
        m=self.grid-1
        corners=[(0,0),(m,0),(m,m),(0,m)]
        for p in living:
            if all(self.bases[c].owner==p for c in corners):
                self.winner=p; self.finish_game("four_corner_bases",p); return

    def finish_game(self,reason,winner):
        self.log_event("game_over",winner=winner,reason=reason)
        self.message=(
            "DRAW" if winner is None
            else f"{faction_name(winner)} WINS — {reason.replace('_',' ').upper()}"
        )
        self.record_replay_snapshot("GAME_OVER",force=True)
        try:
            match_dir=Path(__file__).with_name("Matchs")
            match_dir.mkdir(parents=True,exist_ok=True)
            out=match_dir/("match_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".json")
            out.write_text(json.dumps({
                "version":VERSION,"players":self.players,"winner":winner,
                "reason":reason,
                "turns":self.global_turn,
                "rounds":self.global_turn,
                "plies":self.turn,
                "settings":{
                    "grid":self.grid,
                    "base_move":self.base_move,
                    "unit_cap":self.unit_cap,
                    "starting_pawns":self.starting_pawns,
                    "starting_vehicle":self.starting_vehicle,
                    "draw_winner":self.draw_winner,
                    "basic_bot":self.basic_bot,
                    "bot_difficulty":self.bot_difficulty,
                    "bot_players":sorted(self.bot_players),
                    "human_player":self.human_player,
                    "starting_player":self.starting_player,
                    "randomize_faction_order":self.randomize_faction_order,
                    "harvest_reward_mode":self.harvest_reward_mode,
                    "lose_last_base":self.lose_last_base,
                    "base_movement":self.base_movement
                },
                "factions":FACTION_NAMES,
                "harvest_stats":{
                    "cashouts":self.harvest_cashouts,
                    "full_cycles":self.harvest_full_cycles
                },
                "bot_personality_model":"V3.8-DIFFICULTY-SURVIVAL",
                "events":self.log,
                "ai_decisions":self.ai_log,
                "replay_snapshots":self.replay_snapshots
            },indent=2),encoding="utf-8")
        except Exception:
            pass

        # Every completed game immediately exposes the replay controls while
        # keeping the final position on screen. << jumps to the true opening.
        self.enter_replay_mode(start_at_end=True)

    # ---------- pathing ----------
    def square_blocks_path(self,pos,owner,goal):
        if pos==goal:
            return False
        t=self.token_at(*pos)
        if t is not None:
            # Friendly units may be crossed; enemies block.
            return t.owner!=owner
        if pos in self.bases:
            # Bases are solid except when they are the destination.
            return True
        return False

    def find_path(self,start,goal,owner):
        q=deque([start]); prev={start:None}
        while q:
            cur=q.popleft()
            if cur==goal: break
            x,y=cur
            for nxt in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                nx,ny=nxt
                if not (0<=nx<self.grid and 0<=ny<self.grid) or nxt in prev: continue
                if self.square_blocks_path(nxt,owner,goal): continue
                prev[nxt]=cur; q.append(nxt)
        if goal not in prev: return None
        path=[]; cur=goal
        while cur!=start:
            path.append(cur); cur=prev[cur]
        path.reverse()
        return path

    def harvest_kind_map(self):
        return {pos:HARVEST_ORDER[i] for i,pos in enumerate(self.harvest_tiles)}

    def harvest_collected_this_cycle(self,p,pos):
        # Collected already this cycle, but not waiting for the next cycle reset.
        return (not self.harvest_active[p].get(pos,False)) and (not self.harvest_pending[p].get(pos,False))

    def collect_end_turn_harvests(self,p):
        collected=[]
        start_marks=self.harvest_marks[p]

        for t in self.tokens:
            if t.owner!=p:
                continue
            pos=(t.x,t.y)
            if pos in self.harvest_tiles and self.harvest_active[p].get(pos,False):
                self.harvest_active[p][pos]=False
                self.harvest_marks[p]+=1
                marks=self.harvest_marks[p]
                self.log_event("harvest",tile=list(pos),marks=marks)
                collected.append(pos)

        if collected:
            self.message=f"Harvest secured ({self.harvest_marks[p]}/4)."
            self._evaluate_harvest_threshold(p,start_marks)

        return collected

    def collect_harvest_along_path(self,owner,path):
        # v0.11.2: harvest is no longer collected by passing through.
        # A harvest is gained only if a unit ends the turn on its tile.
        return

    def reachable_empty_tiles(self,t):
        """
        Empty destinations this selected token can legally reach with the
        movement points currently remaining. Friendly units may be crossed,
        enemies and bases block paths as usual.
        """
        if self.move_left <= 0:
            return set()
        if t.vehicle and not t.people:
            return set()

        start=(t.x,t.y)
        reachable=set()
        q=deque([(start,0)])
        seen={start}

        while q:
            cur,dist=q.popleft()
            if dist>=self.move_left:
                continue
            x,y=cur
            for nxt in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                nx,ny=nxt
                if not (0<=nx<self.grid and 0<=ny<self.grid):
                    continue
                if nxt in seen:
                    continue

                tok=self.token_at(nx,ny)
                base=self.bases.get(nxt)

                # Enemy units and any base stop path expansion.
                if tok is not None and tok.owner != t.owner:
                    continue
                if base is not None:
                    continue

                seen.add(nxt)
                nd=dist+1

                # Friendly units may be crossed but are not empty destinations.
                if tok is None:
                    reachable.add(nxt)

                q.append((nxt,nd))

        return reachable

    def reachable_interaction_targets(self,t):
        """
        Returns:
          friendly: set of reachable occupied friendly destinations
          hostile: set of reachable enemy/base destinations that trigger attack/capture

        Empty vehicle cannot move, so it has no reachable interaction targets.
        """
        friendly=set()
        hostile=set()

        if self.move_left <= 0:
            return friendly,hostile
        if t.vehicle and not t.people:
            return friendly,hostile

        start=(t.x,t.y)

        # Tokens
        for other in self.tokens:
            if other is t:
                continue
            goal=(other.x,other.y)
            path=self.find_path(start,goal,t.owner)
            if path is None or len(path)>self.move_left:
                continue

            if other.owner==t.owner:
                # Core rule: there are NO field teams outside vehicles.
                # Friendly people may combine only inside a vehicle, but boarding
                # works symmetrically:
                #   person -> vehicle OR occupied vehicle -> pawn/leader.
                if other.vehicle:
                    if (not t.vehicle
                            and not t.has_saboteur()
                            and len(other.people)+len(t.people) <= MAX_GROUP):
                        friendly.add(goal)
                elif t.vehicle:
                    # An occupied vehicle may drive onto a lone pawn/leader and
                    # pick them up, provided there is capacity. Saboteur is the
                    # one exception: it can never enter a vehicle.
                    if (t.people
                            and not other.has_saboteur()
                            and len(t.people)+len(other.people) <= MAX_GROUP):
                        friendly.add(goal)
                # Non-vehicle -> non-vehicle remains illegal.
            else:
                # A Saboteur may capture an empty enemy Vehicle; it simply
                # cannot board that Vehicle.
                hostile.add(goal)

        # Bases
        for goal,b in self.bases.items():
            path=self.find_path(start,goal,t.owner)
            if path is None or len(path)>self.move_left:
                continue

            if b.owner==t.owner:
                # Vehicle and leader can never enter. Pawn/Saboteur may enter.
                base_eligible=any(not p.leader for p in t.people)
                if not t.vehicle and base_eligible and len(b.people)<4:
                    friendly.add(goal)
            else:
                # Neutral and enemy bases are actionable attack/capture targets.
                hostile.add(goal)

        return friendly,hostile

    # ---------- movement / interaction ----------
    def try_move_or_interact(self,t,nx,ny):
        if self.move_left<=0:
            self.message="No movement left."; return
        if t.vehicle and not t.people:
            # Empty vehicle cannot move, but it remains a valid visible token.
            self.message="Empty vehicle cannot move."; return

        goal=(nx,ny)
        path=self.find_path((t.x,t.y),goal,t.owner)
        if path is None:
            self.message="No legal path."; return
        cost=len(path)
        if cost>self.move_left:
            self.message=f"Need {cost} movement; only {self.move_left} left."; return

        target=self.token_at(nx,ny)
        base=self.bases.get(goal)

        # Empty destination.
        if target is None and base is None:
            move_from=(t.x,t.y)
            t.x,t.y=nx,ny
            self.move_left-=cost
            self.action_taken=True
            self.collect_harvest_along_path(t.owner,path)
            self.log_event("move",from_pos=list(move_from),to=[nx,ny],cost=cost,vehicle=t.vehicle,strength=t.strength())
            self.selected=t; self.selected_person_idx=None
            self.message=f"Moved {cost} tile"+("s." if cost!=1 else ".")
            return

        # Friendly token endpoint.
        if target is not None and target.owner==self.current:
            if target is t:
                self.selected=None; self.selected_person_idx=None
                return
            self.collect_harvest_along_path(t.owner,path[:-1])
            self.merge_tokens(t,target,cost)
            return

        # Enemy token endpoint.
        if target is not None and target.owner!=self.current:
            self.collect_harvest_along_path(t.owner,path[:-1])
            if target.vehicle and not target.people:
                # Empty enemy Vehicle: normal units steal it, but a Saboteur
                # cannot board Vehicles and therefore destroys it instead.
                old=target.owner
                self.move_left-=cost
                self.action_taken=True
                self.release_reserve_slots(old,1)

                if not t.vehicle and t.has_saboteur():
                    approach = path[-2] if len(path) >= 2 else (t.x,t.y)
                    t.x,t.y = approach
                    if target in self.tokens:
                        self.tokens.remove(target)
                    self.log_event(
                        "vehicle_destroyed",
                        victim=old,
                        attacker=self.current,
                        at=[nx,ny],
                        occupied=False,
                        destroyed_by_saboteur=True
                    )
                    self.message=f"Saboteur destroyed {faction_name(old)}'s empty vehicle."
                    self.selected=t
                    self.selected_person_idx=None

                elif not t.vehicle:
                    self.record_captured_vehicle(self.current,old)
                    boarded_people=list(t.people)
                    target.owner=self.current
                    target.people.extend(boarded_people)
                    if t in self.tokens:
                        self.tokens.remove(t)

                    # The exposed attackers have collapsed into one visible vehicle.
                    # Any newly freed visible-unit slots may immediately release reserve.
                    freed=max(0,len(boarded_people)-1)
                    if freed:
                        self.release_reserve_slots(self.current,freed)

                    self.log_event(
                        "vehicle_captured",
                        from_player=old,
                        at=[nx,ny],
                        to_reserve=False,
                        boarded=len(boarded_people)
                    )
                    self.message=f"Captured {faction_name(old)}'s empty vehicle and boarded it."
                    self.selected=target
                    self.selected_person_idx=None

                else:
                    # Occupied vehicle cannot board another vehicle.
                    # It advances to the final square before the captured vehicle,
                    # while the stolen empty vehicle remains on its own tile.
                    approach = path[-2] if len(path) >= 2 else (t.x,t.y)
                    t.x,t.y = approach

                    if self.visible_units(self.current) >= self.unit_cap:
                        self.tokens.remove(target)
                        self.reserve_vehicles[self.current]+=1
                        self.log_event(
                            "vehicle_captured",
                            from_player=old,
                            at=[nx,ny],
                            to_reserve=True,
                            attacker_approach=list(approach)
                        )
                        self.message=f"Captured {faction_name(old)}'s empty vehicle; sent to reserve."
                        self.selected=t
                        self.selected_person_idx=None
                    else:
                        target.owner=self.current
                        self.log_event(
                            "vehicle_captured",
                            from_player=old,
                            at=[nx,ny],
                            to_reserve=False,
                            attacker_approach=list(approach)
                        )
                        self.message=f"Captured {faction_name(old)}'s empty vehicle."
                        self.selected=t
                        self.selected_person_idx=None
                return
            self.resolve_field_combat(t,target,cost)
            return

        # Base endpoint.
        if base is not None:
            self.collect_harvest_along_path(t.owner,path[:-1])
            if base.owner==self.current:
                self.enter_friendly_base(t,base,cost)
            else:
                # The base tile itself is the final path step. A leader supports the
                # assault from the square immediately before it rather than remaining
                # back on the square where the move started.
                approach = path[-2] if len(path) >= 2 else (t.x,t.y)
                self.resolve_base_attack(t,base,cost,approach)
            return

    def merge_tokens(self,src,dst,cost):
        # Core rule: exposed people NEVER merge into field teams.
        # The only legal multi-person field token is a vehicle with occupants.

        # Normal direction: exposed pawn/leader boards a friendly vehicle.
        if dst.vehicle:
            if src.vehicle:
                self.message="Vehicles cannot merge."
                return
            if src.has_saboteur():
                self.message="Saboteur can never enter a vehicle."
                return
            if len(dst.people)+len(src.people)>MAX_GROUP:
                self.message="Vehicle capacity is 4."
                return

            boarded_count=len(src.people)
            merge_from=(src.x,src.y)
            dst.people.extend(src.people)
            self.tokens.remove(src)
            self.move_left-=cost
            self.action_taken=True
            self.release_reserve_slots(src.owner,1)
            self.selected=dst
            self.selected_person_idx=None
            self.log_event(
                "board_vehicle",
                from_pos=list(merge_from),
                at=[dst.x,dst.y],
                count=len(dst.people),
                boarded=boarded_count,
                direction="person_to_vehicle",
                cost=cost
            )
            return

        # Reverse direction: an OCCUPIED vehicle drives onto a lone friendly
        # pawn/leader and picks that unit up.
        if src.vehicle:
            if not src.people:
                self.message="Empty vehicle cannot move."
                return
            if dst.vehicle:
                self.message="Vehicles cannot merge."
                return
            if dst.has_saboteur():
                self.message="Saboteur can never enter a vehicle."
                return
            if len(src.people)+len(dst.people)>MAX_GROUP:
                self.message="Vehicle capacity is 4."
                return

            boarded_count=len(dst.people)
            merge_from=(src.x,src.y)
            src.people.extend(dst.people)
            src.x,src.y=dst.x,dst.y
            self.tokens.remove(dst)
            self.move_left-=cost
            self.action_taken=True
            self.release_reserve_slots(src.owner,1)
            self.selected=src
            self.selected_person_idx=None
            self.log_event(
                "board_vehicle",
                from_pos=list(merge_from),
                at=[src.x,src.y],
                count=len(src.people),
                boarded=boarded_count,
                direction="vehicle_to_person",
                cost=cost
            )
            return

        self.message="Field units cannot merge; use a vehicle."

    def enter_friendly_base(self,t,b,cost):
        if t.vehicle:
            self.message="Vehicles cannot enter bases."; return

        entrants=[p for p in t.people if not p.leader]
        if not entrants:
            self.message="Leader can never enter a base."; return

        free=4-len(b.people)
        if free<=0:
            self.message="Base is full."; return

        entering=entrants[:free]
        for p in entering:
            t.people.remove(p); b.people.append(p)

        self.move_left-=cost
        self.action_taken=True
        self.release_reserve_slots(t.owner,len(entering))
        self.log_event("enter_base",base=[b.x,b.y],count=len(entering),cost=cost)

        if not t.people:
            self.tokens.remove(t); self.selected=b
        else:
            # Any leader in the moving group remains outside on the origin square.
            self.selected=t
        self.selected_person_idx=None

    # ---------- container panel ----------
    def container_people(self,obj):
        if isinstance(obj,Base): return obj.people
        if isinstance(obj,Token) and obj.vehicle: return obj.people
        return None

    def reachable_container_destinations(self,obj,idx):
        """Return legal destinations for one selected person inside a base/vehicle."""
        empty_tiles=set()
        friendly_targets=set()

        people=self.container_people(obj)
        if people is None or idx is None or idx<0 or idx>=len(people):
            return empty_tiles,friendly_targets
        if self.move_left<=0:
            return empty_tiles,friendly_targets

        person=people[idx]
        start=(obj.x,obj.y)

        # Exiting onto the board creates one new visible unit.
        if self.visible_units(self.current) < self.unit_cap:
            for y in range(self.grid):
                for x in range(self.grid):
                    goal=(x,y)
                    if goal==start:
                        continue
                    if self.token_at(x,y) is not None or goal in self.bases:
                        continue
                    path=self.find_path(start,goal,self.current)
                    if path is not None and 1 <= len(path) <= self.move_left:
                        empty_tiles.add(goal)

        # Direct transfer into friendly vehicles. Saboteur can never board.
        if not person.saboteur:
            for t in self.tokens:
                if t is obj or t.owner!=self.current or not t.vehicle:
                    continue
                if len(t.people)>=4:
                    continue
                goal=(t.x,t.y)
                path=self.find_path(start,goal,self.current)
                if path is not None and 1 <= len(path) <= self.move_left:
                    friendly_targets.add(goal)

        # Direct transfer into friendly bases: pawn or Saboteur, never leader.
        if not person.leader:
            for goal,b in self.bases.items():
                if b is obj or b.owner!=self.current or len(b.people)>=4:
                    continue
                path=self.find_path(start,goal,self.current)
                if path is not None and 1 <= len(path) <= self.move_left:
                    friendly_targets.add(goal)

        return empty_tiles,friendly_targets

    def deploy_selected_person(self,obj,idx,nx,ny):
        people=self.container_people(obj)
        if people is None or idx is None or idx<0 or idx>=len(people):
            return
        person=people[idx]
        start=(obj.x,obj.y)
        goal=(nx,ny)

        target_token=self.token_at(nx,ny)
        target_base=self.bases.get(goal)

        # Direct transfer into a friendly vehicle.
        if target_token is not None and target_token.owner==self.current and target_token.vehicle:
            if person.saboteur:
                self.message="Saboteur must remain alone outside bases."
                return
            if target_token is obj:
                self.message="Already inside this vehicle."
                return
            if len(target_token.people)>=4:
                self.message="Vehicle is full."
                return
            path=self.find_path(start,goal,self.current)
            if path is None:
                self.message="No legal path to vehicle."
                return
            cost=len(path)
            if cost>self.move_left:
                self.message=f"Need {cost} movement; only {self.move_left} left."
                return
            people.pop(idx)
            target_token.people.append(person)
            self.move_left-=cost
            self.action_taken=True
            # A regular pawn leaving open/container logic: if it came from a base it was already hidden;
            # if it came from a vehicle it remains hidden, so no reserve release here.
            self.log_event("container_transfer",
                           source="base" if isinstance(obj,Base) else "vehicle",
                           target="vehicle",leader=person.leader,to=[nx,ny],cost=cost)
            self.selected=target_token; self.selected_person_idx=None
            label="Leader" if person.leader else ("Saboteur" if person.saboteur else "Pawn")
            self.message=label+f" transferred to vehicle, cost {cost}."
            return

        # Direct transfer into a friendly base: regular pawns only.
        if target_base is not None and target_base.owner==self.current:
            if person.leader:
                self.message="Leader can never enter a base."
                return
            if len(target_base.people)>=4:
                self.message="Base is full."
                return
            path=self.find_path(start,goal,self.current)
            if path is None:
                self.message="No legal path to base."
                return
            cost=len(path)
            if cost>self.move_left:
                self.message=f"Need {cost} movement; only {self.move_left} left."
                return
            people.pop(idx)
            target_base.people.append(person)
            self.move_left-=cost
            self.action_taken=True
            self.log_event("container_transfer",
                           source="base" if isinstance(obj,Base) else "vehicle",
                           target="base",leader=False,to=[nx,ny],cost=cost)
            self.selected=target_base; self.selected_person_idx=None
            self.message=f"Pawn transferred to base, cost {cost}."
            return

        # Otherwise exit onto an empty board tile.
        if target_token is not None or target_base is not None:
            self.message="Choose an empty tile, friendly vehicle, or friendly base."
            return

        if self.visible_units(self.current)>=self.unit_cap:
            self.message=f"Visible unit cap is {self.unit_cap}."
            return

        path=self.find_path(start,goal,self.current)
        if path is None:
            self.message="No legal path from container."
            return
        cost=len(path)
        if cost<1:
            return
        if cost>self.move_left:
            self.message=f"Need {cost} movement; only {self.move_left} left."
            return

        people.pop(idx)
        new=Token(self.current,nx,ny,[person],False)
        self.tokens.append(new)
        self.move_left-=cost
        self.action_taken=True
        self.collect_harvest_along_path(self.current,path)
        self.log_event("exit_container",
                       source="base" if isinstance(obj,Base) else "vehicle",
                       leader=person.leader,to=[nx,ny],cost=cost)
        self.selected=new; self.selected_person_idx=None
        self.message=("Leader" if person.leader else "Pawn")+f" exited, cost {cost}."

    # ---------- reserve ----------
    def find_spawn_outside_base(self,p):
        for b in self.controlled_bases(p):
            for x,y in ((b.x+1,b.y),(b.x-1,b.y),(b.x,b.y+1),(b.x,b.y-1)):
                if 0<=x<self.grid and 0<=y<self.grid and self.token_at(x,y) is None and (x,y) not in self.bases:
                    return (x,y)
        return None

    def inject_one_pawn_from_reserve(self,p):
        if self.reserve[p] <= 0 or not self.controlled_bases(p):
            return False

        # Hidden base slots do not count against visible-unit cap.
        for b in self.controlled_bases(p):
            if len(b.people) < 4:
                b.people.append(Person(p,False))
                self.reserve[p] -= 1
                self.log_event("reserve_deployed",reserve_type="pawn",location="base",
                               base=[b.x,b.y],reserve=self.reserve[p])
                return True

        # If all bases are full, pawn may appear outside only if a visible slot exists.
        if self.visible_units(p) < self.unit_cap:
            spot=self.find_spawn_outside_base(p)
            if spot is not None:
                x,y=spot
                self.tokens.append(Token(p,x,y,[Person(p,False)],False))
                self.reserve[p]-=1
                self.log_event("reserve_deployed",reserve_type="pawn",location="outside",
                               at=[x,y],reserve=self.reserve[p])
                return True
        return False

    def inject_one_vehicle_from_reserve(self,p):
        if self.reserve_vehicles[p] <= 0 or not self.controlled_bases(p):
            return False
        if self.visible_units(p) >= self.unit_cap:
            return False
        spot=self.find_spawn_outside_base(p)
        if spot is None:
            return False
        x,y=spot
        self.tokens.append(Token(p,x,y,[],True))
        self.reserve_vehicles[p]-=1
        self.log_event("reserve_deployed",reserve_type="vehicle",at=[x,y],
                       reserve_vehicles=self.reserve_vehicles[p])
        return True

    def release_reserve_slots(self,p,count):
        """
        A visible unit disappeared. First, any reserve pawns may fill empty base slots
        (hidden, so they do not consume visible capacity). Then each newly available
        visible slot can bring out a reserve vehicle or, if bases are full, a pawn.
        """
        self.fill_hidden_base_slots_from_pawn_reserve(p)
        for _ in range(count):
            if self.visible_units(p) >= self.unit_cap:
                break
            if self.inject_one_vehicle_from_reserve(p):
                continue
            if self.inject_one_pawn_from_reserve(p):
                continue
            break

    def fill_hidden_base_slots_from_pawn_reserve(self,p):
        changed=False
        while self.reserve[p] > 0:
            placed=False
            for b in self.controlled_bases(p):
                if len(b.people)<4:
                    b.people.append(Person(p,False))
                    self.reserve[p]-=1
                    placed=True; changed=True
                    self.log_event("reserve_deployed",reserve_type="pawn",
                                   location="base",base=[b.x,b.y],reserve=self.reserve[p])
                    break
            if not placed:
                break
        return changed

    def grant_new_pawn(self,p):
        """
        Priority:
        1) owned base slot, regardless of visible-unit count
        2) if every base is full and visible-unit count < 6, spawn outside
        3) otherwise reserve
        """
        for b in self.controlled_bases(p):
            if len(b.people)<4:
                b.people.append(Person(p,False))
                return "base"

        if self.visible_units(p) < self.unit_cap:
            spot=self.find_spawn_outside_base(p)
            if spot is not None:
                x,y=spot
                self.tokens.append(Token(p,x,y,[Person(p,False)],False))
                return "outside"

        self.reserve[p]+=1
        return "reserve"

    def grant_new_vehicle(self,p):
        if self.visible_units(p) >= self.unit_cap:
            self.reserve_vehicles[p]+=1
            return "reserve"
        spot=self.find_spawn_outside_base(p)
        if spot is not None:
            x,y=spot
            self.tokens.append(Token(p,x,y,[],True))
            return "outside"
        self.reserve_vehicles[p]+=1
        return "reserve"

    # ---------- combat ----------
    def resolve_field_combat(self,atk,dfn,cost):
        self._combat_context={"location":[dfn.x,dfn.y],"base":False,
                              "attacker_from":[atk.x,atk.y]}
        A,D=atk.strength(),dfn.strength()

        # SABOTEUR special: offensive only. If a Saboteur attacks an OCCUPIED
        # enemy vehicle, the vehicle and every occupant are destroyed. The
        # Saboteur advances into the now-empty target square.
        if atk.has_saboteur() and not atk.vehicle and dfn.vehicle and dfn.people:
            atk_owner,dfn_owner=atk.owner,dfn.owner
            victim_people=list(dfn.people)
            lost_kinds=self.combat_loss_kinds(victim_people,True)
            leader=dfn.has_leader()
            dx,dy=dfn.x,dfn.y

            self.log_event("saboteur_strike",location=[dx,dy],attacker=atk_owner,
                           defender=dfn_owner,destroyed_occupants=len(victim_people),cost=cost)
            self.record_taken(atk_owner,dfn_owner,victim_people,True)
            self.add_combat_marker(dx,dy,dfn_owner,lost_kinds)
            self.set_last_fight(atk_owner,dfn_owner,A,D,
                                f"P{atk_owner+1} SABOTEUR STRIKE",
                                [(dfn_owner,lost_kinds)])

            self.tokens.remove(dfn)

            # Vehicle and occupants are destroyed, not captured. The Saboteur
            # wins the fight and advances into the now-empty target square.
            atk.x,atk.y=dx,dy
            self.move_left=0
            self.action_taken=True
            self.release_reserve_slots(dfn_owner,1)
            self.selected=atk
            self.selected_person_idx=None
            self.message=(f"{faction_name(atk_owner)} Saboteur destroys "
                          f"{faction_name(dfn_owner)}'s occupied vehicle and all occupants.")
            if leader:
                self.eliminate_players_simultaneously([dfn_owner])
            self.check_victory()
            return

        A,D=atk.strength(),dfn.strength()
        atk_owner,dfn_owner=atk.owner,dfn.owner
        prefix=(f"{faction_name(atk_owner)} ATK {A} vs "
                f"{faction_name(dfn_owner)} ATK {D} — ")
        self.log_event("combat",location=[dfn.x,dfn.y],atk=A,defense=D,base=False,cost=cost,
                       attacker=atk_owner,defender=dfn_owner)

        if A>D:
            victim=dfn.owner; leader=dfn.has_leader()
            lost_visible = 1 if dfn.vehicle else len(dfn.people)
            lost_kinds=self.combat_loss_kinds(dfn.people,dfn.vehicle)
            self.record_taken(atk_owner,victim,dfn.people,dfn.vehicle)
            dx,dy=dfn.x,dfn.y
            self.add_combat_marker(dx,dy,victim,lost_kinds)
            self.set_last_fight(atk_owner,dfn_owner,A,D,f"P{atk_owner+1} WINS",[(victim,lost_kinds)])
            self.tokens.remove(dfn)
            atk.x,atk.y=dx,dy
            self.move_left=0
            self.action_taken=True
            self.release_reserve_slots(victim,lost_visible)
            self.message=prefix+f"{faction_name(atk_owner)} wins."
            if leader: self.eliminate_players_simultaneously([victim])

        elif A<D:
            victim=atk.owner; leader=atk.has_leader()
            lost_visible = 1 if atk.vehicle else len(atk.people)
            lost_kinds=self.combat_loss_kinds(atk.people,atk.vehicle)
            self.record_taken(dfn_owner,victim,atk.people,atk.vehicle)
            self.add_combat_marker(dfn.x,dfn.y,victim,lost_kinds)
            self.set_last_fight(atk_owner,dfn_owner,A,D,f"P{dfn_owner+1} WINS",[(victim,lost_kinds)])
            self.tokens.remove(atk); self.selected=None
            self.move_left=0
            self.action_taken=True
            self.release_reserve_slots(victim,lost_visible)
            self.message=prefix+f"{faction_name(dfn_owner)} wins."
            if leader: self.eliminate_players_simultaneously([victim])

        else:
            if self.draw_winner=="defender":
                atk_leader=atk.has_leader()
                atk_lost_visible = 1 if atk.vehicle else len(atk.people)
                dfn_leader_dies=False
                atk_lost_kinds=self.combat_loss_kinds(atk.people,atk.vehicle)
                self.record_taken(dfn_owner,atk_owner,atk.people,atk.vehicle)
                self.add_combat_marker(dfn.x,dfn.y,atk_owner,atk_lost_kinds)
                self.tokens.remove(atk); self.selected=None
                self.release_reserve_slots(atk_owner,atk_lost_visible)

                tie_losses=[(atk_owner,atk_lost_kinds)]
                if dfn.regular_count()>0:
                    dead_pawn=next(p for p in dfn.people if not p.leader)
                    self.record_taken(atk_owner,dfn_owner,[dead_pawn],False)
                    self.add_combat_marker(dfn.x,dfn.y,dfn_owner,["pawn"])
                    tie_losses.append((dfn_owner,["pawn"]))
                    self.remove_one_regular(dfn.people)
                elif dfn.has_saboteur():
                    dead_sab=next(p for p in dfn.people if p.saboteur)
                    self.record_taken(atk_owner,dfn_owner,[dead_sab],False)
                    self.add_combat_marker(dfn.x,dfn.y,dfn_owner,["saboteur"])
                    tie_losses.append((dfn_owner,["saboteur"]))
                    self.remove_one_saboteur(dfn.people,dfn_owner)
                elif dfn.has_leader():
                    dead_leader=next(p for p in dfn.people if p.leader)
                    self.record_taken(atk_owner,dfn_owner,[dead_leader],False)
                    self.add_combat_marker(dfn.x,dfn.y,dfn_owner,["leader"])
                    tie_losses.append((dfn_owner,["leader"]))
                    dfn_leader_dies=True
                    if dfn in self.tokens: self.tokens.remove(dfn)

                self.set_last_fight(atk_owner,dfn_owner,A,D,f"P{dfn_owner+1} WINS TIE",tie_losses)
                self.message=(prefix+f"tie: {faction_name(dfn_owner)} wins as defender, "
                              "but loses one pawn.")
                victims=[]
                if atk_leader: victims.append(atk_owner)
                if dfn_leader_dies: victims.append(dfn_owner)
                if victims: self.eliminate_players_simultaneously(victims)
                if dfn in self.tokens and not dfn.people and not dfn.vehicle:
                    self.tokens.remove(dfn)

            else:
                dfn_leader=dfn.has_leader()
                dfn_lost_visible = 1 if dfn.vehicle else len(dfn.people)
                dfn_lost_kinds=self.combat_loss_kinds(dfn.people,dfn.vehicle)
                self.record_taken(atk_owner,dfn_owner,dfn.people,dfn.vehicle)
                ax,ay=dfn.x,dfn.y
                self.add_combat_marker(ax,ay,dfn_owner,dfn_lost_kinds)
                tie_losses=[(dfn_owner,dfn_lost_kinds)]
                self.tokens.remove(dfn)
                self.release_reserve_slots(dfn_owner,dfn_lost_visible)

                atk_leader_dies=False
                if atk.regular_count()>0:
                    dead_pawn=next(p for p in atk.people if not p.leader)
                    self.record_taken(dfn_owner,atk_owner,[dead_pawn],False)
                    self.add_combat_marker(ax,ay,atk_owner,["pawn"])
                    tie_losses.append((atk_owner,["pawn"]))
                    self.remove_one_regular(atk.people)
                elif atk.has_saboteur():
                    dead_sab=next(p for p in atk.people if p.saboteur)
                    self.record_taken(dfn_owner,atk_owner,[dead_sab],False)
                    self.add_combat_marker(ax,ay,atk_owner,["saboteur"])
                    tie_losses.append((atk_owner,["saboteur"]))
                    self.remove_one_saboteur(atk.people,atk_owner)
                elif atk.has_leader():
                    dead_leader=next(p for p in atk.people if p.leader)
                    self.record_taken(dfn_owner,atk_owner,[dead_leader],False)
                    self.add_combat_marker(ax,ay,atk_owner,["leader"])
                    tie_losses.append((atk_owner,["leader"]))
                    atk_leader_dies=True
                    if atk in self.tokens: self.tokens.remove(atk)

                if atk in self.tokens:
                    atk.x,atk.y=ax,ay
                    self.selected=atk
                else:
                    self.selected=None

                self.set_last_fight(atk_owner,dfn_owner,A,D,f"P{atk_owner+1} WINS TIE",tie_losses)
                self.message=(prefix+f"tie: {faction_name(atk_owner)} wins as attacker, "
                              "but loses one pawn.")
                victims=[]
                if dfn_leader: victims.append(dfn_owner)
                if atk_leader_dies: victims.append(atk_owner)
                if victims: self.eliminate_players_simultaneously(victims)

            self.move_left=0
            self.action_taken=True
        self.check_victory()

    def resolve_base_attack(self,atk,b,cost,approach=None):
        self._combat_context={"location":[b.x,b.y],"base":True}
        # A base is attacked from the last traversable square before it.
        # Move the attacker there before resolving the fight so any surviving
        # vehicle/person finishes adjacent to the base, never back at its origin.
        if approach is not None and atk in self.tokens:
            atk.x,atk.y=approach

        A,D=atk.strength(),b.defense()
        entrants=[p for p in atk.people if not p.leader]
        regs=[p for p in atk.people if p.regular]
        attacking_saboteurs=[p for p in atk.people if p.saboteur]
        attacking_leader=atk.has_leader()
        defender_label=(f"{faction_name(b.owner)} base" if b.owner is not None else "Neutral base")
        self.message=f"{faction_name(atk.owner)} ATK {A} vs {defender_label} DEF {D} — "
        self.log_event("combat",location=[b.x,b.y],atk=A,defense=D,base=True,cost=cost,
                       attacker=atk.owner,defender=b.owner)

        if A>D:
            old=b.owner
            defending_leader=b.has_leader()
            killed_regs=b.regular_count()
            if old is not None and b.people:
                lost_kinds=self.combat_loss_kinds(b.people,False)
                self.record_taken(atk.owner,old,b.people,False)
                self.add_combat_marker(b.x,b.y,old,lost_kinds)
                self.set_last_fight(atk.owner,old,A,D,f"P{atk.owner+1} WINS",[(old,lost_kinds)])
            else:
                self.set_last_fight(atk.owner,old,A,D,f"P{atk.owner+1} WINS",[])
            b.people=[]; b.owner=self.current

            # Pawn/Saboteur attackers enter; leader stays outside.
            for p in list(entrants)[:4]:
                if len(b.people)>=4: break
                if p in atk.people:
                    atk.people.remove(p); b.people.append(p)

            self.move_left=0
            self.action_taken=True
            self.message+=f"{faction_name(atk.owner)} wins; base captured."
            self.log_event("base_captured",base=[b.x,b.y],previous_owner=old)

            # Experimental rule: if this was the defender's final base, they
            # are eliminated even if their leader survived elsewhere.
            if old is not None and old!=atk.owner:
                self.eliminate_for_last_base(old)

            if defending_leader and old is not None and self.alive[old]:
                self.eliminate_players_simultaneously([old])

            if atk in self.tokens:
                if not atk.people and not atk.vehicle:
                    self.tokens.remove(atk); self.selected=b
                else:
                    self.selected=atk
            self.selected_person_idx=None

        else:
            attacker_regs=len(regs)
            attacker_sabs=len(attacking_saboteurs)
            all_nonleaders=list(entrants)
            base_losses=[]

            if b.owner is not None and all_nonleaders:
                self.record_taken(b.owner,atk.owner,all_nonleaders,False)
            elif attacking_saboteurs:
                self.saboteur_lost[atk.owner]=True

            lost_kinds=["pawn"]*attacker_regs + ["saboteur"]*attacker_sabs
            if lost_kinds:
                self.add_combat_marker(b.x,b.y,atk.owner,lost_kinds)
                base_losses.append((atk.owner,lost_kinds))

            for p in list(atk.people):
                if not p.leader:
                    if p.saboteur:
                        self.saboteur_lost[atk.owner]=True
                    atk.people.remove(p)
            self.release_reserve_slots(atk.owner,len(all_nonleaders))

            defender_victim=None
            if A==D and self.draw_winner=="defender":
                if b.regular_count()>0:
                    dead_pawn=next(p for p in b.people if p.regular)
                    if b.owner is not None:
                        self.record_taken(atk.owner,b.owner,[dead_pawn],False)
                        self.add_combat_marker(b.x,b.y,b.owner,["pawn"])
                        base_losses.append((b.owner,["pawn"]))
                    self.remove_one_regular(b.people)
                elif b.has_saboteur():
                    dead_sab=next(p for p in b.people if p.saboteur)
                    if b.owner is not None:
                        self.record_taken(atk.owner,b.owner,[dead_sab],False)
                        self.add_combat_marker(b.x,b.y,b.owner,["saboteur"])
                        base_losses.append((b.owner,["saboteur"]))
                        self.remove_one_saboteur(b.people,b.owner)
                # No special immunity for the attacking leader. A defender-win
                # tie destroys the attacking leader as well, exactly as a normal
                # failed all-in attack should.
                leader_lost=False
                if attacking_leader:
                    leader_person=next((p for p in atk.people if p.leader),None)
                    if leader_person is not None:
                        if b.owner is not None:
                            self.record_taken(b.owner,atk.owner,[leader_person],False)
                        self.add_combat_marker(b.x,b.y,atk.owner,["leader"])
                        base_losses.append((atk.owner,["leader"]))
                        atk.people.remove(leader_person)
                        leader_lost=True

                self.set_last_fight(
                    atk.owner,b.owner,A,D,
                    (f"P{b.owner+1} WINS TIE" if b.owner is not None else "BASE HOLDS TIE"),
                    base_losses
                )
                self.message+="tie: defender holds; attacking leader is not protected."

                # Any combat exhausts the entire shared movement pool.
                self.move_left=0
                self.action_taken=True

                if not atk.people and not atk.vehicle:
                    if atk in self.tokens:
                        self.tokens.remove(atk)
                    self.selected=None
                else:
                    self.selected=atk
                self.selected_person_idx=None

                if leader_lost:
                    self.eliminate_players_simultaneously([atk.owner])

            elif A==D and self.draw_winner=="attacker":
                # Attacker takes base, but loses one regular pawn from the assault.
                old=b.owner
                tie_losses=[]
                if old is not None and b.people:
                    d_kinds=self.combat_loss_kinds(b.people,False)
                    self.record_taken(atk.owner,old,b.people,False)
                    self.add_combat_marker(b.x,b.y,old,d_kinds)
                    tie_losses.append((old,d_kinds))
                if regs:
                    lost=regs[0]
                    if lost in atk.people:
                        self.add_combat_marker(b.x,b.y,atk.owner,["pawn"])
                        tie_losses.append((atk.owner,["pawn"]))
                        atk.people.remove(lost)
                elif attacking_saboteurs:
                    lost=attacking_saboteurs[0]
                    if lost in atk.people:
                        self.add_combat_marker(b.x,b.y,atk.owner,["saboteur"])
                        tie_losses.append((atk.owner,["saboteur"]))
                        self.saboteur_lost[atk.owner]=True
                        atk.people.remove(lost)

                b.people=[]
                b.owner=self.current

                for p in [q for q in list(atk.people) if not q.leader][:4]:
                    if len(b.people)>=4: break
                    atk.people.remove(p)
                    b.people.append(p)

                self.move_left=0
                self.action_taken=True
                self.set_last_fight(atk.owner,old,A,D,f"P{atk.owner+1} WINS TIE",tie_losses)
                self.message+=f"tie: {faction_name(atk.owner)} captures the base but loses one pawn."
                self.log_event("base_captured",base=[b.x,b.y],previous_owner=old,via_tie=True)

                if old is not None and old!=atk.owner:
                    self.eliminate_for_last_base(old)

                if not atk.people and not atk.vehicle:
                    if atk in self.tokens: self.tokens.remove(atk)
                    self.selected=b
                else:
                    self.selected=atk
                self.selected_person_idx=None

            else:
                # Strict defender win (A < D): every person committed to the
                # failed base assault is lost, INCLUDING the attacking leader.
                # Previously non-leaders were removed above but the leader
                # survived this branch, allowing immortal repeated base attacks.
                leader_lost=False
                if attacking_leader:
                    leader_person=next((p for p in atk.people if p.leader),None)
                    if leader_person is not None:
                        if b.owner is not None:
                            self.record_taken(b.owner,atk.owner,[leader_person],False)
                        self.add_combat_marker(b.x,b.y,atk.owner,["leader"])
                        base_losses.append((atk.owner,["leader"]))
                        atk.people.remove(leader_person)
                        leader_lost=True

                self.set_last_fight(
                    atk.owner,b.owner,A,D,
                    (f"P{b.owner+1} WINS" if b.owner is not None else "BASE HOLDS"),
                    base_losses
                )
                self.message+="defender wins; base holds."
                self.move_left=0
                self.action_taken=True

                if not atk.people:
                    if atk in self.tokens:
                        self.tokens.remove(atk)
                    self.selected=None
                else:
                    self.selected=atk
                self.selected_person_idx=None

                if leader_lost:
                    self.eliminate_players_simultaneously([atk.owner])

        self.check_victory()

    # ---------- harvest ----------
    def _reset_harvest_cycle(self,p):
        """Reset a player's personal four-tile harvest cycle.

        Tiles respawn only when physically empty, preserving the existing
        anti-camping rule.
        """
        self.harvest_marks[p]=0
        self.harvest_mid_offer[p]=False
        self.harvest_committed_to_four[p]=False
        for h in self.harvest_tiles:
            self.harvest_active[p][h]=False
            self.harvest_pending[p][h]=True

    def _complete_harvest_cycle(self,p):
        """Resolve a completed four-mark harvest cycle for the selected mode."""
        mode=self.harvest_reward_mode
        self.harvest_full_cycles[p]+=1
        cycle=self.harvest_full_cycles[p]
        self._reset_harvest_cycle(p)

        self.log_event(
            "harvest_cycle_complete",
            cycle=cycle,
            reward_mode=mode
        )

        if mode in ("ladder","clean_choice"):
            # These modes reserve the four-mark tier exclusively for manpower.
            results=[self.grant_new_pawn(p) for _ in range(3)]
            self.log_event(
                "reinforcement",
                reinforcement_type="3_pawns",
                harvest_marks=4,
                reward_mode=mode,
                results=results,
                reserve=self.reserve[p]
            )
            self.message=f"4 harvests: +3 pawns ({results.count('reserve')} to reserve)."
            return

        # CURRENT and CLASSIC keep the existing full-cycle reward choice.
        self.reinforcement_credits[p]+=1
        pawn_reward=3 if mode=="progressive" else 2
        self.log_event(
            "harvest_cycle_credit",
            credits=self.reinforcement_credits[p],
            cycle=cycle,
            reward_mode=mode
        )
        self.message=(
            f"Harvest cycle complete. Choose +{pawn_reward} pawns, "
            "+1 vehicle"
            + (", or recover Saboteur." if self.saboteur_lost[p] else ".")
        )

    def _evaluate_harvest_threshold(self,p,start_marks):
        """Evaluate harvest rewards once after all end-turn harvests are collected."""
        mode=self.harvest_reward_mode
        marks=self.harvest_marks[p]

        if marks>=4:
            self._complete_harvest_cycle(p)
            return

        if mode=="classic":
            return

        # CLEAN: exactly two offers pawn / vehicle / Saboteur / push.
        if mode=="clean_choice":
            if marks==2 and start_marks<2 and not self.harvest_committed_to_four[p]:
                self.harvest_mid_offer[p]=True
                self.log_event("harvest_mid_offer",marks=2,reward_mode=mode)
                self.message="2 harvests: choose a reward now, or push to 4."
                return

            # Crossing beyond two in the same collection means the player
            # implicitly pushed instead of taking the two-mark reward.
            if marks>2 and not self.harvest_committed_to_four[p]:
                self.harvest_mid_offer[p]=False
                self.harvest_committed_to_four[p]=True
                self.log_event(
                    "harvest_auto_push",
                    from_marks=start_marks,
                    marks=marks,
                    target=4,
                    reward_mode=mode
                )
                self.message=f"{marks} harvests secured — automatically pushed to 4."
            return

        # CURRENT and LADDER share the 2-mark pawn-or-push decision.
        if marks==2 and start_marks<2 and not self.harvest_committed_to_four[p]:
            self.harvest_mid_offer[p]=True
            self.log_event("harvest_mid_offer",marks=2,reward_mode=mode)
            self.message="2 harvests: take +1 pawn now, or push."
            return

        # If the player crossed the 2-mark threshold in one batch, occupying
        # the third harvest is an implicit push beyond the 2-mark cash-out.
        if marks>2 and not self.harvest_committed_to_four[p]:
            self.harvest_mid_offer[p]=False
            self.harvest_committed_to_four[p]=True
            self.log_event(
                "harvest_auto_push",
                from_marks=start_marks,
                marks=marks,
                target=3 if mode=="ladder" else 4,
                reward_mode=mode
            )

        # LADDER has a second checkpoint at three marks.
        if mode=="ladder" and marks==3:
            self.harvest_mid_offer[p]=True
            self.log_event("harvest_mid_offer",marks=3,reward_mode=mode)
            self.message=(
                "3 harvests: take +1 vehicle"
                + (" / recover Saboteur" if self.saboteur_lost[p] else "")
                + ", or push to 4."
            )
            return

        if marks>2:
            self.message=f"{marks} harvests secured — pushed toward 4."

    def collect_harvest(self,p,pos):
        """Compatibility helper for a single harvest collection."""
        if not self.harvest_active[p].get(pos,False):
            return
        start_marks=self.harvest_marks[p]
        self.harvest_active[p][pos]=False
        self.harvest_marks[p]+=1
        self.log_event("harvest",tile=list(pos),marks=self.harvest_marks[p])
        self.message=f"Harvest secured ({self.harvest_marks[p]}/4)."
        self._evaluate_harvest_threshold(p,start_marks)

    def resolve_mid_harvest_choice(self,choice):
        """Resolve CURRENT / LADDER / CLEAN harvest checkpoint decisions."""
        p=self.current
        mode=self.harvest_reward_mode
        marks=self.harvest_marks[p]

        if mode=="classic" or not self.harvest_mid_offer[p]:
            return False

        def finish_checkpoint(reward,result=None):
            self.harvest_cashouts[p]+=1
            self.log_event(
                "harvest_checkpoint_reward",
                marks=marks,
                reward=reward,
                result=result,
                reward_mode=mode,
                cashouts=self.harvest_cashouts[p]
            )
            self._reset_harvest_cycle(p)

        # ---- 2 marks ----
        if marks==2:
            if choice in ("cashout","pawn"):
                result=self.grant_new_pawn(p)
                finish_checkpoint("1_pawn",result)
                self.log_event(
                    "reinforcement",
                    reinforcement_type="1_pawn",
                    harvest_marks=2,
                    reward_mode=mode,
                    result=result
                )
                self.message=(
                    "+1 pawn harvest reward"
                    + (" (reserve)." if result=="reserve" else ".")
                )
                return True

            if mode=="clean_choice" and choice=="vehicle":
                result=self.grant_new_vehicle(p)
                finish_checkpoint("vehicle",result)
                self.log_event(
                    "reinforcement",
                    reinforcement_type="vehicle",
                    harvest_marks=2,
                    reward_mode=mode,
                    result=result
                )
                self.message=(
                    "2 harvests: +1 vehicle"
                    + (" (reserve)." if result=="reserve" else ".")
                )
                return True

            if mode=="clean_choice" and choice=="saboteur":
                result=self.grant_new_saboteur(p)
                if result=="base":
                    finish_checkpoint("saboteur",result)
                    self.log_event(
                        "reinforcement",
                        reinforcement_type="recover_saboteur",
                        harvest_marks=2,
                        reward_mode=mode
                    )
                    self.message="2 harvests: Saboteur recovered."
                    return True
                if result=="no_space":
                    self.message="Recover Saboteur: free one base slot first."
                else:
                    self.message="Your Saboteur is already active."
                return False

            if choice=="push":
                self.harvest_mid_offer[p]=False
                self.harvest_committed_to_four[p]=True
                target=3 if mode=="ladder" else 4
                self.log_event(
                    "harvest_push",
                    marks=2,
                    target=target,
                    reward_mode=mode
                )
                self.message=f"Harvest pushed to {target}."
                return True

            return False

        # ---- 3 marks: LADDER only ----
        if mode=="ladder" and marks==3:
            if choice=="vehicle":
                result=self.grant_new_vehicle(p)
                finish_checkpoint("vehicle",result)
                self.log_event(
                    "reinforcement",
                    reinforcement_type="vehicle",
                    harvest_marks=3,
                    reward_mode=mode,
                    result=result
                )
                self.message=(
                    "3 harvests: +1 vehicle"
                    + (" (reserve)." if result=="reserve" else ".")
                )
                return True

            if choice=="saboteur":
                result=self.grant_new_saboteur(p)
                if result=="base":
                    finish_checkpoint("saboteur",result)
                    self.log_event(
                        "reinforcement",
                        reinforcement_type="recover_saboteur",
                        harvest_marks=3,
                        reward_mode=mode
                    )
                    self.message="3 harvests: Saboteur recovered."
                    return True
                if result=="no_space":
                    self.message="Recover Saboteur: free one base slot first."
                else:
                    self.message="Your Saboteur is already active."
                return False

            if choice=="push":
                self.harvest_mid_offer[p]=False
                self.harvest_committed_to_four[p]=True
                self.log_event(
                    "harvest_push",
                    marks=3,
                    target=4,
                    reward_mode=mode
                )
                self.message="Harvest pushed to 4 for +3 pawns."
                return True

        return False

    def resolve_harvest_respawns(self,p):
        for h in self.harvest_tiles:
            if not self.harvest_pending[p][h]: continue
            occupied=self.token_at(*h) is not None
            if not occupied:
                self.harvest_pending[p][h]=False
                self.harvest_active[p][h]=True

    # ---------- reinforcements ----------
    def grant_new_saboteur(self,p):
        if not self.saboteur_lost[p]:
            return "already_active"
        for b in self.controlled_bases(p):
            if len(b.people)<4:
                b.people.append(Person(p,False,True))
                self.saboteur_lost[p]=False
                return "base"
        return "no_space"

    def spawn_reinforcement(self,choice):
        p=self.current
        if self.reinforcement_credits[p]<=0:
            return
        if not self.controlled_bases(p):
            self.message="Credit held: you need a base."
            return

        if choice=="pawns":
            count=3 if self.harvest_reward_mode=="progressive" else 2
            results=[self.grant_new_pawn(p) for _ in range(count)]
            self.reinforcement_credits[p]-=1
            self.log_event(
                "reinforcement",
                reinforcement_type=f"{count}_pawns",
                results=results,
                reserve=self.reserve[p]
            )
            self.message=f"+{count} pawns: {results.count('reserve')} to reserve."

        elif choice=="vehicle":
            result=self.grant_new_vehicle(p)
            self.reinforcement_credits[p]-=1
            self.log_event(
                "reinforcement",
                reinforcement_type="vehicle",
                result=result,
                reserve_vehicles=self.reserve_vehicles[p]
            )
            self.message=(
                "Vehicle reinforcement: "
                + ("placed." if result=="outside" else "sent to reserve.")
            )

        elif choice=="saboteur":
            result=self.grant_new_saboteur(p)
            if result=="base":
                self.reinforcement_credits[p]-=1
                self.log_event(
                    "reinforcement",
                    reinforcement_type="recover_saboteur"
                )
                self.message="Saboteur recovered in a controlled base."
            elif result=="no_space":
                self.message="Recover Saboteur: free one base slot first."
            else:
                self.message="Your Saboteur is already active."

def board_offset(grid):
    spare=(MAX_GRID-grid)*CELL
    return MARGIN+spare//2, TOP+spare//2

def cell_rect(x,y,grid=MAX_GRID):
    ox,oy=board_offset(grid)
    return pygame.Rect(ox+x*CELL,oy+y*CELL,CELL,CELL)

def cell_center(x,y,grid=MAX_GRID):
    return cell_rect(x,y,grid).center

def draw_text(s,pos,f=None,color=TEXT): screen.blit((f or font).render(str(s),True,color),pos)

def draw_harvest_glyph(kind,center,color,size=18,width=2):
    """Simple harvest silhouettes.
    width=0 -> filled / lit version.
    width>0 -> outline/muted version.
    """
    cx,cy=center
    s=size
    filled=(width==0)
    line_w=max(1,width)

    if kind=="forest":
        tri1=[(cx,cy-s//2),(cx-s//3,cy-s//8),(cx+s//3,cy-s//8)]
        tri2=[(cx,cy-s//4),(cx-s//2+1,cy+s//7),(cx+s//2-1,cy+s//7)]
        trunk=pygame.Rect(cx-max(2,s//10),cy+s//7,max(4,s//5),max(4,s//4))
        if filled:
            pygame.draw.polygon(screen,color,tri1,0)
            pygame.draw.polygon(screen,color,tri2,0)
            pygame.draw.rect(screen,color,trunk,0)
        else:
            pygame.draw.polygon(screen,color,tri1,line_w)
            pygame.draw.polygon(screen,color,tri2,line_w)
            pygame.draw.rect(screen,color,trunk,line_w)

    elif kind=="fish":
        body=pygame.Rect(cx-s//2+2,cy-s//4,s-6,max(8,s//2))
        tail=[(cx+s//2-4,cy),(cx+s//2+4,cy-s//4),(cx+s//2+4,cy+s//4)]
        eye=(cx-s//5,cy-1)
        if filled:
            pygame.draw.ellipse(screen,color,body,0)
            pygame.draw.polygon(screen,color,tail,0)
            pygame.draw.circle(screen,BG,eye,1)
        else:
            pygame.draw.ellipse(screen,color,body,line_w)
            pygame.draw.polygon(screen,color,tail,line_w)
            pygame.draw.circle(screen,color,eye,1)

    elif kind=="oil":
        # Replaced with a simple mountain silhouette.
        left=(cx-s//2, cy+s//3)
        peak=(cx-s//10, cy-s//2)
        right=(cx+s//2, cy+s//3)
        ridge=(cx+s//8, cy-s//8)
        if filled:
            pygame.draw.polygon(screen,color,[left, peak, ridge, right],0)
        else:
            pygame.draw.lines(screen,color,False,[left, peak, ridge, right],line_w)
            pygame.draw.line(screen,color,left,right,line_w)

    elif kind=="factory":
        # Clearer triangular/sawtooth roof with a much taller far-right chimney.
        left=cx-s//2
        right=cx+s//2
        bottom=cy+s//3
        roof_y=cy-s//12
        p1=(cx-s//5, roof_y-s//4)
        p2=(cx+s//18, roof_y)
        p3=(cx+s//4, roof_y-s//4)
        poly=[(left,bottom),(left,roof_y),(p1[0],p1[1]),(p2[0],p2[1]),(p3[0],p3[1]),(right,roof_y),(right,bottom)]
        chim_w=max(3,s//7+2)
        chim_h=max(9,s//2+1)
        chim=pygame.Rect(right-chim_w+1, cy-s//2-s//6, chim_w, chim_h)
        w1=pygame.Rect(cx-s//5,bottom-s//6,max(2,s//8+1),max(2,s//8+1))
        w2=pygame.Rect(cx+1,bottom-s//6,max(2,s//8+1),max(2,s//8+1))
        if filled:
            pygame.draw.polygon(screen,color,poly,0)
            pygame.draw.rect(screen,color,chim,0)
            pygame.draw.rect(screen,BG,w1,0)
            pygame.draw.rect(screen,BG,w2,0)
        else:
            pygame.draw.lines(screen,color,False,poly,line_w)
            pygame.draw.line(screen,color,(left,bottom),(right,bottom),line_w)
            pygame.draw.rect(screen,color,chim,line_w)
            pygame.draw.rect(screen,color,w1,line_w)
            pygame.draw.rect(screen,color,w2,line_w)

def wrap_text(text,width=None):
    width=width or WRAP
    words=text.split(); lines=[]; line=""
    for w in words:
        test=(line+" "+w).strip()
        if len(test)>width:
            if line: lines.append(line)
            line=w
        else: line=test
    if line: lines.append(line)
    return lines

def container_slot_rects(px,y0):
    size=SLOT; gap=10
    return [
        pygame.Rect(px,y0,size,size),
        pygame.Rect(px+size+gap,y0,size,size),
        pygame.Rect(px,y0+size+gap,size,size),
        pygame.Rect(px+size+gap,y0+size+gap,size,size)
    ]

def draw_container_panel(g,px,y0):
    obj=g.selected
    people=g.container_people(obj)
    if people is None or getattr(obj,"owner",None)!=g.current:
        return []
    title="BASE" if isinstance(obj,Base) else "VEHICLE"
    draw_text(title,(px,y0),font_small,MUTED)
    slots=container_slot_rects(px,y0+24)
    for i,r in enumerate(slots):
        pygame.draw.rect(screen,SLOT_BG,r)
        pygame.draw.rect(screen,SELECT if g.selected_person_idx==i else MUTED,r,2 if g.selected_person_idx==i else 1)
        if i<len(people):
            p=people[i]
            c=PLAYER_COLORS[p.owner]
            cx,cy=r.center
            if p.leader:
                pygame.draw.polygon(screen,c,[(cx,cy-14),(cx-13,cy+11),(cx+13,cy+11)],3)
            elif p.saboteur:
                pygame.draw.polygon(screen,c,[(cx,cy-14),(cx+12,cy),(cx,cy+14),(cx-12,cy)],3)
            else:
                pygame.draw.circle(screen,c,(cx,cy),13,3)
    draw_text("Tap slot, then tile",(px,y0+158),font_small,MUTED)
    return slots

def draw_combat_markers(g):
    """Faction-colored X marks for recent casualties."""
    grouped={}
    for m in g.combat_markers:
        key=(m["x"],m["y"],m["owner"])
        grouped[key]=grouped.get(key,0)+max(1,len(m.get("kinds",[])))

    by_tile={}
    for (x,y,owner),count in grouped.items():
        by_tile.setdefault((x,y),[]).append((owner,count))

    offsets=[(-11,-11),(11,-11),(-11,11),(11,11)]
    for (x,y),entries in by_tile.items():
        cx,cy=cell_center(x,y,g.grid)
        for i,(owner,count) in enumerate(entries[:4]):
            ox,oy=offsets[i]
            px,py=cx+ox,cy+oy
            c=PLAYER_COLORS[owner]
            pygame.draw.line(screen,BG,(px-5,py-5),(px+5,py+5),5)
            pygame.draw.line(screen,BG,(px+5,py-5),(px-5,py+5),5)
            pygame.draw.line(screen,c,(px-5,py-5),(px+5,py+5),3)
            pygame.draw.line(screen,c,(px+5,py-5),(px-5,py+5),3)
            if count>1:
                draw_text(str(count),(px+6,py-10),font_small,c)

def draw_rich_line(parts,x,y,f=None):
    """Draw [(text,color), ...] as one horizontal line."""
    ff=f or font_small
    px=x
    for text,color in parts:
        surf=ff.render(str(text),True,color)
        screen.blit(surf,(px,y))
        px+=surf.get_width()
    return px

def player_part(p,label=None):
    if p is None:
        return ("NEUTRAL",MUTED)
    return (label or faction_name(p),PLAYER_COLORS[p])

def draw_last_fight(g,x,y):
    lf=g.last_fight
    if not lf:
        return

    draw_text("LAST FIGHT:",(x,y),font_small,MUTED)

    # In CPU mode Player 1 is the human viewer even when the game ended
    # during a bot turn. Hotseat keeps the current-player perspective.
    omniscient=False
    # Default sidebar perspective during live play.
    # Replay mode may override this below.
    view_player=g.current

    if getattr(g,"replay_mode",False):
        mode=getattr(g,"replay_view_mode","you")
        omniscient=(mode=="omniscient")
        viewer=(
            g.current if mode=="turn"
            else getattr(g,"human_player",0)
        )
    else:
        viewer=(
            getattr(g,"human_player",0)
            if getattr(g,"basic_bot",False) else g.current
        )
    attacker=lf["attacker"]
    defender=lf["defender"]
    involved=omniscient or viewer in (attacker,defender)

    a_text,a_col=player_part(attacker)
    d_text,d_col=player_part(defender)
    if defender is None and lf.get("base"):
        d_text="NEUTRAL BASE"

    if involved:
        draw_rich_line([
            (a_text,a_col),
            (f" ATK {lf['atk']}  vs  ",TEXT),
            (d_text,d_col),
            (f" {'DEF' if lf.get('base') else 'ATK'} {lf['def']}",TEXT),
        ],x,y+18,font_small)
    else:
        # Third parties learn only that combat happened and who won.
        draw_rich_line([
            (a_text,a_col),(" fought ",TEXT),(d_text,d_col)
        ],x,y+18,font_small)

    winner=lf.get("winner")
    if winner is None:
        draw_text("No surviving winner",(x,y+36),font_small,MUTED)
    else:
        w_text,w_col=player_part(winner)
        draw_rich_line([(w_text,w_col),(" wins",TEXT)],x,y+36,font_small)

    # Casualty/composition details are private to combat participants.
    if involved:
        parts=[]
        for owner,kinds in lf["losses"]:
            bits=[]
            n=kinds.count("pawn")
            if n: bits.append(f"{n} pawn" + ("" if n==1 else "s"))
            n=kinds.count("leader")
            if n: bits.append(f"{n} leader" + ("" if n==1 else "s"))
            n=kinds.count("vehicle")
            if n: bits.append(f"{n} vehicle" + ("" if n==1 else "s"))
            n=kinds.count("saboteur")
            if n: bits.append(f"{n} Saboteur" + ("" if n==1 else "s"))
            if bits:
                parts.append((owner,", ".join(bits)))

        if parts:
            px=x
            for i,(owner,desc) in enumerate(parts):
                if i:
                    sep="  |  "
                    surf=font_small.render(sep,True,MUTED)
                    screen.blit(surf,(px,y+54)); px+=surf.get_width()
                label=faction_name(owner)
                surf=font_small.render(label,True,PLAYER_COLORS[owner])
                screen.blit(surf,(px,y+54)); px+=surf.get_width()
                rest=f" lost {desc}"
                surf=font_small.render(rest,True,MUTED)
                screen.blit(surf,(px,y+54)); px+=surf.get_width()

def draw_taken_strip(g,x,y):
    """Compact chess-like list of pieces taken by the current player."""
    draw_text("TAKEN:",(x,y),font_small,MUTED)
    items=g.taken[g.current]
    start_x=x+68
    cy=y+9
    gap=22

    # Keep the strip compact on tablet. Oldest pieces remain represented via +N.
    max_icons=8 if LAYOUT_MODE=="tablet" else 10
    shown=items[:max_icons]
    for i,item in enumerate(shown):
        px=start_x+i*gap
        c=PLAYER_COLORS[item["owner"]]
        kind=item["kind"]
        if kind=="pawn":
            pygame.draw.circle(screen,c,(px,cy),6,2)
        elif kind=="vehicle":
            pygame.draw.rect(screen,c,pygame.Rect(px-6,cy-6,12,12),2)
        elif kind=="saboteur":
            pygame.draw.polygon(screen,c,[(px,cy-7),(px+7,cy),(px,cy+7),(px-7,cy)],2)
        else:
            pygame.draw.polygon(screen,c,[(px,cy-7),(px-7,cy+6),(px+7,cy+6)],2)

    tail_x=start_x+len(shown)*gap
    if len(items)>max_icons:
        draw_text(f"+{len(items)-max_icons}",(tail_x-2,y-1),font_small,MUTED)
        tail_x+=34

    # Captured empty vehicles are loot, not kills; only show this if it happened.
    captured=g.captured_vehicles[g.current]
    if captured:
        draw_text(" C:",(tail_x,y-1),font_small,MUTED)
        tail_x+=28
        # Usually this is only one vehicle, but keep it safe and compact.
        for owner in captured[:3]:
            c=PLAYER_COLORS[owner]
            pygame.draw.rect(screen,c,pygame.Rect(tail_x-5,cy-5,10,10),2)
            tail_x+=17
        if len(captured)>3:
            draw_text(f"+{len(captured)-3}",(tail_x,y-1),font_small,MUTED)

def draw_game(g):
    screen.fill(BG)

    # Resolve the information perspective ONCE, before anything in the board or
    # sidebar is rendered. This fixes live-play access to view_player and keeps
    # bases/tokens/harvests consistent across all replay modes.
    replay_mode=getattr(g,"replay_mode",False)
    replay_view_mode=getattr(g,"replay_view_mode","you")
    omniscient_view=(replay_mode and replay_view_mode=="omniscient")

    if replay_mode and replay_view_mode=="turn":
        view_player=g.current
    elif replay_mode:
        view_player=getattr(g,"human_player",0)
    else:
        view_player=g.current

    for y in range(g.grid):
        for x in range(g.grid):
            pygame.draw.rect(screen,GRID_C,cell_rect(x,y,g.grid),1)

    kind_map=g.harvest_kind_map()
    for h in g.harvest_tiles:
        active=g.harvest_active[view_player][h]
        pending=g.harvest_pending[view_player][h]
        cx,cy=cell_center(*h,g.grid)
        col=HARVEST_ON if active else HARVEST_OFF
        draw_harvest_glyph(kind_map[h],(cx,cy),col,size=ps(20),width=0 if active else 2)
        if pending:
            pygame.draw.circle(screen,HARVEST_OFF,(cx,cy),ps(13),1)

    for pos,b in g.bases.items():
        r=cell_rect(*pos,g.grid).inflate(-ps(8),-ps(8))
        c=BASE_NEUTRAL if b.owner is None else PLAYER_COLORS[b.owner]
        pygame.draw.rect(screen,c,r,ps(3))
        if not g.privacy and (
            omniscient_view or b.owner==view_player or g.reveal_debug
        ):
            draw_text(f"B{b.defense()}",(r.x+ps(4),r.y+ps(4)),font_small,c)
        if g.selected is b:
            pygame.draw.rect(screen,SELECT,cell_rect(b.x,b.y,g.grid).inflate(-3,-3),2)

    if not g.privacy:
        for t in g.tokens:
            cx,cy=cell_center(t.x,t.y,g.grid)
            own=(
                omniscient_view
                or t.owner==view_player
                or g.reveal_debug
            )
            c=PLAYER_COLORS[t.owner]

            if own:
                if t.vehicle:
                    pygame.draw.rect(screen,c,pygame.Rect(cx-ps(12),cy-ps(12),ps(24),ps(24)),ps(3))
                    if t.people:
                        draw_text(str(t.strength()),(cx-5,cy-8),font_small if PS<1.2 else font,c)
                elif t.has_leader() and len(t.people)==1:
                    pygame.draw.polygon(screen,c,[(cx,cy-ps(14)),(cx-ps(13),cy+ps(11)),(cx+ps(13),cy+ps(11))],ps(3))
                elif t.has_saboteur() and len(t.people)==1:
                    pygame.draw.polygon(screen,c,[(cx,cy-ps(14)),(cx+ps(13),cy),(cx,cy+ps(14)),(cx-ps(13),cy)],ps(3))
                else:
                    pygame.draw.circle(screen,c,(cx,cy),ps(13),ps(3))
                    draw_text(str(t.strength()),(cx-5,cy-8),font_small if PS<1.2 else font,c)
                    if t.has_saboteur():
                        pygame.draw.polygon(screen,c,[(cx+ps(10),cy-ps(12)),(cx+ps(14),cy-ps(8)),(cx+ps(10),cy-ps(4)),(cx+ps(6),cy-ps(8))],1)
            else:
                # Enemy field units are deliberately generic: faction is public,
                # composition is not. A SOLID circle means "unknown enemy unit",
                # distinct from the hollow circle used for your own pawn/team.
                pygame.draw.circle(screen,c,(cx,cy),ps(11),0)

            if g.selected is t:
                pygame.draw.rect(screen,SELECT,cell_rect(t.x,t.y,g.grid).inflate(-3,-3),2)

    # Recent combat deaths stay visible briefly on the board.
    draw_combat_markers(g)

    # Reachability hints are deliberately drawn LAST over board graphics,
    # so harvest emblems / bases / pieces never hide them.
    if not g.privacy and isinstance(g.selected,Token) and g.selected.owner==g.current:
        c=PLAYER_COLORS[g.current]

        for rx,ry in g.reachable_empty_tiles(g.selected):
            cx,cy=cell_center(rx,ry,g.grid)
            # dark halo + player-color core keeps the marker readable over icons
            pygame.draw.circle(screen,BG,(cx,cy),ps(6))
            pygame.draw.circle(screen,c,(cx,cy),ps(4))

        friendly_targets,hostile_targets=g.reachable_interaction_targets(g.selected)

        for rx,ry in friendly_targets:
            cx,cy=cell_center(rx,ry,g.grid)
            pygame.draw.circle(screen,BG,(cx,cy),ps(7))
            pygame.draw.circle(screen,c,(cx,cy),ps(5))

        for rx,ry in hostile_targets:
            cx,cy=cell_center(rx,ry,g.grid)
            pts=[(cx,cy-ps(8)),(cx+ps(8),cy),(cx,cy+ps(8)),(cx-ps(8),cy)]
            pygame.draw.polygon(screen,BG,pts,ps(4))
            pts=[(cx,cy-ps(7)),(cx+ps(7),cy),(cx,cy+ps(7)),(cx-ps(7),cy)]
            pygame.draw.polygon(screen,c,pts,ps(2))

    # Reachability preview for a selected person inside a base or vehicle.
    if (
        not g.privacy
        and g.selected_person_idx is not None
        and g.container_people(g.selected) is not None
        and getattr(g.selected,"owner",None)==g.current
    ):
        c=PLAYER_COLORS[g.current]
        empty_tiles,friendly_targets=g.reachable_container_destinations(
            g.selected,g.selected_person_idx
        )

        for rx,ry in empty_tiles:
            cx,cy=cell_center(rx,ry,g.grid)
            pygame.draw.circle(screen,BG,(cx,cy),6)
            pygame.draw.circle(screen,c,(cx,cy),4)

        for rx,ry in friendly_targets:
            cx,cy=cell_center(rx,ry,g.grid)
            pygame.draw.circle(screen,BG,(cx,cy),7)
            pygame.draw.circle(screen,c,(cx,cy),5)

    # ---------- header row: title, player, turn ----------
    tx,ty,tsize=L["title"]
    if tsize=="big":
        draw_text(f"GDG MINI — v{VERSION}",(tx,ty),font_big,TEXT)
    else:
        draw_text(f"GDG MINI v{VERSION}",(tx,ty),font_small,MUTED)
    if getattr(g,"replay_mode",False):
        mode=getattr(g,"replay_view_mode","you")
        if mode=="omniscient":
            replay_viewer=getattr(g,"human_player",0)
            replay_label="OMNISCIENT VIEW"
            draw_text(replay_label,L["player"],font,MUTED)
            # Sidebar still uses the human faction's economy/status counters;
            # the board/fight information itself is fully revealed.
            view_player=replay_viewer
        else:
            replay_viewer=(
                g.current if mode=="turn"
                else getattr(g,"human_player",0)
            )
            replay_label=(
                f"TURN VIEW: {faction_name(replay_viewer)}"
                if mode=="turn"
                else f"YOUR VIEW: {faction_name(replay_viewer)}"
            )
            draw_text(replay_label,L["player"],font,PLAYER_COLORS[replay_viewer])
            view_player=replay_viewer
    else:
        draw_text(faction_name(g.current),L["player"],font,PLAYER_COLORS[g.current])
        view_player=g.current
    turn_surface=font.render(f"Turn {g.global_turn}",True,TEXT)
    screen.blit(turn_surface,(L["turn_right"][0]-turn_surface.get_width(),L["turn_right"][1]))

    # ---------- status ----------
    sx=L["status_x"]
    draw_text("MOVE LEFT",(sx,L["y_move_label"]),font_small,MUTED)
    draw_text(str(g.move_left),(sx,L["y_move_num"]),font_move,TEXT)

    draw_text(f"Visible units: {g.visible_units(view_player)}/{g.unit_cap}",(sx,L["y_visible"]))
    draw_text("Harvest:",(sx,L["y_harvest"]))
    for i,h in enumerate(g.harvest_tiles):
        kind=HARVEST_ORDER[i]
        collected=g.harvest_collected_this_cycle(view_player,h)
        active=g.harvest_active[g.current][h]
        pending=g.harvest_pending[g.current][h]
        icon_color=HARVEST_ON if collected else (MUTED if active else HARVEST_OFF)
        draw_harvest_glyph(kind,(sx+L["harvest_dx"]+i*L["harvest_step"],L["y_harvest"]+11),icon_color,size=18,width=0 if collected or active else 1)
        if pending:
            pygame.draw.circle(screen,HARVEST_OFF,(sx+L["harvest_dx"]+i*L["harvest_step"],L["y_harvest"]+11),13,1)
    draw_text(f"Bases: {len(g.controlled_bases(view_player))}",(sx,L["y_bases"]))
    draw_taken_strip(g,sx,L["y_taken"])
    if L["y_config"] is not None:
        move_rule=("1+B+U" if g.base_movement else f"base {g.base_move}")
        draw_text(f"{g.grid}x{g.grid} | {move_rule} | cap {g.unit_cap}",(sx,L["y_config"]),font_small,MUTED)
    for ly,text in L["legend"]:
        draw_text(text,(sx,ly),font_small,MUTED)

    # Visual reserve. PC uses one sequential sidebar flow so sections can
    # never collide when spacing above changes.
    if LAYOUT_MODE=="pc":
        reserve_label_y=L["y_taken"]+42
        reserve_icons_y=reserve_label_y+24
    else:
        reserve_label_y=L["y_reserve_label"]
        reserve_icons_y=L["y_reserve_icons"]
    draw_text("RESERVE:",(sx,reserve_label_y),font_small,MUTED)
    rx=sx; ry=reserve_icons_y
    reserve_icons=[]
    for _ in range(g.reserve[g.current]):
        reserve_icons.append("pawn")
    for _ in range(g.reserve_vehicles[g.current]):
        reserve_icons.append("vehicle")
    for i,kind in enumerate(reserve_icons[:12]):
        cx=rx+(i%6)*34+13
        cy=ry+(i//6)*34+13
        c=PLAYER_COLORS[g.current]
        if kind=="pawn":
            pygame.draw.circle(screen,c,(cx,cy),9,2)
        else:
            pygame.draw.rect(screen,c,pygame.Rect(cx-9,cy-9,18,18),2)
    if len(reserve_icons)>12:
        draw_text(f"+{len(reserve_icons)-12}",(rx+210,ry+36),font_small,MUTED)

    # ---------- last fight + message + container panel ----------
    mx,my=L["msg"]; lh=L["msg_line_h"]
    if LAYOUT_MODE=="pc":
        # Reserve is capped/small; Last Fight begins after its icon row, then
        # Message follows the fixed-height fight block. No guessed overlap.
        fight_y=reserve_icons_y+46
        my=fight_y+82
    else:
        fight_y=my-82
    draw_last_fight(g,mx,fight_y)
    draw_text("Message:",(mx,my),font_small,MUTED)
    y=my
    message_lines=wrap_text(g.message)
    for line in message_lines[:4]:
        y+=lh
        draw_text(line,(mx,y),font_small)
    if len(message_lines)>4:
        y+=lh
        draw_text("...",(mx,y),font_small,MUTED)

    slot_rects=draw_container_panel(g,*L["container"])

    buttons={}
    popup_buttons={}
    over=g.winner is not None or g.draw

    # End turn button.
    end_r=L["end"]
    end_enabled=(not getattr(g,"replay_mode",False)) and g.end_turn_allowed()
    pygame.draw.rect(screen,(55,58,62) if end_enabled else (38,39,41),end_r)
    pygame.draw.rect(screen,TEXT if end_enabled else MUTED,end_r,1)
    draw_center(L["end_label"],end_r.center,font if LAYOUT_MODE!="pc" else font_small,TEXT if end_enabled else MUTED)
    buttons["end"]=end_r

    # Restart: goes back to the setup screen; needs a second tap mid-game.
    rs_r=L["restart"]
    armed=(not over) and pygame.time.get_ticks()<UI["restart_until"]
    pygame.draw.rect(screen,(92,52,52) if armed else (47,50,54),rs_r)
    pygame.draw.rect(screen,TEXT if armed else MUTED,rs_r,1)
    draw_center("TAP AGAIN" if armed else "RESTART",rs_r.center,font_small,TEXT if armed else MUTED)
    buttons["restart"]=rs_r

    # Harvest checkpoint reward modal.
    show_mid_harvest_popup = (
        g.harvest_reward_mode in ("progressive","ladder","clean_choice")
        and g.harvest_mid_offer[g.current]
        and not g.privacy
        and g.winner is None
        and not g.draw
        and not getattr(g,"replay_mode",False)
    )

    if show_mid_harvest_popup:
        board_left,board_top=board_offset(g.grid)
        board_w=g.grid*CELL
        board_h=g.grid*CELL
        marks=g.harvest_marks[g.current]
        mode=g.harvest_reward_mode

        overlay=pygame.Surface((board_w,board_h),pygame.SRCALPHA)
        overlay.fill((0,0,0,150))
        screen.blit(overlay,(board_left,board_top))

        pop_w=520 if mode=="clean_choice" and marks==2 else 460
        pop_h=210
        pop_x=board_left+(board_w-pop_w)//2
        pop_y=board_top+(board_h-pop_h)//2
        pop=pygame.Rect(pop_x,pop_y,pop_w,pop_h)

        pygame.draw.rect(screen,(38,40,43),pop)
        pygame.draw.rect(screen,TEXT,pop,2)

        draw_center(f"{marks} HARVESTS SECURED",(pop.centerx,pop.y+36),font_big,TEXT)

        options=[]
        if marks==2 and mode in ("progressive","ladder"):
            draw_center(
                "Take +1 pawn now, or keep building the harvest.",
                (pop.centerx,pop.y+75),font_small,MUTED
            )
            options=[
                ("harvest_cashout","TAKE +1 PAWN"),
                ("harvest_push","PUSH TO 3" if mode=="ladder" else "PUSH TO 4"),
            ]
        elif marks==2 and mode=="clean_choice":
            draw_center(
                "Take a reward now, or push to 4 for +3 pawns.",
                (pop.centerx,pop.y+75),font_small,MUTED
            )
            options=[
                ("harvest_cashout","+1 PAWN"),
                ("harvest_vehicle","+1 VEHICLE"),
            ]
            if g.saboteur_lost[g.current]:
                options.append(("harvest_saboteur","SABOTEUR"))
            options.append(("harvest_push","PUSH TO 4"))
        elif marks==3 and mode=="ladder":
            draw_center(
                "Take the specialist reward, or push once more for +3 pawns.",
                (pop.centerx,pop.y+75),font_small,MUTED
            )
            options=[("harvest_vehicle","+1 VEHICLE")]
            if g.saboteur_lost[g.current]:
                options.append(("harvest_saboteur","SABOTEUR"))
            options.append(("harvest_push","PUSH TO 4"))

        if options:
            gap=10
            total_w=pop_w-36
            bw=(total_w-gap*(len(options)-1))//len(options)
            by=pop.y+118
            for i,(key,label) in enumerate(options):
                r=pygame.Rect(pop.x+18+i*(bw+gap),by,bw,62)
                pygame.draw.rect(screen,(55,58,62),r)
                pygame.draw.rect(screen,TEXT,r,1)
                draw_center(label,r.center,font_small,TEXT)
                popup_buttons[key]=r

    # Reinforcement choice becomes a modal over the board.
    show_reinforcement_popup = (
        not show_mid_harvest_popup
        and g.reinforcement_credits[g.current] > 0
        and bool(g.controlled_bases(g.current))
        and not g.privacy
        and g.winner is None
        and not g.draw
        and not getattr(g,"replay_mode",False)
    )

    if show_reinforcement_popup:
        board_left,board_top=board_offset(g.grid)
        board_w=g.grid*CELL
        board_h=g.grid*CELL

        overlay=pygame.Surface((board_w,board_h),pygame.SRCALPHA)
        overlay.fill((0,0,0,150))
        screen.blit(overlay,(board_left,board_top))

        pop_w=390
        pop_h=190
        pop_x=board_left+(board_w-pop_w)//2
        pop_y=board_top+(board_h-pop_h)//2
        pop=pygame.Rect(pop_x,pop_y,pop_w,pop_h)

        pygame.draw.rect(screen,(38,40,43),pop)
        pygame.draw.rect(screen,TEXT,pop,2)

        draw_center("REINFORCEMENT",(pop.centerx,pop.y+38),font_big,TEXT)
        draw_center("Choose your harvest reward",(pop.centerx,pop.y+76),font_small,MUTED)

        pawn_reward=3 if g.harvest_reward_mode=="progressive" else 2

        if g.saboteur_lost[g.current]:
            pawn_r=pygame.Rect(pop.x+18,pop.y+108,112,60)
            veh_r=pygame.Rect(pop.x+139,pop.y+108,112,60)
            sab_r=pygame.Rect(pop.x+260,pop.y+108,112,60)
            for r in (pawn_r,veh_r,sab_r):
                pygame.draw.rect(screen,(55,58,62),r)
                pygame.draw.rect(screen,TEXT,r,1)
            draw_center(f"+{pawn_reward} PAWNS",pawn_r.center,font_small,TEXT)
            draw_center("+1 VEHICLE",veh_r.center,font_small,TEXT)
            draw_center("SABOTEUR",sab_r.center,font_small,TEXT)
            popup_buttons["saboteur"]=sab_r
        else:
            pawn_r=pygame.Rect(pop.x+24,pop.y+108,164,60)
            veh_r=pygame.Rect(pop.x+202,pop.y+108,164,60)
            for r in (pawn_r,veh_r):
                pygame.draw.rect(screen,(55,58,62),r)
                pygame.draw.rect(screen,TEXT,r,1)
            draw_center(f"+{pawn_reward} PAWNS",pawn_r.center,font_small,TEXT)
            draw_center("+1 VEHICLE",veh_r.center,font_small,TEXT)

        popup_buttons["pawns"]=pawn_r
        popup_buttons["vehicle"]=veh_r

    if g.privacy:
        cpu_hidden = g.current in getattr(g,"bot_players",set())

        if cpu_hidden:
            # Bot turns reveal NOTHING: no board, sidebar, messages, contents,
            # movement, or intermediate positions.
            shade=pygame.Surface((WIDTH,HEIGHT),pygame.SRCALPHA)
            shade.fill((10,10,10,248))
            screen.blit(shade,(0,0))
            cx=WIDTH//2
            draw_center("CPU TURN",(cx,HEIGHT//2-26),font_big,MUTED)
            draw_center("Resolving opponents...",(cx,HEIGHT//2+24),font_small,MUTED)
        else:
            shade=pygame.Surface((MARGIN*2+BOARD_W,HEIGHT),pygame.SRCALPHA)
            shade.fill((10,10,10,235)); screen.blit(shade,(0,0))
            cx=(MARGIN*2+BOARD_W)//2
            draw_center(faction_name(g.current),(cx,HEIGHT//2-50),font_big,PLAYER_COLORS[g.current])
            draw_center("Pass the device, then tap to begin.",(cx,HEIGHT//2),font,TEXT)
            draw_center("Enemy ownership color remains visible.",(cx,HEIGHT//2+34),font_small,MUTED)

    # Cheap post-elimination replay viewer.
    if getattr(g,"replay_mode",False):
        ox,oy=board_offset(g.grid)
        board_w=g.grid*CELL
        board_bottom=oy+g.grid*CELL

        bar_y=min(HEIGHT-58,board_bottom+52)
        bw=46
        play_w=64
        view_w=118
        gap=7
        has_skull=getattr(g,"human_elimination_snapshot",None) is not None
        widths=[bw,bw,play_w,bw,bw] + ([bw] if has_skull else []) + [view_w]
        total=sum(widths)+gap*(len(widths)-1)
        bx=ox+(board_w-total)//2

        specs=[
            ("replay_first","<<",bw),
            ("replay_prev","<",bw),
            ("replay_play","PAUSE" if g.replay_playing else "PLAY",play_w),
            ("replay_next",">",bw),
            ("replay_last",">>",bw),
        ]
        if has_skull:
            specs.append(("replay_death",None,bw))
        specs.append((
                "replay_view",
                (
                    "YOUR VIEW" if g.replay_view_mode=="you"
                    else "TURN VIEW" if g.replay_view_mode=="turn"
                    else "OMNISCIENT"
                ),
                view_w
            ))
        x=bx
        for key,label,w in specs:
            r=pygame.Rect(x,bar_y,w,38)
            pygame.draw.rect(screen,(47,50,54),r)
            pygame.draw.rect(screen,MUTED,r,1)
            if key=="replay_death":
                # Font-independent skull: GDG's bundled UI font does not carry
                # Unicode symbol glyphs reliably, so draw the icon ourselves.
                cx,cy=r.center
                pygame.draw.circle(screen,TEXT,(cx,cy-3),9,2)
                pygame.draw.rect(screen,TEXT,pygame.Rect(cx-6,cy+4,12,6),2)
                pygame.draw.circle(screen,TEXT,(cx-4,cy-4),2)
                pygame.draw.circle(screen,TEXT,(cx+4,cy-4),2)
                pygame.draw.line(screen,TEXT,(cx,cy-1),(cx,cy+3),2)
                pygame.draw.line(screen,TEXT,(cx-3,cy+7),(cx-3,cy+10),1)
                pygame.draw.line(screen,TEXT,(cx+3,cy+7),(cx+3,cy+10),1)
            else:
                draw_center(label,r.center,font_small if key=="replay_play" else font,TEXT)
            buttons[key]=r
            x+=w+gap

        shown=max(0,g.replay_index-g.replay_start_index)
        total_frames=max(0,len(g.replay_snapshots)-1-g.replay_start_index)
        draw_center(
            f"REPLAY  {shown}/{total_frames}  |  GLOBAL TURN {g.global_turn}",
            (ox+board_w//2,bar_y+56),
            font_small,MUTED
        )

    # End-of-game result belongs to the board, not the sidebar.
    # Put it centered directly below the active board whenever space permits.
    if (g.draw or g.winner is not None):
        ox,oy=board_offset(g.grid)
        board_bottom=oy+g.grid*CELL
        result_center=(ox+(g.grid*CELL)//2, min(HEIGHT-26, board_bottom+30))
        if g.draw:
            draw_center("DRAW",result_center,font_big,TEXT)
        else:
            draw_center(
                f"{faction_name(g.winner)} WINS",
                result_center,font_big,PLAYER_COLORS[g.winner]
            )

    return buttons,slot_rects,popup_buttons

def draw_center(s,center,f=None,color=TEXT):
    surf=(f or font).render(str(s),True,color)
    screen.blit(surf,surf.get_rect(center=center))

def board_pos_from_mouse(pos,grid):
    mx,my=pos
    ox,oy=board_offset(grid)
    if mx<ox or my<oy: return None
    x=(mx-ox)//CELL; y=(my-oy)//CELL
    if 0<=x<grid and 0<=y<grid:
        return int(x),int(y)
    return None

# ---------- input helpers ----------
def select_friendly_at(g,bp):
    """Right-click on desktop / double-tap on phone: switch selection to the
    friendly token or base on that tile, without performing any action."""
    x,y=bp
    tok=g.token_at(x,y)
    base=g.bases.get((x,y))
    if tok and tok.owner==g.current:
        g.selected=tok
        g.selected_person_idx=None
        g.message="Selected vehicle." if tok.vehicle else f"Selected strength {tok.strength()}."
    elif base and base.owner==g.current:
        g.selected=base
        g.selected_person_idx=None
        g.message=f"Selected base: {len(base.people)} occupant(s)."

def tap_is_ambiguous(g,bp):
    """A single tap on a friendly tile while something else is selected would
    merge / board / transfer. Because a double-tap means 'just select it', that
    one case waits a moment to see whether a second tap follows."""
    sel=g.selected
    if sel is None: return False
    tok=g.token_at(*bp); base=g.bases.get(bp)
    friendly_tok = tok is not None and tok.owner==g.current and tok is not sel
    friendly_base = base is not None and base.owner==g.current and base is not sel
    if not (friendly_tok or friendly_base): return False
    if isinstance(sel,Base) and g.selected_person_idx is None: return False
    return True

def handle_left_click(g,pos,buttons,slot_rects,popup_buttons):
    """Everything a normal left click / single tap does (privacy screen,
    reinforcement popup and restart button are handled by the caller)."""
    if buttons.get("end") and buttons["end"].collidepoint(pos):
        g.next_turn(); return

    # Container slot selection.
    if g.container_people(g.selected) is not None:
        for i,r in enumerate(slot_rects):
            if r.collidepoint(pos):
                people=g.container_people(g.selected)
                if i<len(people):
                    g.selected_person_idx=i
                    p=people[i]
                    label="leader" if p.leader else ("Saboteur" if p.saboteur else "pawn")
                    g.message=f"Selected {label}."
                else:
                    g.selected_person_idx=None
                return

    bp=board_pos_from_mouse(pos,g.grid)
    if bp is None or g.winner is not None or g.draw: return
    x,y=bp
    clicked_token=g.token_at(x,y)
    clicked_base=g.bases.get((x,y))

    # If a person inside a selected container is selected, board click deploys them.
    if g.selected_person_idx is not None and g.container_people(g.selected) is not None:
        g.deploy_selected_person(g.selected,g.selected_person_idx,x,y)
        return

    if g.selected is None:
        if clicked_token and clicked_token.owner==g.current:
            g.selected=clicked_token; g.selected_person_idx=None
            g.message="Selected vehicle." if clicked_token.vehicle else f"Selected strength {clicked_token.strength()}."
        elif clicked_base and clicked_base.owner==g.current:
            g.selected=clicked_base; g.selected_person_idx=None
            g.message=f"Selected base: {len(clicked_base.people)} occupant(s)."
        else:
            g.message="Select one of your tokens or bases."
        return

    if isinstance(g.selected,Base):
        # Clicking selected base again clears; own token/base switches selection.
        if clicked_base is g.selected:
            g.selected=None; g.selected_person_idx=None
        elif clicked_token and clicked_token.owner==g.current:
            g.selected=clicked_token; g.selected_person_idx=None
        elif clicked_base and clicked_base.owner==g.current:
            g.selected=clicked_base; g.selected_person_idx=None
        else:
            g.message="Choose an occupant slot first."
        return

    if isinstance(g.selected,Token):
        if clicked_token is g.selected:
            g.selected=None; g.selected_person_idx=None
        elif (
            clicked_base is not None
            and clicked_base.owner==g.current
            and (g.selected.vehicle or (g.selected.has_leader() and g.selected.regular_count()==0))
        ):
            # Convenience: vehicle/leader cannot enter a base, so clicking
            # a friendly base switches selection instead of producing an error.
            g.selected=clicked_base
            g.selected_person_idx=None
            g.message=f"Selected base: {len(clicked_base.people)} occupant(s)."
        else:
            g.try_move_or_interact(g.selected,x,y)

# ---------- setup screen ----------
async def choose_settings():
    settings={
        "players":4,
        "grid":9,
        "base_move":2,
        "unit_cap":6,
        "starting_pawns":3,
        "starting_vehicle":True,
        "draw_winner":"defender",
        "basic_bot":True,
        "bot_difficulty":"hard",
        "randomize_faction_order":True,
        "harvest_reward_mode":"ladder",
        "lose_last_base":False,
        "base_movement":True,
    }

    def clamp(v,lo,hi): return max(lo,min(hi,v))

    # Setup is now a virtual page taller than the physical window.
    # Mouse wheel / trackpad and touch-drag move the viewport.
    scroll_y=0
    scroll_max=0
    touch_dragging=False
    touch_last_y=None

    frame=0
    while True:
        # Browser: follow the screen shape (rotate the iPad -> layout follows)
        # until the player picks a view by hand.
        if sys.platform=="emscripten" and not UI["picked"] and frame%30==0:
            want=auto_layout()
            if want!=LAYOUT_MODE: set_layout(want)
        frame+=1
        S=L["setup"]     # re-read every frame: the layout can change from this screen

        display_screen=screen
        page_h=max(1200,HEIGHT+360)
        page_surface=pygame.Surface((WIDTH,page_h))
        globals()["screen"]=page_surface
        page_surface.fill(BG)

        draw_text("GDG MINI — PLAYTEST SETUP",S["title"],font_big)
        draw_text("Everything here is deliberately tweakable.",S["sub"],font_small,MUTED)

        # Layout switch (top right): phone / PC look.
        tw=96; th=36
        layout_rects={
            "phone":pygame.Rect(WIDTH-MARGIN-3*tw-12,MARGIN,tw,th),
            "tablet":pygame.Rect(WIDTH-MARGIN-2*tw-6,MARGIN,tw,th),
            "pc":pygame.Rect(WIDTH-MARGIN-tw,MARGIN,tw,th),
        }
        draw_text("VIEW",(layout_rects["phone"].x-62,MARGIN+9),font_small,MUTED)
        for name,r in layout_rects.items():
            sel=(LAYOUT_MODE==name)
            pygame.draw.rect(screen,(74,78,83) if sel else (47,50,54),r)
            pygame.draw.rect(screen,TEXT if sel else MUTED,r,2 if sel else 1)
            draw_center(name.upper(),r.center,font_small,TEXT if sel else MUTED)

        # Fullscreen (browser only): hides the address bar on Android.
        fs_rect=None
        if sys.platform=="emscripten":
            fs_rect=pygame.Rect(WIDTH-MARGIN-3*tw-12,MARGIN+th+6,3*tw+12,th)
            pygame.draw.rect(screen,(47,50,54),fs_rect)
            pygame.draw.rect(screen,MUTED,fs_rect,1)
            draw_center("FULLSCREEN",fs_rect.center,font_small,TEXT)

        controls={}
        x0=S["x0"]; y0=S["y0"]; row=S["row"]; bh=S["bh"]
        cx0=S["cx0"]

        def choice_row(key,label,options,display=None):
            nonlocal y0
            draw_text(label,(x0,y0+(bh-font.get_height())//2),font)
            bx=cx0
            controls[key]=[]
            for value in options:
                text = display(value) if display else str(value)
                w=max(S["wmin"],S["wpad"]+len(text)*S["wchar"])
                r=pygame.Rect(bx,y0,w,bh)
                selected=settings[key]==value
                pygame.draw.rect(screen,(74,78,83) if selected else (47,50,54),r)
                pygame.draw.rect(screen,TEXT if selected else MUTED,r,2 if selected else 1)
                draw_center(text,r.center,font_small,TEXT if selected else MUTED)
                controls[key].append((value,r))
                bx+=w+10
            y0+=row

        choice_row("players","PLAYERS",[2,3,4],lambda v:f"{v}P")
        choice_row("grid","BOARD",[13,11,9,7],lambda v:f"{v} x {v}")
        choice_row("draw_winner","DRAW ADVANTAGE",["defender","attacker"],lambda v:v.upper())
        choice_row("starting_vehicle","START VEHICLE",[True,False],lambda v:"YES" if v else "NO")
        choice_row("basic_bot","OPPONENTS",[False,True],lambda v:"BASIC BOTS" if v else "HUMAN")
        choice_row("bot_difficulty","BOT DIFFICULTY",["easy","medium","hard"],lambda v:v.upper())
        choice_row(
            "randomize_faction_order","RANDOM FACTION + ORDER",
            [True,False],lambda v:"YES" if v else "NO"
        )
        choice_row(
            "harvest_reward_mode","HARVEST REWARD",
            ["progressive","ladder","clean_choice","classic"],
            lambda v:{
                "progressive":"CURRENT",
                "ladder":"LADDER",
                "clean_choice":"CLEAN 2/4",
                "classic":"CLASSIC"
            }[v]
        )
        choice_row(
            "lose_last_base","LOSE LAST BASE",
            [False,True],
            lambda v:"NORMAL" if not v else "ELIMINATED"
        )
        choice_row(
            "base_movement","BASE MOVEMENT",
            [False,True],
            lambda v:"CLASSIC" if not v else "1 + BASES + UNITS"
        )

        # Stepper rows
        steppers={}
        sxs,mw,vw,gap=S["step"]
        for key,label,lo,hi in [
            ("base_move","DEFAULT MOVE",1,10),
            ("unit_cap","MAX VISIBLE UNITS",2,12),
            ("starting_pawns","STARTING PAWNS",0,4),
        ]:
            draw_text(label,(x0,y0+(bh-font.get_height())//2),font)
            minus=pygame.Rect(sxs,y0,mw,bh)
            valr=pygame.Rect(sxs+mw+gap,y0,vw,bh)
            plus=pygame.Rect(sxs+mw+gap+vw+gap,y0,mw,bh)
            for r in (minus,plus,valr):
                pygame.draw.rect(screen,(47,50,54),r)
                pygame.draw.rect(screen,MUTED,r,1)
            draw_center("-",minus.center,font_big,TEXT)
            draw_center("+",plus.center,font_big,TEXT)
            draw_center(str(settings[key]),valr.center,font,TEXT)
            steppers[key]=(minus,plus,lo,hi)
            y0+=row

        # Helpful derived summary
        summary_y=y0+S["summary"]
        draw_text("STARTING STATE",(x0,summary_y),font_small,MUTED)
        visible_start=1+(1 if settings["starting_vehicle"] else 0)  # leader + possible vehicle
        opponent_summary=(
            ("P2 BOT" if settings["players"]==2 else f"P2-P{settings['players']} BOTS")
            if settings["basic_bot"] else "ALL HUMAN"
        )
        if settings["basic_bot"]:
            opponent_summary += f" / {settings['bot_difficulty'].upper()}"
        opening_pool=(
            1 + 1 + visible_start
            if settings["base_movement"]
            else settings["base_move"] + visible_start
        )
        draw_text(
            f"{settings['starting_pawns']} pawn(s) hidden in base | "
            f"{visible_start} visible unit(s) | opening pool {opening_pool} | "
            f"{opponent_summary}"
            + (" | RANDOM FACTION/ORDER" if settings["randomize_faction_order"] else "")
            + {
                "progressive":" | HARVEST CURRENT 2→1 / 4→3+",
                "ladder":" | HARVEST LADDER 2→1 / 3→V/S / 4→3",
                "clean_choice":" | HARVEST CLEAN 2→1/V/S / 4→3",
                "classic":" | HARVEST CLASSIC 4→2+",
            }[settings["harvest_reward_mode"]]
            + (" | LAST BASE = ELIMINATION" if settings["lose_last_base"] else "")
            + (" | MOVE = 1+BASES+UNITS" if settings["base_movement"] else ""),
            (x0,summary_y+24),font_small,TEXT
        )

        # Flow the start button beneath the actual content so new setup rows
        # can never collide with it.
        start=pygame.Rect(
            WIDTH//2-150,
            summary_y+72,
            300,
            56
        )
        pygame.draw.rect(screen,(65,70,75),start)
        pygame.draw.rect(screen,TEXT,start,2)
        draw_center("START TEST GAME",start.center,font,TEXT)

        content_bottom=start.bottom+36
        scroll_max=max(0,content_bottom-HEIGHT+20)
        scroll_y=max(0,min(scroll_y,scroll_max))

        # Return drawing to the real display and show the requested viewport.
        globals()["screen"]=display_screen
        display_screen.fill(BG)
        display_screen.blit(page_surface,(0,-scroll_y))

        # Minimal scrollbar: only appears if scrolling is actually necessary.
        if scroll_max>0:
            track=pygame.Rect(WIDTH-9,10,3,HEIGHT-20)
            pygame.draw.rect(display_screen,(56,59,63),track)
            thumb_h=max(42,int(track.h*HEIGHT/(HEIGHT+scroll_max)))
            travel=max(1,track.h-thumb_h)
            thumb_y=track.y+int(travel*(scroll_y/scroll_max))
            pygame.draw.rect(
                display_screen,MUTED,
                pygame.Rect(track.x-1,thumb_y,5,thumb_h)
            )

        pygame.display.flip()

        for e in pygame.event.get():
            if e.type==pygame.QUIT:
                pygame.quit(); sys.exit()

            # Desktop wheel / trackpad.
            if e.type==pygame.MOUSEWHEEL:
                scroll_y=clamp(scroll_y-e.y*52,0,scroll_max)
                continue

            # Browser / tablet finger scrolling.
            if e.type==pygame.FINGERDOWN:
                touch_dragging=True
                touch_last_y=e.y
                continue
            if e.type==pygame.FINGERMOTION and touch_dragging:
                if touch_last_y is not None:
                    dy=(e.y-touch_last_y)*HEIGHT
                    scroll_y=clamp(scroll_y-dy,0,scroll_max)
                touch_last_y=e.y
                continue
            if e.type==pygame.FINGERUP:
                touch_dragging=False
                touch_last_y=None
                continue

            # Old-style wheel events, useful on some pygame builds.
            if e.type==pygame.MOUSEBUTTONDOWN and e.button in (4,5):
                scroll_y=clamp(
                    scroll_y + (-52 if e.button==4 else 52),
                    0,scroll_max
                )
                continue

            if e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                # All setup rectangles live in virtual-page coordinates.
                click_pos=(e.pos[0],e.pos[1]+scroll_y)
                if fs_rect is not None and fs_rect.collidepoint(click_pos):
                    toggle_fullscreen()
                    continue
                switched=False
                for name,r in layout_rects.items():
                    if r.collidepoint(click_pos):
                        UI["picked"]=True
                        if name!=LAYOUT_MODE:
                            set_layout(name)
                            scroll_y=0
                            switched=True
                        break
                if switched:
                    break          # geometry changed: redraw before reading more clicks

                for key,items in controls.items():
                    for value,r in items:
                        if r.collidepoint(click_pos):
                            settings[key]=value
                            if key=="grid":
                                defaults={13:4,11:3,9:2,7:1}
                                settings["base_move"]=defaults[value]
                            elif key=="players":
                                # Same starting material in every player-count mode.
                                # Harvest access / board pressure create the scaling.
                                pass
                            break

                for key,(minus,plus,lo,hi) in steppers.items():
                    if minus.collidepoint(click_pos):
                        settings[key]=clamp(settings[key]-1,lo,hi)
                    elif plus.collidepoint(click_pos):
                        settings[key]=clamp(settings[key]+1,lo,hi)

                if start.collidepoint(click_pos):
                    return settings

        clock.tick(FPS)
        await asyncio.sleep(0)   # lets the browser breathe (required for the web build)

# ---------- one match ----------
async def play(g):
    """Runs one match. Returns when the player restarts (back to the setup screen)."""
    pending=None     # (pos, tile, time): single tap on a friendly tile, waiting to see if a 2nd tap follows
    last_tap=None    # (tile, time): last board tap, used to spot double-taps
    UI["restart_until"]=0
    bots={p:BasicBot(player=p,difficulty=getattr(g,"bot_difficulty","normal")) for p in getattr(g,"bot_players",set())}
    bot_phase_started=None

    while True:
        buttons,slot_rects,popup_buttons=draw_game(g)
        pygame.display.flip()
        now=pygame.time.get_ticks()

        # Replay autoplay: one completed-turn snapshot every 2 seconds.
        if getattr(g,"replay_mode",False) and getattr(g,"replay_playing",False):
            last_index=len(g.replay_snapshots)-1
            if g.replay_index>=last_index:
                g.replay_playing=False
                g.replay_next_tick=0
            elif g.replay_next_tick<=0:
                g.replay_next_tick=now+g.replay_interval_ms
            elif now>=g.replay_next_tick:
                g.restore_replay_snapshot(g.replay_index+1)
                if g.replay_index>=last_index:
                    g.replay_playing=False
                    g.replay_next_tick=0
                else:
                    g.replay_next_tick=now+g.replay_interval_ms

        # CPU phase: show one fully opaque privacy screen, pause briefly, then
        # resolve ALL consecutive bot turns without rendering any intermediate
        # board state. The human only sees the resulting position.
        active_bot=bots.get(g.current)
        if (
            not getattr(g,"replay_mode",False)
            and active_bot is not None
            and g.winner is None
            and not g.draw
        ):
            g.privacy=True
            pending=None
            last_tap=None

            if bot_phase_started is None:
                bot_phase_started=now

            # Leave the cover visible for a short beat so End Turn -> CPU -> result
            # reads clearly instead of feeling like an accidental instant jump.
            if now-bot_phase_started < 550:
                for e in pygame.event.get():
                    if e.type==pygame.QUIT:
                        pygame.quit(); sys.exit()
                clock.tick(FPS)
                await asyncio.sleep(0)
                continue

            safety=0
            while g.current in bots and g.winner is None and not g.draw and safety<500:
                bot=bots[g.current]
                before=(g.current,g.turn,g.move_left,len(g.log))
                human_was_alive=g.alive[getattr(g,"human_player",0)]
                result=bot.step(g)
                safety+=1

                if (
                    human_was_alive
                    and not g.alive[getattr(g,"human_player",0)]
                    and g.human_elimination_snapshot is None
                ):
                    g.human_elimination_snapshot=g.record_replay_snapshot(
                        "HUMAN_ELIMINATED",force=True
                    )

                # Defensive escape hatch: a bot must never freeze the hidden phase.
                after=(g.current,g.turn,g.move_left,len(g.log))
                if result=="idle" and after==before:
                    if g.end_turn_allowed():
                        g.next_turn()
                    else:
                        # No legal action should be extraordinarily rare; keep the
                        # game responsive rather than hanging forever.
                        g.action_taken=True
                        g.next_turn()

            # If the human was eliminated, bots are allowed to finish the whole
            # match behind the curtain. Then open a turn-by-turn neutral replay
            # from the elimination frame.
            g.privacy=False
            if (
                g.basic_bot
                and not g.alive[g.human_player]
                and (g.winner is not None or g.draw)
                and not g.replay_mode
            ):
                g.enter_replay_mode(start_at_end=True)

            bot_phase_started=None
            clock.tick(FPS)
            await asyncio.sleep(0)
            continue

        bot_phase_started=None

        # A human can also eliminate itself on its own attack. Bookmark that
        # state, advance away from the dead turn owner, and let the CPUs finish.
        if (
            g.basic_bot
            and not g.replay_mode
            and not g.alive[g.human_player]
            and g.winner is None
            and not g.draw
        ):
            if g.human_elimination_snapshot is None:
                g.human_elimination_snapshot=g.record_replay_snapshot(
                    "HUMAN_ELIMINATED",force=True
                )
            if g.current==g.human_player:
                if not g.action_taken:
                    g.action_taken=True
                g.next_turn()
            clock.tick(FPS)
            await asyncio.sleep(0)
            continue

        # A pending tap that never got a second tap becomes a normal click.
        if pending and now-pending[2]>DOUBLE_TAP_MS:
            handle_left_click(g,pending[0],buttons,slot_rects,popup_buttons)
            pending=None

        for e in pygame.event.get():
            if e.type==pygame.QUIT:
                pygame.quit(); sys.exit()

            if e.type==pygame.KEYDOWN:
                if e.key==pygame.K_F2:
                    g.reveal_debug=not g.reveal_debug
                elif (
                    e.key==pygame.K_RETURN
                    and not g.privacy
                    and not popup_buttons
                    and not getattr(g,"replay_mode",False)
                ):
                    g.next_turn()
                elif isinstance(g.selected,Token) and not g.privacy and not popup_buttons and g.selected_person_idx is None:
                    dx=dy=0
                    if e.key==pygame.K_LEFT: dx=-1
                    elif e.key==pygame.K_RIGHT: dx=1
                    elif e.key==pygame.K_UP: dy=-1
                    elif e.key==pygame.K_DOWN: dy=1
                    if dx or dy:
                        nx,ny=g.selected.x+dx,g.selected.y+dy
                        if 0<=nx<g.grid and 0<=ny<g.grid:
                            g.try_move_or_interact(g.selected,nx,ny)

            # Desktop right-click (kept): select a friendly token/base.
            if e.type==pygame.MOUSEBUTTONDOWN and e.button==3:
                if g.privacy or popup_buttons:
                    continue
                bp=board_pos_from_mouse(e.pos,g.grid)
                if bp is not None:
                    select_friendly_at(g,bp)
                continue

            if e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                now=pygame.time.get_ticks()
                over=g.winner is not None or g.draw

                if getattr(g,"replay_mode",False):
                    if buttons.get("replay_first") and buttons["replay_first"].collidepoint(e.pos):
                        g.replay_playing=False
                        g.replay_next_tick=0
                        g.restore_replay_snapshot(g.replay_start_index)
                        continue

                    if buttons.get("replay_prev") and buttons["replay_prev"].collidepoint(e.pos):
                        g.replay_playing=False
                        g.replay_next_tick=0
                        g.restore_replay_snapshot(
                            max(g.replay_start_index,g.replay_index-1)
                        )
                        continue

                    if buttons.get("replay_play") and buttons["replay_play"].collidepoint(e.pos):
                        if g.replay_playing:
                            g.replay_playing=False
                            g.replay_next_tick=0
                        else:
                            # Pressing Play at the end replays from elimination.
                            if g.replay_index>=len(g.replay_snapshots)-1:
                                g.restore_replay_snapshot(g.replay_start_index)
                            g.replay_playing=True
                            g.replay_next_tick=now+g.replay_interval_ms
                        continue

                    if buttons.get("replay_next") and buttons["replay_next"].collidepoint(e.pos):
                        g.replay_playing=False
                        g.replay_next_tick=0
                        g.restore_replay_snapshot(
                            min(len(g.replay_snapshots)-1,g.replay_index+1)
                        )
                        continue

                    if buttons.get("replay_last") and buttons["replay_last"].collidepoint(e.pos):
                        g.replay_playing=False
                        g.replay_next_tick=0
                        g.restore_replay_snapshot(len(g.replay_snapshots)-1)
                        continue

                    if buttons.get("replay_death") and buttons["replay_death"].collidepoint(e.pos):
                        g.replay_playing=False
                        g.replay_next_tick=0
                        g.restore_replay_snapshot(g.human_elimination_snapshot)
                        continue

                    if buttons.get("replay_view") and buttons["replay_view"].collidepoint(e.pos):
                        # Cycle knowledge perspective without changing replay position.
                        order=["you","turn","omniscient"]
                        current=getattr(g,"replay_view_mode","you")
                        try:
                            idx=order.index(current)
                        except ValueError:
                            idx=0
                        g.replay_view_mode=order[(idx+1)%len(order)]
                        continue

                # Restart button: back to the setup screen. Mid-game it needs a second tap.
                if buttons["restart"].collidepoint(e.pos):
                    if over or now<UI["restart_until"]:
                        UI["restart_until"]=0
                        return
                    UI["restart_until"]=now+2500
                    continue

                if g.privacy:
                    g.privacy=False
                    pending=None; last_tap=None
                    continue

                if getattr(g,"replay_mode",False):
                    # Replay controls / restart are the only active inputs.
                    continue

                # Modal reinforcement choice blocks board interaction.
                if popup_buttons:
                    if (
                        popup_buttons.get("harvest_cashout")
                        and popup_buttons["harvest_cashout"].collidepoint(e.pos)
                    ):
                        if g.resolve_mid_harvest_choice("cashout") and g.end_turn_allowed():
                            g.next_turn()
                    elif (
                        popup_buttons.get("harvest_push")
                        and popup_buttons["harvest_push"].collidepoint(e.pos)
                    ):
                        if g.resolve_mid_harvest_choice("push") and g.end_turn_allowed():
                            g.next_turn()
                    elif (
                        popup_buttons.get("harvest_vehicle")
                        and popup_buttons["harvest_vehicle"].collidepoint(e.pos)
                    ):
                        if g.resolve_mid_harvest_choice("vehicle") and g.end_turn_allowed():
                            g.next_turn()
                    elif (
                        popup_buttons.get("harvest_saboteur")
                        and popup_buttons["harvest_saboteur"].collidepoint(e.pos)
                    ):
                        if g.resolve_mid_harvest_choice("saboteur") and g.end_turn_allowed():
                            g.next_turn()
                    elif popup_buttons.get("pawns") and popup_buttons["pawns"].collidepoint(e.pos):
                        g.spawn_reinforcement("pawns")
                        if g.end_turn_allowed():
                            g.next_turn()
                    elif popup_buttons.get("vehicle") and popup_buttons["vehicle"].collidepoint(e.pos):
                        g.spawn_reinforcement("vehicle")
                        if g.end_turn_allowed():
                            g.next_turn()
                    elif popup_buttons.get("saboteur") and popup_buttons["saboteur"].collidepoint(e.pos):
                        g.spawn_reinforcement("saboteur")
                        if g.end_turn_allowed():
                            g.next_turn()
                    continue

                bp=board_pos_from_mouse(e.pos,g.grid)

                # A waiting tap that this tap does not complete into a double-tap acts now.
                if pending and not (bp is not None and pending[1]==bp and now-pending[2]<=DOUBLE_TAP_MS):
                    handle_left_click(g,pending[0],buttons,slot_rects,popup_buttons)
                    pending=None

                if bp is not None and not over:
                    if pending:
                        # Second tap on the same tile: double-tap = select, no action.
                        pending=None; last_tap=None
                        select_friendly_at(g,bp)
                        continue
                    if last_tap and last_tap[0]==bp and now-last_tap[1]<=DOUBLE_TAP_MS:
                        last_tap=None
                        select_friendly_at(g,bp)
                        continue
                    last_tap=(bp,now)
                    if tap_is_ambiguous(g,bp):
                        pending=(e.pos,bp,now)
                        continue

                handle_left_click(g,e.pos,buttons,slot_rects,popup_buttons)

        clock.tick(FPS)
        await asyncio.sleep(0)   # lets the browser breathe (required for the web build)

async def main():
    while True:
        settings=await choose_settings()
        g=Game(**settings)
        await play(g)

# Keep this at the very end of the file (the web build needs it exactly here).
if __name__=="__main__" or sys.platform=="emscripten":
    asyncio.run(main())
