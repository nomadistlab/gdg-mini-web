import asyncio, pygame, sys, json
from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime
from collections import deque

pygame.init()

VERSION="0.11.12"

MAX_GRID=13
FPS=60; MAX_GROUP=4
DOUBLE_TAP_MS=320                   # two taps on the same tile within this = "right click"

BG=(28,30,32); GRID_C=(74,77,80); TEXT=(235,235,235); MUTED=(165,165,165)
BASE_NEUTRAL=(90,90,90); HARVEST_ON=(214,188,76); HARVEST_OFF=(80,75,55)
SELECT=(245,245,245); SLOT_BG=(48,51,55)
PLAYER_COLORS=[(205,75,75),(80,145,220),(90,190,120),(210,155,70)]
HARVEST_ORDER=("forest","oil","factory","fish")  # top, right, bottom, left


pygame.display.set_caption(f"GDG Mini v{VERSION}")
clock=pygame.time.Clock()

def load_font(size,bold=False,prefer_consolas=False):
    # A bundled font keeps text identical on desktop and in the browser
    # (system fonts like Consolas do not exist on phones / in the web build).
    if prefer_consolas:
        try:
            path=pygame.font.match_font("consolas",bold=bold)
            if path: return pygame.font.Font(path,size)
        except Exception:
            pass
        size=max(8,round(size*0.92))   # DejaVu is a little wider than Consolas
    name="DejaVuSansMono-Bold.ttf" if bold else "DejaVuSansMono.ttf"
    candidates=[]
    try: candidates.append(Path(__file__).with_name(name))
    except Exception: pass
    candidates.append(Path(name))
    for p in candidates:
        try:
            if p.exists(): return pygame.font.Font(str(p),size)
        except Exception:
            pass
    try: return pygame.font.SysFont("consolas,dejavusansmono,couriernew",size,bold=bold)
    except Exception: return pygame.font.Font(None,int(size*1.25))

# ---------- layouts ----------
# "pc"    = the classic v0.9 look (square-ish window, one sidebar column)
# "phone" = wide landscape layout (board left, two sidebar columns)
# Everything that depends on the layout is (re)set by set_layout().
LAYOUT_MODE=None
CELL=MARGIN=TOP=BOARD_W=WIDTH=HEIGHT=WRAP=SLOT=0
PS=1.0     # piece scale (bigger cells -> bigger pieces)
def ps(n): return max(1,round(n*PS))
L={}
screen=None
font=font_small=font_big=font_move=None

def set_layout(mode):
    global LAYOUT_MODE,CELL,MARGIN,TOP,BOARD_W,WIDTH,HEIGHT,WRAP,SLOT,L,screen,PS
    global font,font_small,font_big,font_move
    LAYOUT_MODE=mode
    PS=1.0
    if mode=="pc":
        CELL=48; MARGIN=26; TOP=70
        BOARD_W=MAX_GRID*CELL
        WIDTH=MARGIN*2+BOARD_W+350; HEIGHT=TOP+BOARD_W+MARGIN+90
        WRAP=34; SLOT=54
        font=load_font(18,False,True); font_small=load_font(14,False,True)
        font_big=load_font(28,True,True); font_move=load_font(34,True,True)
        px=MARGIN+BOARD_W+24; right=WIDTH-MARGIN
        L=dict(
            title=(MARGIN,24,"big"), player=(px,TOP), turn_right=(right,TOP), status_x=px,
            y_move_label=TOP+42, y_move_num=TOP+60,
            y_visible=TOP+112, y_harvest=TOP+140, y_bases=TOP+168, y_config=None,
            legend=[],
            y_reserve_label=TOP+242, y_reserve_icons=TOP+274, harvest_dx=132, harvest_step=34,
            msg=(px,TOP+344), msg_line_h=18,
            container=(px,TOP+448),
            end=pygame.Rect(px,HEIGHT-58,285,42), end_label="END TURN [ENTER]",
            restart=pygame.Rect(px,HEIGHT-58-52,150,40),
            result=(px,HEIGHT-245),
            setup=dict(title=(MARGIN,28), sub=(MARGIN,66), x0=95, y0=118, row=62, bh=40,
                       cx0=330, wmin=74, wpad=18, wchar=11, step=(365,42,64,7), summary=12,
                       start=pygame.Rect(WIDTH//2-120,HEIGHT-82,240,50)),
        )
    elif mode=="tablet":
        # Squarer screens (iPad, 4:3): big board, ONE narrow column, minimal text.
        CELL=57; MARGIN=14; TOP=14; PS=CELL/44
        BOARD_W=MAX_GRID*CELL
        WIDTH=1024; HEIGHT=MARGIN*2+BOARD_W
        WRAP=25; SLOT=58
        font=load_font(19); font_small=load_font(15)
        font_big=load_font(28,True); font_move=load_font(44,True)
        sx=MARGIN*2+BOARD_W+10; side_r=WIDTH-MARGIN
        L=dict(
            title=(sx,TOP+28,"small"), player=(sx,TOP), turn_right=(side_r,TOP), status_x=sx,
            y_move_label=TOP+58, y_move_num=TOP+76,
            y_visible=TOP+136, y_harvest=TOP+166, y_bases=TOP+196, y_config=None,
            legend=[],
            y_reserve_label=TOP+234, y_reserve_icons=TOP+256, harvest_dx=100, harvest_step=30,
            msg=(sx,TOP+330), msg_line_h=20,
            container=(sx,TOP+440),
            end=pygame.Rect(sx,HEIGHT-MARGIN-56,side_r-sx,56), end_label="END TURN",
            restart=pygame.Rect(sx,HEIGHT-MARGIN-56-6-44,side_r-sx,44),
            result=(sx,TOP+576),
            setup=dict(title=(MARGIN+10,MARGIN), sub=(MARGIN+10,MARGIN+38), x0=150, y0=100, row=58, bh=46,
                       cx0=440, wmin=84, wpad=24, wchar=10, step=(440,52,72,6), summary=8,
                       start=pygame.Rect(WIDTH//2-130,HEIGHT-84,260,58)),
        )
    else:
        CELL=44; MARGIN=14; TOP=14
        BOARD_W=MAX_GRID*CELL
        WIDTH=1280; HEIGHT=MARGIN*2+BOARD_W
        WRAP=32; SLOT=58
        font=load_font(20); font_small=load_font(16)
        font_big=load_font(30,True); font_move=load_font(44,True)
        side_x=MARGIN*2+BOARD_W+10; side_r=WIDTH-MARGIN
        col_w=(side_r-side_x-20)//2
        col_a=side_x; col_b=side_r-col_w
        ya=TOP+40
        L=dict(
            title=(col_b,TOP+3,"small"), player=(col_a,TOP), turn_right=(side_r,TOP), status_x=col_a,
            y_move_label=ya, y_move_num=ya+18,
            y_visible=ya+78, y_harvest=ya+104, y_bases=ya+130, y_config=None,
            legend=[],
            y_reserve_label=ya+232, y_reserve_icons=ya+254, harvest_dx=132, harvest_step=34,
            msg=(col_b,ya), msg_line_h=20,
            container=(col_b,TOP+160),
            end=pygame.Rect(col_b,HEIGHT-MARGIN-56,col_w,56), end_label="END TURN",
            restart=pygame.Rect(col_a,HEIGHT-MARGIN-44,150,44),
            result=(col_a,HEIGHT-MARGIN-44-52),
            setup=dict(title=(MARGIN+10,MARGIN), sub=(MARGIN+10,MARGIN+38), x0=270, y0=84, row=52, bh=44,
                       cx0=560, wmin=84, wpad=24, wchar=10, step=(560,52,72,6), summary=6,
                       start=pygame.Rect(WIDTH//2-130,HEIGHT-76,260,58)),
        )
    # The window/canvas is always exactly the logical size. In the browser the
    # page fits it to the phone screen with CSS (see fit_web_canvas), which also
    # survives rotating the phone.
    screen=pygame.display.set_mode((WIDTH,HEIGHT))

# Browser only: make the canvas fit the screen (portrait or landscape) with the
# right proportions, stop double-tap zoom / scrolling, and keep it centered.
WEB_FIT_JS = """(function(){
if(document.getElementById('gdg-fit-style')) return;
var css = 'html,body{margin:0;padding:0;width:100%;height:100%;overflow:hidden;background:#1c1e20 !important;touch-action:none;overscroll-behavior:none;-webkit-user-select:none;user-select:none;-webkit-touch-callout:none;}'
 + 'canvas#canvas,canvas.emscripten{position:absolute !important;left:0 !important;right:0 !important;top:0 !important;bottom:0 !important;margin:auto !important;'
 + 'width:auto !important;height:auto !important;max-width:100vw !important;max-height:100vh !important;max-width:100dvw !important;max-height:100dvh !important;'
 + 'touch-action:none !important;background:#1c1e20 !important;}';
var st=document.createElement('style'); st.id='gdg-fit-style'; st.textContent=css; document.head.appendChild(st);
var m=document.querySelector('meta[name=viewport]');
if(m) m.setAttribute('content','width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no');
document.addEventListener('contextmenu',function(e){e.preventDefault();});
})();"""

def fit_web_canvas():
    if sys.platform!="emscripten": return
    try:
        import platform
        platform.window.eval(WEB_FIT_JS)
    except Exception as e:
        print("fit_web_canvas failed:",repr(e))

FULLSCREEN_JS = """(function(){
var d=document,e=d.documentElement;
var inFs=d.fullscreenElement||d.webkitFullscreenElement;
if(inFs){ var x=d.exitFullscreen||d.webkitExitFullscreen; if(x) x.call(d); return; }
var f=e.requestFullscreen||e.webkitRequestFullscreen;
if(!f) return;
var p=f.call(e);
var lock=function(){ try{ var o=screen.orientation; if(o&&o.lock){ var q=o.lock('landscape'); if(q&&q.catch) q.catch(function(){}); } }catch(x){} };
if(p&&p.then){ p.then(lock).catch(function(){}); } else { lock(); }
})();"""

def toggle_fullscreen():
    if sys.platform!="emscripten": return
    try:
        import platform
        platform.window.eval(FULLSCREEN_JS)
    except Exception as e:
        print("toggle_fullscreen failed:",repr(e))

def window_aspect():
    """Browser window width/height, or None when not in the browser."""
    if sys.platform!="emscripten": return None
    try:
        import platform
        w=float(platform.window.innerWidth); h=float(platform.window.innerHeight)
        return w/h if h>0 else None
    except Exception:
        return None

def auto_layout():
    """PC window on a desktop; in the browser pick by screen shape:
    wide (phone sideways) / portrait -> 'phone', squarer (iPad landscape) -> 'tablet'."""
    if sys.platform!="emscripten": return "pc"
    a=window_aspect()
    if a is not None and 1.0<a<1.6: return "tablet"
    return "phone"

# PC window on a desktop, phone layout in the browser. Changeable on the setup screen.
set_layout(auto_layout())
fit_web_canvas()

UI={"restart_until":0,"picked":False}   # restart button asks for a second tap within 2.5 s

@dataclass
class Person:
    owner:int
    leader:bool=False
    @property
    def strength(self): return 2 if self.leader else 1

@dataclass
class Token:
    owner:int
    x:int
    y:int
    people:list=field(default_factory=list)
    vehicle:bool=False
    def strength(self): return sum(p.strength for p in self.people)
    def has_leader(self): return any(p.leader for p in self.people)
    def regular_count(self): return sum(1 for p in self.people if not p.leader)
    def visible_presence(self):
        return 1 if self.vehicle else len(self.people)

@dataclass
class Base:
    x:int
    y:int
    owner:int|None
    people:list=field(default_factory=list)
    # Leaders are never allowed inside bases.
    def defense(self):
        return 1 + len(self.people)
    def has_leader(self): return False
    def regular_count(self): return sum(1 for p in self.people if not p.leader)

class Game:
    def __init__(self,players=2,grid=13,base_move=4,unit_cap=6,
                 starting_pawns=3,starting_vehicle=True,draw_winner="defender"):
        self.players=players
        self.grid=grid
        self.base_move=base_move
        self.unit_cap=unit_cap
        self.starting_pawns=starting_pawns
        self.starting_vehicle=starting_vehicle
        self.draw_winner=draw_winner
        self.current=0; self.turn=1
        self.tokens=[]; self.bases={}
        c=self.grid//2
        d=(c+1)//2
        self.harvest_tiles=[(c,c-d),(c+d,c),(c,c+d),(c-d,c)]
        self.harvest_active={p:{h:True for h in self.harvest_tiles} for p in range(players)}
        self.harvest_pending={p:{h:False for h in self.harvest_tiles} for p in range(players)}
        self.harvest_marks=[0]*players
        self.reinforcement_credits=[0]*players
        self.reserve=[0]*players
        self.reserve_vehicles=[0]*players
        self.alive=[True]*players
        self.move_left=0
        self.action_taken=False
        self.selected=None
        self.selected_person_idx=None
        self.message=""
        self.privacy=True
        self.reveal_debug=False
        self.winner=None; self.draw=False
        self.log=[]
        self.setup_board()

    def setup_board(self):
        m=self.grid-1
        corners=[(0,0),(m,0),(m,m),(0,m)]
        vehicle_spots=[(0,1),(m,1),(m,m-1),(0,m-1)]
        # Leader starts diagonally next to its base (B2 when the base is A1).
        leader_spots=[(1,1),(m-1,1),(m-1,m-1),(1,m-1)]

        # Which corner each player sits in. 2 players face each other across the board.
        seats=[0,2] if self.players==2 else list(range(self.players))

        for i,pos in enumerate(corners):
            self.bases[pos]=Base(*pos,seats.index(i) if i in seats else None)

        c=self.grid//2
        self.bases[(c,c)]=Base(c,c,None)

        for p in range(self.players):
            s=seats[p]
            b=self.bases[corners[s]]
            b.people=[Person(p,False) for _ in range(self.starting_pawns)]

            lx,ly=leader_spots[s]
            self.tokens.append(Token(p,lx,ly,[Person(p,True)],False))

            if self.starting_vehicle:
                vx,vy=vehicle_spots[s]
                self.tokens.append(Token(p,vx,vy,[],True))

        self.start_turn()

    def log_event(self,event_type,**data):
        self.log.append({"turn":self.turn,"player":self.current,"kind":event_type,**data})

    def controlled_bases(self,p):
        return [b for b in self.bases.values() if b.owner==p]

    def token_at(self,x,y):
        return next((t for t in self.tokens if t.x==x and t.y==y),None)

    def visible_regulars(self,p):
        return sum(t.regular_count() for t in self.tokens if t.owner==p and not t.vehicle)

    def visible_units(self,p):
        """
        Visible UNIT cap:
        - each exposed person outside a vehicle/base = 1
        - each vehicle token = 1, regardless of occupants
        Hidden occupants add 0.
        """
        total=0
        for t in self.tokens:
            if t.owner!=p:
                continue
            total += 1 if t.vehicle else len(t.people)
        return total

    def visible_presence(self,p):
        # The same visible-unit count generates movement.
        return self.visible_units(p)

    def adjacent(self,a,b):
        return abs(a[0]-b[0])+abs(a[1]-b[1])==1

    def start_turn(self):
        if self.winner is not None or self.draw: return
        self.move_left=self.base_move+self.visible_presence(self.current)
        self.action_taken=False
        self.selected=None; self.selected_person_idx=None
        self.message=f"Player {self.current+1}: {self.move_left} movement."
        self.check_victory()

    def end_turn_allowed(self):
        if not self.action_taken:
            return False
        if self.reinforcement_credits[self.current]>0 and self.controlled_bases(self.current):
            return False
        return True

    def next_turn(self):
        if self.winner is not None or self.draw: return
        if not self.end_turn_allowed():
            if not self.action_taken:
                self.message="You must make at least one move before ending your turn."
            else:
                self.message="Choose your reinforcement before ending the turn."
            return

        before_credits=self.reinforcement_credits[self.current]
        self.collect_end_turn_harvests(self.current)
        new_credit=self.reinforcement_credits[self.current] > before_credits
        if new_credit and self.controlled_bases(self.current):
            # Stay on the current turn so the player can choose the reward first.
            return

        self.resolve_harvest_respawns(self.current)
        for _ in range(self.players):
            self.current=(self.current+1)%self.players
            if self.alive[self.current]: break
        self.turn+=1
        self.privacy=True
        self.start_turn()

    def remove_one_regular(self,people):
        for i,p in enumerate(people):
            if not p.leader:
                people.pop(i); return True
        return False

    def remove_dead_player_assets(self,p):
        self.tokens=[t for t in self.tokens if t.owner!=p]
        for b in self.bases.values():
            if b.owner==p:
                b.owner=None; b.people=[]

    def eliminate_players_simultaneously(self,players):
        victims={p for p in players if 0<=p<self.players and self.alive[p]}
        for p in victims:
            self.alive[p]=False
            self.log_event("leader_killed",victim=p)
        for p in victims:
            self.remove_dead_player_assets(p)
        self.check_victory()

    def check_victory(self):
        if self.winner is not None or self.draw: return
        living=[p for p in range(self.players) if self.alive[p]]
        if len(living)==0:
            self.draw=True; self.finish_game("simultaneous_leader_death",None); return
        if len(living)==1:
            self.winner=living[0]; self.finish_game("last_leader",self.winner); return
        m=self.grid-1
        corners=[(0,0),(m,0),(m,m),(0,m)]
        for p in living:
            if all(self.bases[c].owner==p for c in corners):
                self.winner=p; self.finish_game("four_corner_bases",p); return

    def finish_game(self,reason,winner):
        self.log_event("game_over",winner=winner,reason=reason)
        self.message="DRAW" if winner is None else f"PLAYER {winner+1} WINS — {reason.replace('_',' ').upper()}"
        try:
            out=Path(__file__).with_name("match_"+datetime.now().strftime("%Y%m%d_%H%M%S")+".json")
            out.write_text(json.dumps({
                "version":VERSION,"players":self.players,"winner":winner,
                "reason":reason,"turns":self.turn,
                "settings":{
                    "grid":self.grid,
                    "base_move":self.base_move,
                    "unit_cap":self.unit_cap,
                    "starting_pawns":self.starting_pawns,
                    "starting_vehicle":self.starting_vehicle,
                    "draw_winner":self.draw_winner
                },
                "events":self.log
            },indent=2),encoding="utf-8")
        except Exception:
            pass

    # ---------- pathing ----------
    def square_blocks_path(self,pos,owner,goal):
        if pos==goal:
            return False
        t=self.token_at(*pos)
        if t is not None:
            # Friendly units may be crossed; enemies block.
            return t.owner!=owner
        if pos in self.bases:
            # Bases are solid except when they are the destination.
            return True
        return False

    def find_path(self,start,goal,owner):
        q=deque([start]); prev={start:None}
        while q:
            cur=q.popleft()
            if cur==goal: break
            x,y=cur
            for nxt in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                nx,ny=nxt
                if not (0<=nx<self.grid and 0<=ny<self.grid) or nxt in prev: continue
                if self.square_blocks_path(nxt,owner,goal): continue
                prev[nxt]=cur; q.append(nxt)
        if goal not in prev: return None
        path=[]; cur=goal
        while cur!=start:
            path.append(cur); cur=prev[cur]
        path.reverse()
        return path

    def harvest_kind_map(self):
        return {pos:HARVEST_ORDER[i] for i,pos in enumerate(self.harvest_tiles)}

    def harvest_collected_this_cycle(self,p,pos):
        # Collected already this cycle, but not waiting for the next cycle reset.
        return (not self.harvest_active[p].get(pos,False)) and (not self.harvest_pending[p].get(pos,False))

    def collect_end_turn_harvests(self,p):
        collected=[]
        for t in self.tokens:
            if t.owner!=p:
                continue
            pos=(t.x,t.y)
            if pos in self.harvest_tiles and self.harvest_active[p].get(pos,False):
                self.collect_harvest(p,pos)
                collected.append(pos)
        return collected

    def collect_harvest_along_path(self,owner,path):
        # v0.11.2: harvest is no longer collected by passing through.
        # A harvest is gained only if a unit ends the turn on its tile.
        return

    def reachable_empty_tiles(self,t):
        """
        Empty destinations this selected token can legally reach with the
        movement points currently remaining. Friendly units may be crossed,
        enemies and bases block paths as usual.
        """
        if self.move_left <= 0:
            return set()
        if t.vehicle and not t.people:
            return set()

        start=(t.x,t.y)
        reachable=set()
        q=deque([(start,0)])
        seen={start}

        while q:
            cur,dist=q.popleft()
            if dist>=self.move_left:
                continue
            x,y=cur
            for nxt in ((x+1,y),(x-1,y),(x,y+1),(x,y-1)):
                nx,ny=nxt
                if not (0<=nx<self.grid and 0<=ny<self.grid):
                    continue
                if nxt in seen:
                    continue

                tok=self.token_at(nx,ny)
                base=self.bases.get(nxt)

                # Enemy units and any base stop path expansion.
                if tok is not None and tok.owner != t.owner:
                    continue
                if base is not None:
                    continue

                seen.add(nxt)
                nd=dist+1

                # Friendly units may be crossed but are not empty destinations.
                if tok is None:
                    reachable.add(nxt)

                q.append((nxt,nd))

        return reachable

    def reachable_interaction_targets(self,t):
        """
        Returns:
          friendly: set of reachable occupied friendly destinations
          hostile: set of reachable enemy/base destinations that trigger attack/capture

        Empty vehicle cannot move, so it has no reachable interaction targets.
        """
        friendly=set()
        hostile=set()

        if self.move_left <= 0:
            return friendly,hostile
        if t.vehicle and not t.people:
            return friendly,hostile

        start=(t.x,t.y)

        # Tokens
        for other in self.tokens:
            if other is t:
                continue
            goal=(other.x,other.y)
            path=self.find_path(start,goal,t.owner)
            if path is None or len(path)>self.move_left:
                continue

            if other.owner==t.owner:
                # Friendly interaction only if there is a legal reason to go there.
                if other.vehicle:
                    # Can board if capacity permits.
                    if len(other.people)+len(t.people) <= MAX_GROUP:
                        friendly.add(goal)
                elif not t.vehicle and len(other.people)+len(t.people) <= MAX_GROUP:
                    # Open friendly people can merge.
                    friendly.add(goal)
            else:
                # Any reachable enemy token can be attacked/captured.
                hostile.add(goal)

        # Bases
        for goal,b in self.bases.items():
            path=self.find_path(start,goal,t.owner)
            if path is None or len(path)>self.move_left:
                continue

            if b.owner==t.owner:
                # Vehicle can never enter. Lone leader can never enter.
                # A group containing regular pawns may enter them.
                if not t.vehicle and t.regular_count()>0 and len(b.people)<4:
                    friendly.add(goal)
            else:
                # Neutral and enemy bases are actionable attack/capture targets.
                hostile.add(goal)

        return friendly,hostile

    # ---------- movement / interaction ----------
    def try_move_or_interact(self,t,nx,ny):
        if self.move_left<=0:
            self.message="No movement left."; return
        if t.vehicle and not t.people:
            # Empty vehicle cannot move, but it remains a valid visible token.
            self.message="Empty vehicle cannot move."; return

        goal=(nx,ny)
        path=self.find_path((t.x,t.y),goal,t.owner)
        if path is None:
            self.message="No legal path."; return
        cost=len(path)
        if cost>self.move_left:
            self.message=f"Need {cost} movement; only {self.move_left} left."; return

        target=self.token_at(nx,ny)
        base=self.bases.get(goal)

        # Empty destination.
        if target is None and base is None:
            t.x,t.y=nx,ny
            self.move_left-=cost
            self.action_taken=True
            self.collect_harvest_along_path(t.owner,path)
            self.log_event("move",to=[nx,ny],cost=cost,vehicle=t.vehicle,strength=t.strength())
            self.selected=t; self.selected_person_idx=None
            self.message=f"Moved {cost} tile"+("s." if cost!=1 else ".")
            return

        # Friendly token endpoint.
        if target is not None and target.owner==self.current:
            if target is t:
                self.selected=None; self.selected_person_idx=None
                return
            self.collect_harvest_along_path(t.owner,path[:-1])
            self.merge_tokens(t,target,cost)
            return

        # Enemy token endpoint.
        if target is not None and target.owner!=self.current:
            self.collect_harvest_along_path(t.owner,path[:-1])
            if target.vehicle and not target.people:
                # Loot rule: empty enemy vehicle has 0 DEF and is captured intact.
                # If the attacker is an exposed person/group, they immediately board
                # the vehicle they just stole instead of remaining on the origin tile.
                old=target.owner
                self.move_left-=cost
                self.action_taken=True
                self.release_reserve_slots(old,1)

                if not t.vehicle:
                    boarded_people=list(t.people)
                    target.owner=self.current
                    target.people.extend(boarded_people)
                    if t in self.tokens:
                        self.tokens.remove(t)

                    # The exposed attackers have collapsed into one visible vehicle.
                    # Any newly freed visible-unit slots may immediately release reserve.
                    freed=max(0,len(boarded_people)-1)
                    if freed:
                        self.release_reserve_slots(self.current,freed)

                    self.log_event(
                        "vehicle_captured",
                        from_player=old,
                        at=[nx,ny],
                        to_reserve=False,
                        boarded=len(boarded_people)
                    )
                    self.message=f"Captured Player {old+1}'s empty vehicle and boarded it."
                    self.selected=target
                    self.selected_person_idx=None

                else:
                    # Occupied vehicle cannot board another vehicle.
                    # It advances to the final square before the captured vehicle,
                    # while the stolen empty vehicle remains on its own tile.
                    approach = path[-2] if len(path) >= 2 else (t.x,t.y)
                    t.x,t.y = approach

                    if self.visible_units(self.current) >= self.unit_cap:
                        self.tokens.remove(target)
                        self.reserve_vehicles[self.current]+=1
                        self.log_event(
                            "vehicle_captured",
                            from_player=old,
                            at=[nx,ny],
                            to_reserve=True,
                            attacker_approach=list(approach)
                        )
                        self.message=f"Captured Player {old+1}'s empty vehicle; sent to reserve."
                        self.selected=t
                        self.selected_person_idx=None
                    else:
                        target.owner=self.current
                        self.log_event(
                            "vehicle_captured",
                            from_player=old,
                            at=[nx,ny],
                            to_reserve=False,
                            attacker_approach=list(approach)
                        )
                        self.message=f"Captured Player {old+1}'s empty vehicle."
                        self.selected=t
                        self.selected_person_idx=None
                return
            self.resolve_field_combat(t,target,cost)
            return

        # Base endpoint.
        if base is not None:
            self.collect_harvest_along_path(t.owner,path[:-1])
            if base.owner==self.current:
                self.enter_friendly_base(t,base,cost)
            else:
                # The base tile itself is the final path step. A leader supports the
                # assault from the square immediately before it rather than remaining
                # back on the square where the move started.
                approach = path[-2] if len(path) >= 2 else (t.x,t.y)
                self.resolve_base_attack(t,base,cost,approach)
            return

    def merge_tokens(self,src,dst,cost):
        if src.vehicle and dst.vehicle:
            self.message="Vehicles cannot merge."; return
        if dst.vehicle:
            if len(dst.people)+len(src.people)>MAX_GROUP:
                self.message="Vehicle capacity is 4."; return
            hidden_regs=src.regular_count()
            dst.people.extend(src.people)
            self.tokens.remove(src)
            self.move_left-=cost
            self.action_taken=True
            self.release_reserve_slots(src.owner,hidden_regs + (1 if src.has_leader() else 0))
            self.selected=dst; self.selected_person_idx=None
            self.log_event("board_vehicle",at=[dst.x,dst.y],count=len(dst.people),cost=cost)
            return
        if src.vehicle:
            self.message="Select an occupant in the vehicle panel to unload it."; return
        if len(src.people)+len(dst.people)>MAX_GROUP:
            self.message="Group capacity is 4."; return
        dst.people.extend(src.people)
        self.tokens.remove(src)
        self.move_left-=cost
        self.action_taken=True
        self.selected=dst; self.selected_person_idx=None
        self.log_event("merge_group",at=[dst.x,dst.y],cost=cost)

    def enter_friendly_base(self,t,b,cost):
        if t.vehicle:
            self.message="Vehicles cannot enter bases."; return

        regs=[p for p in t.people if not p.leader]
        if not regs:
            self.message="Leader can never enter a base."; return

        free=4-len(b.people)
        if free<=0:
            self.message="Base is full."; return

        entering=regs[:free]
        for p in entering:
            t.people.remove(p); b.people.append(p)

        self.move_left-=cost
        self.action_taken=True
        self.release_reserve_slots(t.owner,len(entering))
        self.log_event("enter_base",base=[b.x,b.y],count=len(entering),cost=cost)

        if not t.people:
            self.tokens.remove(t); self.selected=b
        else:
            # Any leader in the moving group remains outside on the origin square.
            self.selected=t
        self.selected_person_idx=None

    # ---------- container panel ----------
    def container_people(self,obj):
        if isinstance(obj,Base): return obj.people
        if isinstance(obj,Token) and obj.vehicle: return obj.people
        return None

    def deploy_selected_person(self,obj,idx,nx,ny):
        people=self.container_people(obj)
        if people is None or idx is None or idx<0 or idx>=len(people):
            return
        person=people[idx]
        start=(obj.x,obj.y)
        goal=(nx,ny)

        target_token=self.token_at(nx,ny)
        target_base=self.bases.get(goal)

        # Direct transfer into a friendly vehicle.
        if target_token is not None and target_token.owner==self.current and target_token.vehicle:
            if target_token is obj:
                self.message="Already inside this vehicle."
                return
            if len(target_token.people)>=4:
                self.message="Vehicle is full."
                return
            path=self.find_path(start,goal,self.current)
            if path is None:
                self.message="No legal path to vehicle."
                return
            cost=len(path)
            if cost>self.move_left:
                self.message=f"Need {cost} movement; only {self.move_left} left."
                return
            people.pop(idx)
            target_token.people.append(person)
            self.move_left-=cost
            self.action_taken=True
            # A regular pawn leaving open/container logic: if it came from a base it was already hidden;
            # if it came from a vehicle it remains hidden, so no reserve release here.
            self.log_event("container_transfer",
                           source="base" if isinstance(obj,Base) else "vehicle",
                           target="vehicle",leader=person.leader,to=[nx,ny],cost=cost)
            self.selected=target_token; self.selected_person_idx=None
            self.message=("Leader" if person.leader else "Pawn")+f" transferred to vehicle, cost {cost}."
            return

        # Direct transfer into a friendly base: regular pawns only.
        if target_base is not None and target_base.owner==self.current:
            if person.leader:
                self.message="Leader can never enter a base."
                return
            if len(target_base.people)>=4:
                self.message="Base is full."
                return
            path=self.find_path(start,goal,self.current)
            if path is None:
                self.message="No legal path to base."
                return
            cost=len(path)
            if cost>self.move_left:
                self.message=f"Need {cost} movement; only {self.move_left} left."
                return
            people.pop(idx)
            target_base.people.append(person)
            self.move_left-=cost
            self.action_taken=True
            self.log_event("container_transfer",
                           source="base" if isinstance(obj,Base) else "vehicle",
                           target="base",leader=False,to=[nx,ny],cost=cost)
            self.selected=target_base; self.selected_person_idx=None
            self.message=f"Pawn transferred to base, cost {cost}."
            return

        # Otherwise exit onto an empty board tile.
        if target_token is not None or target_base is not None:
            self.message="Choose an empty tile, friendly vehicle, or friendly base."
            return

        if self.visible_units(self.current)>=self.unit_cap:
            self.message=f"Visible unit cap is {self.unit_cap}."
            return

        path=self.find_path(start,goal,self.current)
        if path is None:
            self.message="No legal path from container."
            return
        cost=len(path)
        if cost<1:
            return
        if cost>self.move_left:
            self.message=f"Need {cost} movement; only {self.move_left} left."
            return

        people.pop(idx)
        new=Token(self.current,nx,ny,[person],False)
        self.tokens.append(new)
        self.move_left-=cost
        self.action_taken=True
        self.collect_harvest_along_path(self.current,path)
        self.log_event("exit_container",
                       source="base" if isinstance(obj,Base) else "vehicle",
                       leader=person.leader,to=[nx,ny],cost=cost)
        self.selected=new; self.selected_person_idx=None
        self.message=("Leader" if person.leader else "Pawn")+f" exited, cost {cost}."

    # ---------- reserve ----------
    def find_spawn_outside_base(self,p):
        for b in self.controlled_bases(p):
            for x,y in ((b.x+1,b.y),(b.x-1,b.y),(b.x,b.y+1),(b.x,b.y-1)):
                if 0<=x<self.grid and 0<=y<self.grid and self.token_at(x,y) is None and (x,y) not in self.bases:
                    return (x,y)
        return None

    def inject_one_pawn_from_reserve(self,p):
        if self.reserve[p] <= 0 or not self.controlled_bases(p):
            return False

        # Hidden base slots do not count against visible-unit cap.
        for b in self.controlled_bases(p):
            if len(b.people) < 4:
                b.people.append(Person(p,False))
                self.reserve[p] -= 1
                self.log_event("reserve_deployed",reserve_type="pawn",location="base",
                               base=[b.x,b.y],reserve=self.reserve[p])
                return True

        # If all bases are full, pawn may appear outside only if a visible slot exists.
        if self.visible_units(p) < self.unit_cap:
            spot=self.find_spawn_outside_base(p)
            if spot is not None:
                x,y=spot
                self.tokens.append(Token(p,x,y,[Person(p,False)],False))
                self.reserve[p]-=1
                self.log_event("reserve_deployed",reserve_type="pawn",location="outside",
                               at=[x,y],reserve=self.reserve[p])
                return True
        return False

    def inject_one_vehicle_from_reserve(self,p):
        if self.reserve_vehicles[p] <= 0 or not self.controlled_bases(p):
            return False
        if self.visible_units(p) >= self.unit_cap:
            return False
        spot=self.find_spawn_outside_base(p)
        if spot is None:
            return False
        x,y=spot
        self.tokens.append(Token(p,x,y,[],True))
        self.reserve_vehicles[p]-=1
        self.log_event("reserve_deployed",reserve_type="vehicle",at=[x,y],
                       reserve_vehicles=self.reserve_vehicles[p])
        return True

    def release_reserve_slots(self,p,count):
        """
        A visible unit disappeared. First, any reserve pawns may fill empty base slots
        (hidden, so they do not consume visible capacity). Then each newly available
        visible slot can bring out a reserve vehicle or, if bases are full, a pawn.
        """
        self.fill_hidden_base_slots_from_pawn_reserve(p)
        for _ in range(count):
            if self.visible_units(p) >= self.unit_cap:
                break
            if self.inject_one_vehicle_from_reserve(p):
                continue
            if self.inject_one_pawn_from_reserve(p):
                continue
            break

    def fill_hidden_base_slots_from_pawn_reserve(self,p):
        changed=False
        while self.reserve[p] > 0:
            placed=False
            for b in self.controlled_bases(p):
                if len(b.people)<4:
                    b.people.append(Person(p,False))
                    self.reserve[p]-=1
                    placed=True; changed=True
                    self.log_event("reserve_deployed",reserve_type="pawn",
                                   location="base",base=[b.x,b.y],reserve=self.reserve[p])
                    break
            if not placed:
                break
        return changed

    def grant_new_pawn(self,p):
        """
        Priority:
        1) owned base slot, regardless of visible-unit count
        2) if every base is full and visible-unit count < 6, spawn outside
        3) otherwise reserve
        """
        for b in self.controlled_bases(p):
            if len(b.people)<4:
                b.people.append(Person(p,False))
                return "base"

        if self.visible_units(p) < self.unit_cap:
            spot=self.find_spawn_outside_base(p)
            if spot is not None:
                x,y=spot
                self.tokens.append(Token(p,x,y,[Person(p,False)],False))
                return "outside"

        self.reserve[p]+=1
        return "reserve"

    def grant_new_vehicle(self,p):
        if self.visible_units(p) >= self.unit_cap:
            self.reserve_vehicles[p]+=1
            return "reserve"
        spot=self.find_spawn_outside_base(p)
        if spot is not None:
            x,y=spot
            self.tokens.append(Token(p,x,y,[],True))
            return "outside"
        self.reserve_vehicles[p]+=1
        return "reserve"

    # ---------- combat ----------
    def resolve_field_combat(self,atk,dfn,cost):
        A,D=atk.strength(),dfn.strength()
        self.message=f"Combat: ATK {A} vs DEF {D}. "
        self.log_event("combat",location=[dfn.x,dfn.y],atk=A,defense=D,base=False,cost=cost)

        if A>D:
            victim=dfn.owner; killed_regs=dfn.regular_count(); leader=dfn.has_leader()
            lost_visible = 1 if dfn.vehicle else len(dfn.people)
            dx,dy=dfn.x,dfn.y
            self.tokens.remove(dfn)
            atk.x,atk.y=dx,dy
            self.move_left-=cost
            self.action_taken=True
            self.release_reserve_slots(victim,lost_visible)
            self.message+="Attacker wins."
            if leader: self.eliminate_players_simultaneously([victim])

        elif A<D:
            victim=atk.owner; killed_regs=atk.regular_count(); leader=atk.has_leader()
            lost_visible = 1 if atk.vehicle else len(atk.people)
            self.tokens.remove(atk); self.selected=None
            self.move_left-=cost
            self.action_taken=True
            self.release_reserve_slots(victim,lost_visible)
            self.message+="Defender wins."
            if leader: self.eliminate_players_simultaneously([victim])

        else:
            atk_owner,dfn_owner=atk.owner,dfn.owner

            if self.draw_winner=="defender":
                # Defender holds; attacker is eliminated; defender loses one pawn.
                atk_leader=atk.has_leader()
                atk_lost_visible = 1 if atk.vehicle else len(atk.people)
                dfn_leader_dies=False
                self.tokens.remove(atk); self.selected=None
                self.release_reserve_slots(atk_owner,atk_lost_visible)

                if self.remove_one_regular(dfn.people):
                    pass
                elif dfn.has_leader():
                    dfn_leader_dies=True
                    if dfn in self.tokens: self.tokens.remove(dfn)

                self.message+="Tie: defender wins, but loses one pawn."
                victims=[]
                if atk_leader: victims.append(atk_owner)
                if dfn_leader_dies: victims.append(dfn_owner)
                if victims: self.eliminate_players_simultaneously(victims)
                if dfn in self.tokens and not dfn.people and not dfn.vehicle:
                    self.tokens.remove(dfn)

            else:
                # Attacker wins; defender is eliminated; attacker loses one pawn.
                dfn_leader=dfn.has_leader()
                dfn_lost_visible = 1 if dfn.vehicle else len(dfn.people)
                ax,ay=dfn.x,dfn.y
                self.tokens.remove(dfn)
                self.release_reserve_slots(dfn_owner,dfn_lost_visible)

                atk_leader_dies=False
                if self.remove_one_regular(atk.people):
                    pass
                elif atk.has_leader():
                    atk_leader_dies=True
                    if atk in self.tokens: self.tokens.remove(atk)

                if atk in self.tokens:
                    atk.x,atk.y=ax,ay
                    self.selected=atk
                else:
                    self.selected=None

                self.message+="Tie: attacker wins, but loses one pawn."
                victims=[]
                if dfn_leader: victims.append(dfn_owner)
                if atk_leader_dies: victims.append(atk_owner)
                if victims: self.eliminate_players_simultaneously(victims)

            self.move_left-=cost
            self.action_taken=True
        self.check_victory()

    def resolve_base_attack(self,atk,b,cost,approach=None):
        A,D=atk.strength(),b.defense()
        regs=[p for p in atk.people if not p.leader]
        attacking_leader=atk.has_leader()
        self.message=f"Base assault: ATK {A} vs DEF {D}. "
        self.log_event("combat",location=[b.x,b.y],atk=A,defense=D,base=True,cost=cost)

        if A>D:
            old=b.owner
            defending_leader=b.has_leader()
            killed_regs=b.regular_count()
            b.people=[]; b.owner=self.current

            # Regular attackers enter; leader stays outside.
            for p in list(regs)[:4]:
                if len(b.people)>=4: break
                if p in atk.people:
                    atk.people.remove(p); b.people.append(p)

            self.move_left-=cost
            self.action_taken=True
            self.message+="Base captured."
            self.log_event("base_captured",base=[b.x,b.y],previous_owner=old)

            if defending_leader and old is not None:
                self.eliminate_players_simultaneously([old])

            if atk in self.tokens:
                if not atk.people and not atk.vehicle:
                    self.tokens.remove(atk); self.selected=b
                else:
                    # Regular attackers enter the captured base; any surviving leader
                    # remains outside, on the last square before the base.
                    if attacking_leader and approach is not None:
                        atk.x,atk.y=approach
                    self.selected=atk
            self.selected_person_idx=None

        else:
            attacker_regs=len(regs)
            for p in list(atk.people):
                if not p.leader: atk.people.remove(p)
            self.release_reserve_slots(atk.owner,attacker_regs)

            defender_victim=None
            if A==D and self.draw_winner=="defender":
                if self.remove_one_regular(b.people):
                    pass
                self.message+="Tie: base holds but loses one pawn."

                self.move_left-=cost
                self.action_taken=True
                if not atk.people:
                    if atk in self.tokens: self.tokens.remove(atk)
                    self.selected=None
                else:
                    self.selected=atk
                self.selected_person_idx=None

            elif A==D and self.draw_winner=="attacker":
                # Attacker takes base, but loses one regular pawn from the assault.
                old=b.owner
                if regs:
                    lost=regs[0]
                    if lost in atk.people:
                        atk.people.remove(lost)

                b.people=[]
                b.owner=self.current

                for p in [q for q in list(atk.people) if not q.leader][:4]:
                    if len(b.people)>=4: break
                    atk.people.remove(p)
                    b.people.append(p)

                self.move_left-=cost
                self.action_taken=True
                self.message+="Tie: attacker captures base but loses one pawn."
                self.log_event("base_captured",base=[b.x,b.y],previous_owner=old,via_tie=True)

                if not atk.people and not atk.vehicle:
                    if atk in self.tokens: self.tokens.remove(atk)
                    self.selected=b
                else:
                    if attacking_leader and approach is not None and atk in self.tokens:
                        atk.x,atk.y=approach
                    self.selected=atk
                self.selected_person_idx=None

            else:
                self.message+="Base holds."
                self.move_left-=cost
                self.action_taken=True
                if not atk.people:
                    if atk in self.tokens: self.tokens.remove(atk)
                    self.selected=None
                else:
                    self.selected=atk
                self.selected_person_idx=None

        self.check_victory()

    # ---------- harvest ----------
    def collect_harvest(self,p,pos):
        if not self.harvest_active[p].get(pos,False): return
        self.harvest_active[p][pos]=False
        self.harvest_marks[p]+=1
        self.log_event("harvest",tile=list(pos),marks=self.harvest_marks[p])
        self.message=f"Harvest secured ({self.harvest_marks[p]}/4)."

        if self.harvest_marks[p]>=4:
            self.harvest_marks[p]=0
            # No immediate reset. All four wait until their tile is empty at end of turn.
            for h in self.harvest_tiles:
                self.harvest_active[p][h]=False
                self.harvest_pending[p][h]=True
            self.reinforcement_credits[p]+=1
            self.log_event("harvest_cycle_complete",credits=self.reinforcement_credits[p])
            self.message="Harvest cycle complete. Choose reinforcement before ending turn."

    def resolve_harvest_respawns(self,p):
        for h in self.harvest_tiles:
            if not self.harvest_pending[p][h]: continue
            occupied=self.token_at(*h) is not None
            if not occupied:
                self.harvest_pending[p][h]=False
                self.harvest_active[p][h]=True

    # ---------- reinforcements ----------
    def spawn_reinforcement(self,choice):
        p=self.current
        if self.reinforcement_credits[p]<=0: return
        if not self.controlled_bases(p):
            self.message="Credit held: you need a base."; return

        if choice=="pawns":
            results=[self.grant_new_pawn(p),self.grant_new_pawn(p)]
            self.reinforcement_credits[p]-=1
            self.log_event("reinforcement",reinforcement_type="2_pawns",
                           results=results,reserve=self.reserve[p])
            self.message=f"+2 pawns: {results.count('reserve')} to reserve."
        else:
            result=self.grant_new_vehicle(p)
            self.reinforcement_credits[p]-=1
            self.log_event("reinforcement",reinforcement_type="vehicle",
                           result=result,reserve_vehicles=self.reserve_vehicles[p])
            self.message="Vehicle reinforcement: "+("placed." if result=="outside" else "sent to reserve.")

def board_offset(grid):
    spare=(MAX_GRID-grid)*CELL
    return MARGIN+spare//2, TOP+spare//2

def cell_rect(x,y,grid=MAX_GRID):
    ox,oy=board_offset(grid)
    return pygame.Rect(ox+x*CELL,oy+y*CELL,CELL,CELL)

def cell_center(x,y,grid=MAX_GRID):
    return cell_rect(x,y,grid).center

def draw_text(s,pos,f=None,color=TEXT): screen.blit((f or font).render(str(s),True,color),pos)

def draw_harvest_glyph(kind,center,color,size=18,width=2):
    """Simple harvest silhouettes.
    width=0 -> filled / lit version.
    width>0 -> outline/muted version.
    """
    cx,cy=center
    s=size
    filled=(width==0)
    line_w=max(1,width)

    if kind=="forest":
        tri1=[(cx,cy-s//2),(cx-s//3,cy-s//8),(cx+s//3,cy-s//8)]
        tri2=[(cx,cy-s//4),(cx-s//2+1,cy+s//7),(cx+s//2-1,cy+s//7)]
        trunk=pygame.Rect(cx-max(2,s//10),cy+s//7,max(4,s//5),max(4,s//4))
        if filled:
            pygame.draw.polygon(screen,color,tri1,0)
            pygame.draw.polygon(screen,color,tri2,0)
            pygame.draw.rect(screen,color,trunk,0)
        else:
            pygame.draw.polygon(screen,color,tri1,line_w)
            pygame.draw.polygon(screen,color,tri2,line_w)
            pygame.draw.rect(screen,color,trunk,line_w)

    elif kind=="fish":
        body=pygame.Rect(cx-s//2+2,cy-s//4,s-6,max(8,s//2))
        tail=[(cx+s//2-4,cy),(cx+s//2+4,cy-s//4),(cx+s//2+4,cy+s//4)]
        eye=(cx-s//5,cy-1)
        if filled:
            pygame.draw.ellipse(screen,color,body,0)
            pygame.draw.polygon(screen,color,tail,0)
            pygame.draw.circle(screen,BG,eye,1)
        else:
            pygame.draw.ellipse(screen,color,body,line_w)
            pygame.draw.polygon(screen,color,tail,line_w)
            pygame.draw.circle(screen,color,eye,1)

    elif kind=="oil":
        # Replaced with a simple mountain silhouette.
        left=(cx-s//2, cy+s//3)
        peak=(cx-s//10, cy-s//2)
        right=(cx+s//2, cy+s//3)
        ridge=(cx+s//8, cy-s//8)
        if filled:
            pygame.draw.polygon(screen,color,[left, peak, ridge, right],0)
        else:
            pygame.draw.lines(screen,color,False,[left, peak, ridge, right],line_w)
            pygame.draw.line(screen,color,left,right,line_w)

    elif kind=="factory":
        # Clearer triangular/sawtooth roof with a much taller far-right chimney.
        left=cx-s//2
        right=cx+s//2
        bottom=cy+s//3
        roof_y=cy-s//12
        p1=(cx-s//5, roof_y-s//4)
        p2=(cx+s//18, roof_y)
        p3=(cx+s//4, roof_y-s//4)
        poly=[(left,bottom),(left,roof_y),(p1[0],p1[1]),(p2[0],p2[1]),(p3[0],p3[1]),(right,roof_y),(right,bottom)]
        chim_w=max(3,s//7+2)
        chim_h=max(9,s//2+1)
        chim=pygame.Rect(right-chim_w+1, cy-s//2-s//6, chim_w, chim_h)
        w1=pygame.Rect(cx-s//5,bottom-s//6,max(2,s//8+1),max(2,s//8+1))
        w2=pygame.Rect(cx+1,bottom-s//6,max(2,s//8+1),max(2,s//8+1))
        if filled:
            pygame.draw.polygon(screen,color,poly,0)
            pygame.draw.rect(screen,color,chim,0)
            pygame.draw.rect(screen,BG,w1,0)
            pygame.draw.rect(screen,BG,w2,0)
        else:
            pygame.draw.lines(screen,color,False,poly,line_w)
            pygame.draw.line(screen,color,(left,bottom),(right,bottom),line_w)
            pygame.draw.rect(screen,color,chim,line_w)
            pygame.draw.rect(screen,color,w1,line_w)
            pygame.draw.rect(screen,color,w2,line_w)

def wrap_text(text,width=None):
    width=width or WRAP
    words=text.split(); lines=[]; line=""
    for w in words:
        test=(line+" "+w).strip()
        if len(test)>width:
            if line: lines.append(line)
            line=w
        else: line=test
    if line: lines.append(line)
    return lines

def container_slot_rects(px,y0):
    size=SLOT; gap=10
    return [
        pygame.Rect(px,y0,size,size),
        pygame.Rect(px+size+gap,y0,size,size),
        pygame.Rect(px,y0+size+gap,size,size),
        pygame.Rect(px+size+gap,y0+size+gap,size,size)
    ]

def draw_container_panel(g,px,y0):
    obj=g.selected
    people=g.container_people(obj)
    if people is None or getattr(obj,"owner",None)!=g.current:
        return []
    title="BASE" if isinstance(obj,Base) else "VEHICLE"
    draw_text(title,(px,y0),font_small,MUTED)
    slots=container_slot_rects(px,y0+24)
    for i,r in enumerate(slots):
        pygame.draw.rect(screen,SLOT_BG,r)
        pygame.draw.rect(screen,SELECT if g.selected_person_idx==i else MUTED,r,2 if g.selected_person_idx==i else 1)
        if i<len(people):
            p=people[i]
            c=PLAYER_COLORS[p.owner]
            cx,cy=r.center
            if p.leader:
                pygame.draw.polygon(screen,c,[(cx,cy-14),(cx-13,cy+11),(cx+13,cy+11)],3)
            else:
                pygame.draw.circle(screen,c,(cx,cy),13,3)
    draw_text("Tap slot, then tile",(px,y0+158),font_small,MUTED)
    return slots

def draw_game(g):
    screen.fill(BG)

    for y in range(g.grid):
        for x in range(g.grid):
            pygame.draw.rect(screen,GRID_C,cell_rect(x,y,g.grid),1)

    kind_map=g.harvest_kind_map()
    for h in g.harvest_tiles:
        active=g.harvest_active[g.current][h]
        pending=g.harvest_pending[g.current][h]
        cx,cy=cell_center(*h,g.grid)
        col=HARVEST_ON if active else HARVEST_OFF
        draw_harvest_glyph(kind_map[h],(cx,cy),col,size=ps(20),width=0 if active else 2)
        if pending:
            pygame.draw.circle(screen,HARVEST_OFF,(cx,cy),ps(13),1)

    for pos,b in g.bases.items():
        r=cell_rect(*pos,g.grid).inflate(-ps(8),-ps(8))
        c=BASE_NEUTRAL if b.owner is None else PLAYER_COLORS[b.owner]
        pygame.draw.rect(screen,c,r,ps(3))
        if not g.privacy and (b.owner==g.current or g.reveal_debug):
            draw_text(f"B{b.defense()}",(r.x+ps(4),r.y+ps(4)),font_small,c)
        if g.selected is b:
            pygame.draw.rect(screen,SELECT,cell_rect(b.x,b.y,g.grid).inflate(-3,-3),2)

    if not g.privacy:
        for t in g.tokens:
            cx,cy=cell_center(t.x,t.y,g.grid)
            own=t.owner==g.current or g.reveal_debug
            c=PLAYER_COLORS[t.owner]

            if own:
                if t.vehicle:
                    pygame.draw.rect(screen,c,pygame.Rect(cx-ps(12),cy-ps(12),ps(24),ps(24)),ps(3))
                    if t.people:
                        draw_text(str(t.strength()),(cx-5,cy-8),font_small if PS<1.2 else font,c)
                elif t.has_leader() and len(t.people)==1:
                    pygame.draw.polygon(screen,c,[(cx,cy-ps(14)),(cx-ps(13),cy+ps(11)),(cx+ps(13),cy+ps(11))],ps(3))
                else:
                    pygame.draw.circle(screen,c,(cx,cy),ps(13),ps(3))
                    draw_text(str(t.strength()),(cx-5,cy-8),font_small if PS<1.2 else font,c)
            else:
                # Enemy identity stays visible, composition does not.
                pygame.draw.circle(screen,c,(cx,cy),ps(11),ps(3))

            if g.selected is t:
                pygame.draw.rect(screen,SELECT,cell_rect(t.x,t.y,g.grid).inflate(-3,-3),2)

    # Reachability hints are deliberately drawn LAST over board graphics,
    # so harvest emblems / bases / pieces never hide them.
    if not g.privacy and isinstance(g.selected,Token) and g.selected.owner==g.current:
        c=PLAYER_COLORS[g.current]

        for rx,ry in g.reachable_empty_tiles(g.selected):
            cx,cy=cell_center(rx,ry,g.grid)
            # dark halo + player-color core keeps the marker readable over icons
            pygame.draw.circle(screen,BG,(cx,cy),ps(6))
            pygame.draw.circle(screen,c,(cx,cy),ps(4))

        friendly_targets,hostile_targets=g.reachable_interaction_targets(g.selected)

        for rx,ry in friendly_targets:
            cx,cy=cell_center(rx,ry,g.grid)
            pygame.draw.circle(screen,BG,(cx,cy),ps(7))
            pygame.draw.circle(screen,c,(cx,cy),ps(5))

        for rx,ry in hostile_targets:
            cx,cy=cell_center(rx,ry,g.grid)
            pts=[(cx,cy-ps(8)),(cx+ps(8),cy),(cx,cy+ps(8)),(cx-ps(8),cy)]
            pygame.draw.polygon(screen,BG,pts,ps(4))
            pts=[(cx,cy-ps(7)),(cx+ps(7),cy),(cx,cy+ps(7)),(cx-ps(7),cy)]
            pygame.draw.polygon(screen,c,pts,ps(2))

    # ---------- header row: title, player, turn ----------
    tx,ty,tsize=L["title"]
    if tsize=="big":
        draw_text(f"GDG MINI — v{VERSION}",(tx,ty),font_big,TEXT)
    else:
        draw_text(f"GDG MINI v{VERSION}",(tx,ty),font_small,MUTED)
    draw_text(f"Player {g.current+1}",L["player"],font,PLAYER_COLORS[g.current])
    turn_surface=font.render(f"Turn {g.turn}",True,TEXT)
    screen.blit(turn_surface,(L["turn_right"][0]-turn_surface.get_width(),L["turn_right"][1]))

    # ---------- status ----------
    sx=L["status_x"]
    draw_text("MOVE LEFT",(sx,L["y_move_label"]),font_small,MUTED)
    draw_text(str(g.move_left),(sx,L["y_move_num"]),font_move,TEXT)

    draw_text(f"Visible units: {g.visible_units(g.current)}/{g.unit_cap}",(sx,L["y_visible"]))
    draw_text("Harvest:",(sx,L["y_harvest"]))
    for i,h in enumerate(g.harvest_tiles):
        kind=HARVEST_ORDER[i]
        collected=g.harvest_collected_this_cycle(g.current,h)
        active=g.harvest_active[g.current][h]
        pending=g.harvest_pending[g.current][h]
        icon_color=HARVEST_ON if collected else (MUTED if active else HARVEST_OFF)
        draw_harvest_glyph(kind,(sx+L["harvest_dx"]+i*L["harvest_step"],L["y_harvest"]+11),icon_color,size=18,width=0 if collected or active else 1)
        if pending:
            pygame.draw.circle(screen,HARVEST_OFF,(sx+L["harvest_dx"]+i*L["harvest_step"],L["y_harvest"]+11),13,1)
    draw_text(f"Bases: {len(g.controlled_bases(g.current))}",(sx,L["y_bases"]))
    if L["y_config"] is not None:
        draw_text(f"{g.grid}x{g.grid} | base {g.base_move} | cap {g.unit_cap}",(sx,L["y_config"]),font_small,MUTED)
    for ly,text in L["legend"]:
        draw_text(text,(sx,ly),font_small,MUTED)

    # Visual reserve
    draw_text("RESERVE:",(sx,L["y_reserve_label"]),font_small,MUTED)
    rx=sx; ry=L["y_reserve_icons"]
    reserve_icons=[]
    for _ in range(g.reserve[g.current]):
        reserve_icons.append("pawn")
    for _ in range(g.reserve_vehicles[g.current]):
        reserve_icons.append("vehicle")
    for i,kind in enumerate(reserve_icons[:12]):
        cx=rx+(i%6)*34+13
        cy=ry+(i//6)*34+13
        c=PLAYER_COLORS[g.current]
        if kind=="pawn":
            pygame.draw.circle(screen,c,(cx,cy),9,2)
        else:
            pygame.draw.rect(screen,c,pygame.Rect(cx-9,cy-9,18,18),2)
    if len(reserve_icons)>12:
        draw_text(f"+{len(reserve_icons)-12}",(rx+210,ry+36),font_small,MUTED)

    # ---------- message + container panel ----------
    mx,my=L["msg"]; lh=L["msg_line_h"]
    draw_text("Message:",(mx,my),font_small,MUTED)
    y=my
    message_lines=wrap_text(g.message)
    for line in message_lines[:4]:
        y+=lh
        draw_text(line,(mx,y),font_small)
    if len(message_lines)>4:
        y+=lh
        draw_text("...",(mx,y),font_small,MUTED)

    slot_rects=draw_container_panel(g,*L["container"])

    buttons={}
    popup_buttons={}
    over=g.winner is not None or g.draw

    # End turn button.
    end_r=L["end"]
    end_enabled=g.end_turn_allowed()
    pygame.draw.rect(screen,(55,58,62) if end_enabled else (38,39,41),end_r)
    pygame.draw.rect(screen,TEXT if end_enabled else MUTED,end_r,1)
    draw_center(L["end_label"],end_r.center,font if LAYOUT_MODE!="pc" else font_small,TEXT if end_enabled else MUTED)
    buttons["end"]=end_r

    # Restart: goes back to the setup screen; needs a second tap mid-game.
    rs_r=L["restart"]
    armed=(not over) and pygame.time.get_ticks()<UI["restart_until"]
    pygame.draw.rect(screen,(92,52,52) if armed else (47,50,54),rs_r)
    pygame.draw.rect(screen,TEXT if armed else MUTED,rs_r,1)
    draw_center("TAP AGAIN" if armed else "RESTART",rs_r.center,font_small,TEXT if armed else MUTED)
    buttons["restart"]=rs_r

    # Reinforcement choice becomes a modal over the board.
    show_reinforcement_popup = (
        g.reinforcement_credits[g.current] > 0
        and bool(g.controlled_bases(g.current))
        and not g.privacy
        and g.winner is None
        and not g.draw
    )

    if show_reinforcement_popup:
        board_left,board_top=board_offset(g.grid)
        board_w=g.grid*CELL
        board_h=g.grid*CELL

        overlay=pygame.Surface((board_w,board_h),pygame.SRCALPHA)
        overlay.fill((0,0,0,150))
        screen.blit(overlay,(board_left,board_top))

        pop_w=390
        pop_h=190
        pop_x=board_left+(board_w-pop_w)//2
        pop_y=board_top+(board_h-pop_h)//2
        pop=pygame.Rect(pop_x,pop_y,pop_w,pop_h)

        pygame.draw.rect(screen,(38,40,43),pop)
        pygame.draw.rect(screen,TEXT,pop,2)

        draw_center("REINFORCEMENT",(pop.centerx,pop.y+38),font_big,TEXT)
        draw_center("Choose your harvest reward",(pop.centerx,pop.y+76),font_small,MUTED)

        pawn_r=pygame.Rect(pop.x+24,pop.y+108,164,60)
        veh_r=pygame.Rect(pop.x+202,pop.y+108,164,60)

        for r in (pawn_r,veh_r):
            pygame.draw.rect(screen,(55,58,62),r)
            pygame.draw.rect(screen,TEXT,r,1)

        draw_center("+2 PAWNS",pawn_r.center,font_small,TEXT)
        draw_center("+1 VEHICLE",veh_r.center,font_small,TEXT)

        popup_buttons["pawns"]=pawn_r
        popup_buttons["vehicle"]=veh_r

    if g.privacy:
        shade=pygame.Surface((MARGIN*2+BOARD_W,HEIGHT),pygame.SRCALPHA)
        shade.fill((10,10,10,235)); screen.blit(shade,(0,0))
        cx=(MARGIN*2+BOARD_W)//2
        draw_center(f"PLAYER {g.current+1}",(cx,HEIGHT//2-50),font_big,PLAYER_COLORS[g.current])
        draw_center("Pass the device, then tap to begin.",(cx,HEIGHT//2),font,TEXT)
        draw_center("Enemy ownership color remains visible.",(cx,HEIGHT//2+34),font_small,MUTED)

    if g.draw:
        draw_text("DRAW",L["result"],font_big,TEXT)
    elif g.winner is not None:
        draw_text(f"PLAYER {g.winner+1} WINS",L["result"],font_big,PLAYER_COLORS[g.winner])

    return buttons,slot_rects,popup_buttons

def draw_center(s,center,f=None,color=TEXT):
    surf=(f or font).render(str(s),True,color)
    screen.blit(surf,surf.get_rect(center=center))

def board_pos_from_mouse(pos,grid):
    mx,my=pos
    ox,oy=board_offset(grid)
    if mx<ox or my<oy: return None
    x=(mx-ox)//CELL; y=(my-oy)//CELL
    if 0<=x<grid and 0<=y<grid:
        return int(x),int(y)
    return None

# ---------- input helpers ----------
def select_friendly_at(g,bp):
    """Right-click on desktop / double-tap on phone: switch selection to the
    friendly token or base on that tile, without performing any action."""
    x,y=bp
    tok=g.token_at(x,y)
    base=g.bases.get((x,y))
    if tok and tok.owner==g.current:
        g.selected=tok
        g.selected_person_idx=None
        g.message="Selected vehicle." if tok.vehicle else f"Selected strength {tok.strength()}."
    elif base and base.owner==g.current:
        g.selected=base
        g.selected_person_idx=None
        g.message=f"Selected base: {len(base.people)} occupant(s)."

def tap_is_ambiguous(g,bp):
    """A single tap on a friendly tile while something else is selected would
    merge / board / transfer. Because a double-tap means 'just select it', that
    one case waits a moment to see whether a second tap follows."""
    sel=g.selected
    if sel is None: return False
    tok=g.token_at(*bp); base=g.bases.get(bp)
    friendly_tok = tok is not None and tok.owner==g.current and tok is not sel
    friendly_base = base is not None and base.owner==g.current and base is not sel
    if not (friendly_tok or friendly_base): return False
    if isinstance(sel,Base) and g.selected_person_idx is None: return False
    return True

def handle_left_click(g,pos,buttons,slot_rects,popup_buttons):
    """Everything a normal left click / single tap does (privacy screen,
    reinforcement popup and restart button are handled by the caller)."""
    if buttons.get("end") and buttons["end"].collidepoint(pos):
        g.next_turn(); return

    # Container slot selection.
    if g.container_people(g.selected) is not None:
        for i,r in enumerate(slot_rects):
            if r.collidepoint(pos):
                people=g.container_people(g.selected)
                if i<len(people):
                    g.selected_person_idx=i
                    g.message="Selected "+("leader." if people[i].leader else "pawn.")
                else:
                    g.selected_person_idx=None
                return

    bp=board_pos_from_mouse(pos,g.grid)
    if bp is None or g.winner is not None or g.draw: return
    x,y=bp
    clicked_token=g.token_at(x,y)
    clicked_base=g.bases.get((x,y))

    # If a person inside a selected container is selected, board click deploys them.
    if g.selected_person_idx is not None and g.container_people(g.selected) is not None:
        g.deploy_selected_person(g.selected,g.selected_person_idx,x,y)
        return

    if g.selected is None:
        if clicked_token and clicked_token.owner==g.current:
            g.selected=clicked_token; g.selected_person_idx=None
            g.message="Selected vehicle." if clicked_token.vehicle else f"Selected strength {clicked_token.strength()}."
        elif clicked_base and clicked_base.owner==g.current:
            g.selected=clicked_base; g.selected_person_idx=None
            g.message=f"Selected base: {len(clicked_base.people)} occupant(s)."
        else:
            g.message="Select one of your tokens or bases."
        return

    if isinstance(g.selected,Base):
        # Clicking selected base again clears; own token/base switches selection.
        if clicked_base is g.selected:
            g.selected=None; g.selected_person_idx=None
        elif clicked_token and clicked_token.owner==g.current:
            g.selected=clicked_token; g.selected_person_idx=None
        elif clicked_base and clicked_base.owner==g.current:
            g.selected=clicked_base; g.selected_person_idx=None
        else:
            g.message="Choose an occupant slot first."
        return

    if isinstance(g.selected,Token):
        if clicked_token is g.selected:
            g.selected=None; g.selected_person_idx=None
        elif (
            clicked_base is not None
            and clicked_base.owner==g.current
            and (g.selected.vehicle or (g.selected.has_leader() and g.selected.regular_count()==0))
        ):
            # Convenience: vehicle/leader cannot enter a base, so clicking
            # a friendly base switches selection instead of producing an error.
            g.selected=clicked_base
            g.selected_person_idx=None
            g.message=f"Selected base: {len(clicked_base.people)} occupant(s)."
        else:
            g.try_move_or_interact(g.selected,x,y)

# ---------- setup screen ----------
async def choose_settings():
    settings={
        "players":2,
        "grid":13,
        "base_move":4,
        "unit_cap":6,
        "starting_pawns":3,
        "starting_vehicle":True,
        "draw_winner":"defender",
    }

    def clamp(v,lo,hi): return max(lo,min(hi,v))

    frame=0
    while True:
        # Browser: follow the screen shape (rotate the iPad -> layout follows)
        # until the player picks a view by hand.
        if sys.platform=="emscripten" and not UI["picked"] and frame%30==0:
            want=auto_layout()
            if want!=LAYOUT_MODE: set_layout(want)
        frame+=1
        S=L["setup"]     # re-read every frame: the layout can change from this screen
        screen.fill(BG)
        draw_text("GDG MINI — PLAYTEST SETUP",S["title"],font_big)
        draw_text("Everything here is deliberately tweakable.",S["sub"],font_small,MUTED)

        # Layout switch (top right): phone / PC look.
        tw=96; th=36
        layout_rects={
            "phone":pygame.Rect(WIDTH-MARGIN-3*tw-12,MARGIN,tw,th),
            "tablet":pygame.Rect(WIDTH-MARGIN-2*tw-6,MARGIN,tw,th),
            "pc":pygame.Rect(WIDTH-MARGIN-tw,MARGIN,tw,th),
        }
        draw_text("VIEW",(layout_rects["phone"].x-62,MARGIN+9),font_small,MUTED)
        for name,r in layout_rects.items():
            sel=(LAYOUT_MODE==name)
            pygame.draw.rect(screen,(74,78,83) if sel else (47,50,54),r)
            pygame.draw.rect(screen,TEXT if sel else MUTED,r,2 if sel else 1)
            draw_center(name.upper(),r.center,font_small,TEXT if sel else MUTED)

        # Fullscreen (browser only): hides the address bar on Android.
        fs_rect=None
        if sys.platform=="emscripten":
            fs_rect=pygame.Rect(WIDTH-MARGIN-3*tw-12,MARGIN+th+6,3*tw+12,th)
            pygame.draw.rect(screen,(47,50,54),fs_rect)
            pygame.draw.rect(screen,MUTED,fs_rect,1)
            draw_center("FULLSCREEN",fs_rect.center,font_small,TEXT)

        controls={}
        x0=S["x0"]; y0=S["y0"]; row=S["row"]; bh=S["bh"]
        cx0=S["cx0"]

        def choice_row(key,label,options,display=None):
            nonlocal y0
            draw_text(label,(x0,y0+(bh-font.get_height())//2),font)
            bx=cx0
            controls[key]=[]
            for value in options:
                text = display(value) if display else str(value)
                w=max(S["wmin"],S["wpad"]+len(text)*S["wchar"])
                r=pygame.Rect(bx,y0,w,bh)
                selected=settings[key]==value
                pygame.draw.rect(screen,(74,78,83) if selected else (47,50,54),r)
                pygame.draw.rect(screen,TEXT if selected else MUTED,r,2 if selected else 1)
                draw_center(text,r.center,font_small,TEXT if selected else MUTED)
                controls[key].append((value,r))
                bx+=w+10
            y0+=row

        choice_row("players","PLAYERS",[2,3,4],lambda v:f"{v}P")
        choice_row("grid","BOARD",[13,11,9,7],lambda v:f"{v} x {v}")
        choice_row("draw_winner","DRAW ADVANTAGE",["defender","attacker"],lambda v:v.upper())
        choice_row("starting_vehicle","START VEHICLE",[True,False],lambda v:"YES" if v else "NO")

        # Stepper rows
        steppers={}
        sxs,mw,vw,gap=S["step"]
        for key,label,lo,hi in [
            ("base_move","DEFAULT MOVE",1,10),
            ("unit_cap","MAX VISIBLE UNITS",2,12),
            ("starting_pawns","STARTING PAWNS",0,4),
        ]:
            draw_text(label,(x0,y0+(bh-font.get_height())//2),font)
            minus=pygame.Rect(sxs,y0,mw,bh)
            valr=pygame.Rect(sxs+mw+gap,y0,vw,bh)
            plus=pygame.Rect(sxs+mw+gap+vw+gap,y0,mw,bh)
            for r in (minus,plus,valr):
                pygame.draw.rect(screen,(47,50,54),r)
                pygame.draw.rect(screen,MUTED,r,1)
            draw_center("-",minus.center,font_big,TEXT)
            draw_center("+",plus.center,font_big,TEXT)
            draw_center(str(settings[key]),valr.center,font,TEXT)
            steppers[key]=(minus,plus,lo,hi)
            y0+=row

        # Helpful derived summary
        summary_y=y0+S["summary"]
        draw_text("STARTING STATE",(x0,summary_y),font_small,MUTED)
        visible_start=1+(1 if settings["starting_vehicle"] else 0)  # leader + possible vehicle
        draw_text(
            f"{settings['starting_pawns']} pawn(s) hidden in base | "
            f"{visible_start} visible unit(s) | opening pool {settings['base_move']+visible_start}",
            (x0,summary_y+24),font_small,TEXT
        )

        start=S["start"]
        pygame.draw.rect(screen,(65,70,75),start)
        pygame.draw.rect(screen,TEXT,start,2)
        draw_center("START TEST GAME",start.center,font,TEXT)

        pygame.display.flip()

        for e in pygame.event.get():
            if e.type==pygame.QUIT:
                pygame.quit(); sys.exit()
            if e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                if fs_rect is not None and fs_rect.collidepoint(e.pos):
                    toggle_fullscreen()
                    continue
                switched=False
                for name,r in layout_rects.items():
                    if r.collidepoint(e.pos):
                        UI["picked"]=True
                        if name!=LAYOUT_MODE:
                            set_layout(name)
                            switched=True
                        break
                if switched:
                    break          # geometry changed: redraw before reading more clicks

                for key,items in controls.items():
                    for value,r in items:
                        if r.collidepoint(e.pos):
                            settings[key]=value
                            if key=="grid":
                                defaults={13:4,11:3,9:2,7:1}
                                settings["base_move"]=defaults[value]
                            break

                for key,(minus,plus,lo,hi) in steppers.items():
                    if minus.collidepoint(e.pos):
                        settings[key]=clamp(settings[key]-1,lo,hi)
                    elif plus.collidepoint(e.pos):
                        settings[key]=clamp(settings[key]+1,lo,hi)

                if start.collidepoint(e.pos):
                    return settings

        clock.tick(FPS)
        await asyncio.sleep(0)   # lets the browser breathe (required for the web build)

# ---------- one match ----------
async def play(g):
    """Runs one match. Returns when the player restarts (back to the setup screen)."""
    pending=None     # (pos, tile, time): single tap on a friendly tile, waiting to see if a 2nd tap follows
    last_tap=None    # (tile, time): last board tap, used to spot double-taps
    UI["restart_until"]=0

    while True:
        buttons,slot_rects,popup_buttons=draw_game(g)
        pygame.display.flip()
        now=pygame.time.get_ticks()

        # A pending tap that never got a second tap becomes a normal click.
        if pending and now-pending[2]>DOUBLE_TAP_MS:
            handle_left_click(g,pending[0],buttons,slot_rects,popup_buttons)
            pending=None

        for e in pygame.event.get():
            if e.type==pygame.QUIT:
                pygame.quit(); sys.exit()

            if e.type==pygame.KEYDOWN:
                if e.key==pygame.K_F2:
                    g.reveal_debug=not g.reveal_debug
                elif e.key==pygame.K_RETURN and not g.privacy and not popup_buttons:
                    g.next_turn()
                elif isinstance(g.selected,Token) and not g.privacy and not popup_buttons and g.selected_person_idx is None:
                    dx=dy=0
                    if e.key==pygame.K_LEFT: dx=-1
                    elif e.key==pygame.K_RIGHT: dx=1
                    elif e.key==pygame.K_UP: dy=-1
                    elif e.key==pygame.K_DOWN: dy=1
                    if dx or dy:
                        nx,ny=g.selected.x+dx,g.selected.y+dy
                        if 0<=nx<g.grid and 0<=ny<g.grid:
                            g.try_move_or_interact(g.selected,nx,ny)

            # Desktop right-click (kept): select a friendly token/base.
            if e.type==pygame.MOUSEBUTTONDOWN and e.button==3:
                if g.privacy or popup_buttons:
                    continue
                bp=board_pos_from_mouse(e.pos,g.grid)
                if bp is not None:
                    select_friendly_at(g,bp)
                continue

            if e.type==pygame.MOUSEBUTTONDOWN and e.button==1:
                now=pygame.time.get_ticks()
                over=g.winner is not None or g.draw

                # Restart button: back to the setup screen. Mid-game it needs a second tap.
                if buttons["restart"].collidepoint(e.pos):
                    if over or now<UI["restart_until"]:
                        UI["restart_until"]=0
                        return
                    UI["restart_until"]=now+2500
                    continue

                if g.privacy:
                    g.privacy=False
                    pending=None; last_tap=None
                    continue

                # Modal reinforcement choice blocks board interaction.
                if popup_buttons:
                    if popup_buttons.get("pawns") and popup_buttons["pawns"].collidepoint(e.pos):
                        g.spawn_reinforcement("pawns")
                    elif popup_buttons.get("vehicle") and popup_buttons["vehicle"].collidepoint(e.pos):
                        g.spawn_reinforcement("vehicle")
                    continue

                bp=board_pos_from_mouse(e.pos,g.grid)

                # A waiting tap that this tap does not complete into a double-tap acts now.
                if pending and not (bp is not None and pending[1]==bp and now-pending[2]<=DOUBLE_TAP_MS):
                    handle_left_click(g,pending[0],buttons,slot_rects,popup_buttons)
                    pending=None

                if bp is not None and not over:
                    if pending:
                        # Second tap on the same tile: double-tap = select, no action.
                        pending=None; last_tap=None
                        select_friendly_at(g,bp)
                        continue
                    if last_tap and last_tap[0]==bp and now-last_tap[1]<=DOUBLE_TAP_MS:
                        last_tap=None
                        select_friendly_at(g,bp)
                        continue
                    last_tap=(bp,now)
                    if tap_is_ambiguous(g,bp):
                        pending=(e.pos,bp,now)
                        continue

                handle_left_click(g,e.pos,buttons,slot_rects,popup_buttons)

        clock.tick(FPS)
        await asyncio.sleep(0)   # lets the browser breathe (required for the web build)

async def main():
    while True:
        settings=await choose_settings()
        g=Game(**settings)
        await play(g)

# Keep this at the very end of the file (the web build needs it exactly here).
if __name__=="__main__" or sys.platform=="emscripten":
    asyncio.run(main())
