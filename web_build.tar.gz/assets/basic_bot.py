"""GDG Mini BasicBot V3.4 — Belief + personality + post-capture safety.

This bot is intentionally INFORMATION-HONEST.

It never reads an enemy token's hidden vehicle flag, occupants, strength,
leader status, or Saboteur status when making strategic decisions.

Instead it:
- keeps a public material ledger for every opponent,
- subtracts only casualties it was entitled to learn,
- consumes a canonical SAFE-VIEW: outside positions + base owners only,
- enumerates legal hidden compositions for every visible enemy circle,
- produces marginal probabilities (leader / Saboteur / vehicle / ATK),
- uses those probabilities for risk-aware combat choices,
- writes detailed reasoning to g.ai_log for post-match study.

Non-participant combats provide only participants, location, and winner.
"""

import random
from collections import defaultdict

BOT_VERSION="V1.10-DIFFICULTY-PERCEPTION"

FACTION_NAMES=["FBI","RUSSIAN MAFIA","ITALIAN MAFIA","CIA"]

# Same rational core for every faction. These are intentionally MICRO biases,
# mostly +/- 10–20%, so personality changes preference rather than competence.
FACTION_PERSONALITIES={
    # NW / blue — cautious territorial controller.
    0:{
        "name":"FBI",
        "risk_tolerance":0.86,
        "leader_safety":1.18,
        "leader_kill_reward":0.92,
        "base_control":1.18,
        "harvest":0.94,
        "harvest_block":1.00,
        "center":0.96,
        "concentration":0.96,
        "field_presence":0.92,
    },

    # NE / amber — likes concentrated force, but Saboteur safety remains sacred.
    1:{
        "name":"RUSSIAN MAFIA",
        "risk_tolerance":0.98,
        "leader_safety":1.04,
        "leader_kill_reward":1.04,
        "base_control":0.98,
        "harvest":0.94,
        "harvest_block":0.98,
        "center":1.00,
        "concentration":1.18,
        "field_presence":0.94,
    },

    # SE / magenta — opportunistic, harder to read, more willing to empty bases
    # when that creates useful independent threats or an immediate attack.
    2:{
        "name":"ITALIAN MAFIA",
        "risk_tolerance":1.16,
        "leader_safety":0.92,
        "leader_kill_reward":1.18,
        "base_control":0.92,
        "harvest":0.98,
        "harvest_block":0.98,
        "center":1.00,
        "concentration":0.98,
        "field_presence":1.18,
    },

    # SW / green — objective/denial specialist.
    3:{
        "name":"CIA",
        "risk_tolerance":0.96,
        "leader_safety":1.02,
        "leader_kill_reward":1.00,
        "base_control":1.00,
        "harvest":1.20,
        "harvest_block":1.18,
        "center":1.16,
        "concentration":1.00,
        "field_presence":1.00,
    },
}

def faction_name(p):
    return "NEUTRAL" if p is None else FACTION_NAMES[p]


class BasicBot:
    def __init__(self, player=1, seed=None, faction_id=None, difficulty="normal"):
        self.player=player
        self.faction_id=player if faction_id is None else int(faction_id)
        raw_difficulty=str(difficulty).lower()
        self.difficulty="medium" if raw_difficulty in ("normal","medium") else raw_difficulty
        if self.difficulty not in ("easy","medium","hard"):
            self.difficulty="medium"
        self.rng=random.Random(seed)
        self.personality=dict(FACTION_PERSONALITIES.get(
            self.faction_id,FACTION_PERSONALITIES[0]
        ))
        self.last_reason=""
        self.end_after_combat=False

        self._initialized=False
        self._log_index=0  # legacy; omniscient engine log is never consumed
        self._safe_snapshot_index=0
        self._safe_fight_index=0
        self._material={}
        self._known_losses={}
        self._stationary={}
        self._previous_positions={}
        self._evidence=defaultdict(dict)
        self._base_evidence=defaultdict(dict)
        self._belief_cache_key=None
        self._belief_cache={}
        self._candidate_meta={}
        self._last_candidate_log=[]

        # Safe snapshot-to-snapshot reconstruction. Opponent actions are never
        # observed; only before/after geometry may support hypotheses.
        self._hidden_prep_suspicion=defaultdict(float)
        self._public_intel_history=defaultdict(list)
        # Hard constraints derived only from SAFE-VIEW snapshot transitions.
        # Maps (owner, current_pos) -> composition restrictions.
        self._transition_constraints={}

        # Own leader memory is private information and therefore fair.
        self._last_memory_turn=None
        self._leader_last_pos=None
        self._leader_stationary_turns=0
        self._leader_exposed_turns=0

    @staticmethod
    def _manhattan(a,b):
        return abs(a[0]-b[0])+abs(a[1]-b[1])

    def _pw(self,key):
        """Faction personality weight, defaulting to neutral 1.0."""
        return float(self.personality.get(key,1.0))

    def _difficulty_rank(self):
        return {"easy":0,"medium":1,"hard":2}.get(self.difficulty,1)

    def _difficulty_at_least(self, level):
        return self._difficulty_rank() >= {"easy":0,"medium":1,"hard":2}[level]

    # ================================================================
    # PUBLIC INFORMATION LEDGER
    # ================================================================

    def _ensure_initialized(self,g):
        if self._initialized:
            return
        self._initialized=True
        for p in range(g.players):
            self._material[p]={
                "pawns":int(g.starting_pawns),
                "leader":1,
                "saboteur":1,
                "vehicles":1 if g.starting_vehicle else 0,
            }
            self._known_losses[p]={
                "pawns":0,"leader":0,"saboteur":0,"vehicles":0
            }
            self._previous_positions[p]=set()

        # Opening identities are NOT attached to current coordinates here.
        # Opponent turns are unseen: even an identical before/after geometry can
        # hide loading, unloading, replacement, or swaps. Hard must reconstruct
        # possibilities from safe snapshots rather than track anonymous circles.

    def _observe_public_board(self,g):
        """Only owner+coordinates are read for enemies."""
        for p in range(g.players):
            if p==self.player:
                continue
            view=g.observer_view(self.player)["current"]
            current={tuple(pos) for pos in view["outside"].get(p,[])}
            old=self._previous_positions.get(p,set())
            new_age={}
            for pos in current:
                key=(p,pos)
                age=self._stationary.get(key,0)+1 if pos in old else 0
                new_age[key]=age
            # Drop stale position evidence. Identity is NOT magically tracked
            # through unseen movement.
            for key in [k for k in self._stationary if k[0]==p]:
                self._stationary.pop(key,None)
            self._stationary.update(new_age)
            self._previous_positions[p]=current

            # Evidence attached to a square only survives while that opponent
            # still visibly occupies the square.
            for key in list(self._evidence):
                op,pos=key
                if op==p and pos not in current:
                    del self._evidence[key]

    @staticmethod
    def _loss_key(kind):
        return {
            "pawn":"pawns","leader":"leader",
            "saboteur":"saboteur","vehicle":"vehicles"
        }.get(kind)

    def _apply_known_losses(self,owner,kinds):
        if owner is None or owner==self.player:
            return
        for kind in kinds:
            key=self._loss_key(kind)
            if key:
                self._known_losses[owner][key]+=1

    def _opening_transition_constraint(self,g,actor,prior,snap,budget):
        """Exact first-turn hidden-action search from SAFE-VIEW only.

        The opening is small enough to enumerate at one-MOV granularity.  This
        intentionally does NOT track an observed token: it starts from the
        public standard setup, explores legal hidden sequences up to the MOV
        budget, then keeps only states whose public outside-circle geometry is
        exactly the observed after-snapshot.  A 0/100 result therefore comes
        from surviving legal histories, not from a shortest-path shortcut.
        """
        # Opening is the actor's FIRST completed hidden turn, not global_turn==1.
        # Global turn numbering is round-based: player 0's first turn ends while
        # global_turn is still 0, so the old test silently skipped exactly the
        # human opening we most needed to reconstruct.  The SAFE-VIEW history is
        # the authority here: before the first completed transition for this
        # actor, there is no prior public-intel entry for them.
        if self._public_intel_history.get(actor):
            return
        sp={tuple(x) for x in prior.get("outside",{}).get(actor,[])}
        ep={tuple(x) for x in snap.get("outside",{}).get(actor,[])}
        if len(sp)!=2 or len(ep)!=1 or not getattr(g,"starting_vehicle",False):
            return

        m=g.grid-1
        corners=[(0,0),(m,0),(m,m),(0,m)]
        vehicle_spots=[(0,1),(m,1),(m,m-1),(0,m-1)]
        leader_spots=[(1,1),(m-1,1),(m-1,m-1),(1,m-1)]
        seats=[0,2] if g.players==2 else list(range(g.players))
        seat=seats[actor]
        base=corners[seat]; v0=vehicle_spots[seat]; l0=leader_spots[seat]
        if v0 not in sp or l0 not in sp:
            return

        # State = (vehicle_pos, occupants, leader_pos_or_None,
        #          pawn0_pos/base/None, pawn1..., pawn2...).  None for a person
        # means that person is inside the vehicle.  Saboteur is irrelevant to
        # vehicle ATK and cannot board; any history deploying it cannot match a
        # one-circle after-snapshot, so it need not be expanded here.
        start=(v0, tuple(), l0, "B", "B", "B")

        def neighbours(pos):
            x,y=pos
            for dx,dy in ((1,0),(-1,0),(0,1),(0,-1)):
                q=(x+dx,y+dy)
                if 0<=q[0]<g.grid and 0<=q[1]<g.grid:
                    yield q

        def exposed_positions(st):
            vp,occ,lp,*pps=st
            out=[vp]
            if lp is not None: out.append(lp)
            out.extend(q for q in pps if q != "B" and q is not None)
            return out

        def canon(vp,occ,lp,pps):
            return (vp,tuple(sorted(occ)),lp,*pps)

        def successors(st):
            vp,occ,lp,*pps=st
            occupied=set(exposed_positions(st))
            out=[]

            # Exposed leader: one step, or board by stepping onto vehicle.
            if lp is not None:
                for q in neighbours(lp):
                    if q==vp and len(occ)<4:
                        out.append(canon(vp,occ+("L",),None,pps))
                    elif q not in occupied and q not in g.bases:
                        out.append(canon(vp,occ,q,pps))

            # Regular pawns may leave the home base one tile at a time, move
            # while exposed, or board by stepping onto the vehicle.
            for i,pp in enumerate(pps):
                if pp is None: continue
                origin=base if pp=="B" else pp
                for q in neighbours(origin):
                    if q==vp and len(occ)<4:
                        n=list(pps); n[i]=None
                        out.append(canon(vp,occ+(f"P{i}",),lp,n))
                    elif q not in occupied and q not in g.bases:
                        n=list(pps); n[i]=q
                        out.append(canon(vp,occ,lp,n))

            # An occupied vehicle may move one tile.  If it lands on an
            # exposed leader/pawn, that person is picked up in the same MOV,
            # exactly like GameState.merge_tokens(vehicle, person, cost=1).
            if occ:
                for q in neighbours(vp):
                    if q in g.bases: continue
                    nocc=occ; nlp=lp; npps=list(pps)
                    if lp==q and len(nocc)<4:
                        nocc=nocc+("L",); nlp=None
                    else:
                        hit=None
                        for i,pp in enumerate(npps):
                            if pp==q: hit=i; break
                        if hit is not None and len(nocc)<4:
                            nocc=nocc+(f"P{hit}",); npps[hit]=None
                        elif q in occupied:
                            continue
                    out.append(canon(q,nocc,nlp,npps))
            return out

        frontier={start}
        all_states={start}
        for _ in range(int(budget)):
            nxt=set()
            for st in frontier:
                nxt.update(successors(st))
            frontier=nxt-all_states
            all_states.update(nxt)
            if not frontier: break

        def public_geom(st):
            return set(exposed_positions(st))
        survivors=[st for st in all_states if public_geom(st)==ep]
        if not survivors:
            # Never manufacture certainty if our legal search failed to explain
            # a real screenshot.  Leave the normal probabilistic engine alone.
            return

        end=next(iter(ep))
        compositions=set()
        for st in survivors:
            vp,occ,lp,*pps=st
            if vp!=end: continue
            has_leader="L" in occ
            pawn_count=sum(1 for x in occ if x.startswith("P"))
            compositions.add((has_leader,pawn_count))
        if not compositions:
            return

        require_leader=all(x[0] for x in compositions)
        require_vehicle=True  # the sole circle is the surviving starting vehicle
        pawn_counts=sorted({x[1] for x in compositions if (not require_leader or x[0])})
        self._transition_constraints[(actor,end)]={
            "opening":True,
            "opening_origin":True,
            "rational_pawn_loading_prior":4.0,
            "require_leader":bool(require_leader),
            "require_vehicle":bool(require_vehicle),
            "min_pawns":min(pawn_counts) if pawn_counts else 0,
            "max_pawns":max(pawn_counts) if pawn_counts else 0,
            "legal_pawn_counts":pawn_counts,
            "budget":int(budget),
            "surviving_hidden_states":len(survivors),
            "method":"exhaustive one-MOV SAFE-VIEW opening search",
            "start":[list(x) for x in sorted(sp)],
            "end":list(end),
        }

    def _home_base_for_player(self,g,p):
        """Return p's original corner base from public seating rules."""
        m=g.grid-1
        corners=[(0,0),(m,0),(m,m),(0,m)]
        seats=[0,2] if g.players==2 else list(range(g.players))
        return corners[seats[p]]

    def _transition_lower_bound(self,g,actor,sp,ep,special_start,special_end):
        """Optimistic MOV lower bound for a hidden snapshot transition.

        This is deliberately MORE permissive than the real rules.  The known
        special circle is forced to finish at ``special_end``. Every other end
        circle may be supplied independently by ANY previous circle or directly
        from the home base. We even allow one previous circle to be the source
        of several end circles, which models hidden unloading/splitting at an
        unrealistically cheap price.

        Therefore the result can only be used for proof by impossibility: if
        even this optimistic world needs more MOV than the public budget, that
        mapping cannot have happened in the real game. It must never be used as
        a probability weight.
        """
        cost=self._manhattan(special_start,special_end)
        base=self._home_base_for_player(g,actor)
        sources=list(sp)
        for q in ep:
            if q==special_end:
                continue
            best=self._manhattan(base,q)
            for src in sources:
                best=min(best,self._manhattan(src,q))
            cost+=best
        return int(cost)

    def _propagate_transition_constraints(self,g,actor,prior,snap,budget):
        """Carry proven composition constraints through an unseen turn safely.

        Anonymous circles are NEVER tracked by coordinate.  For every previous
        constrained circle we ask which current circles it could possibly have
        become within the public MOV budget.  A constraint is inherited only
        when exactly one destination remains possible even under an intentionally
        optimistic movement lower bound.  Ambiguity => no inheritance.
        """
        sp={tuple(x) for x in prior.get("outside",{}).get(actor,[])}
        ep={tuple(x) for x in snap.get("outside",{}).get(actor,[])}
        if not sp or not ep:
            return
        old=[(pos,dict(tc)) for (owner,pos),tc in list(self._transition_constraints.items())
             if owner==actor and pos in sp]
        if not old:
            return
        inherited={}
        proposed=[]
        for oldpos,tc in old:
            possible=[]
            for dest in ep:
                lb=self._transition_lower_bound(g,actor,sp,ep,oldpos,dest)
                if lb<=int(budget):
                    possible.append((dest,lb))
            if len(possible)!=1:
                continue
            dest,lb=possible[0]
            ntc=dict(tc)
            ntc["opening"]=False
            ntc["persistent"]=True
            ntc["inherited_from"]=list(oldpos)
            ntc["budget"]=int(budget)
            ntc["proof_lower_bound"]=int(lb)
            ntc["method"]="SAFE-VIEW persistent identity by optimistic MOV impossibility proof"
            ntc["start"]=[list(x) for x in sorted(sp)]
            ntc["end"]=list(dest)
            proposed.append((oldpos,dest,ntc))
        # Two previously distinct proven circles cannot both become one current
        # anonymous circle. A destination collision means our cheap proof is not
        # sufficient to identify either one, so preserve neither.
        counts=defaultdict(int)
        for _,dest,_ in proposed: counts[dest]+=1
        for oldpos,dest,ntc in proposed:
            if counts[dest]==1:
                inherited[(actor,dest)]=ntc

        # Public fight evidence is identity evidence too: never leave it glued
        # to a coordinate merely because some circle still occupies that square.
        # Carry it only when the same optimistic impossibility proof yields one
        # unique destination; otherwise deliberately forget the identity link.
        old_evidence={pos:dict(ev) for (owner,pos),ev in self._evidence.items()
                      if owner==actor and pos in sp and ev}
        for key in [k for k in self._evidence if k[0]==actor]:
            self._evidence.pop(key,None)
        evidence_moves=[]
        for oldpos,ev in old_evidence.items():
            possible=[]
            for dest in ep:
                lb=self._transition_lower_bound(g,actor,sp,ep,oldpos,dest)
                if lb<=int(budget): possible.append(dest)
            if len(possible)==1:
                evidence_moves.append((possible[0],ev))
        ec=defaultdict(int)
        for dest,_ in evidence_moves: ec[dest]+=1
        for dest,ev in evidence_moves:
            if ec[dest]==1:
                self._evidence[(actor,dest)].update(ev)

        # Remove stale positional constraints for this actor, then install only
        # constraints whose identity survived a proof. This prevents coordinate
        # persistence from masquerading as token identity.
        for key in [k for k in self._transition_constraints if k[0]==actor]:
            self._transition_constraints.pop(key,None)
        self._transition_constraints.update(inherited)

    def _process_new_events(self,g):
        """Consume ONLY GameState.observer_view(); never the omniscient g.log.

        Public perception is intentionally tiny: outside circle coordinates and
        base ownership snapshots. The only event layer is fight winner/loser;
        ATK/DEF/losses are supplied only when this bot participated.
        """
        self._ensure_initialized(g)
        view=g.observer_view(self.player)

        # Difficulty changes perception/memory, never the underlying rules or
        # personality. Easy remembers no old positional combat identity between
        # decisions; Medium remembers public combat evidence; Hard additionally
        # performs legal SAFE-VIEW transition reconstruction.
        if self.difficulty == "easy":
            self._evidence.clear()
            self._transition_constraints.clear()
            self._hidden_prep_suspicion.clear()

        # Snapshot-to-snapshot history. No action path, MOV spend, harvest event,
        # reinforcement event, boarding event, or persistent token ID exists here.
        snaps=view.get("snapshots",[])
        for snap in snaps[self._safe_snapshot_index:]:
            actor=snap.get("actor")
            if actor is None or actor==self.player or snap.get("phase")!="turn_end":
                continue
            # Pair with the most recent safe turn_start for this actor.
            prior=None
            for cand in reversed(snaps[:snap.get("seq",0)]):
                if cand.get("actor")==actor and cand.get("phase")=="turn_start":
                    prior=cand; break
            if prior is None:
                continue
            sp={tuple(x) for x in prior.get("outside",{}).get(actor,[])}
            ep={tuple(x) for x in snap.get("outside",{}).get(actor,[])}
            # MOV is inferred from the START screenshot: base_move + owned bases
            # + outside circles. No MOV value is received from the engine.
            owned=sum(1 for owner in prior.get("base_owners",{}).values() if owner==actor)
            budget=(1+owned+len(sp)) if getattr(g,"base_movement",False) else (int(getattr(g,"base_move",1))+len(sp))
            if self.difficulty == "hard":
                self._propagate_transition_constraints(g,actor,prior,snap,budget)
                self._opening_transition_constraint(g,actor,prior,snap,budget)
            disappeared=[x for x in sp if x not in ep]
            appeared=[x for x in ep if x not in sp]
            # Without seeing actions there is no legitimate visible-spend figure.
            # Keep only geometry complexity as a weak "hidden preparation possible"
            # signal; do not pretend to know which circle moved or boarded.
            transition_signal=min(1.0,0.20*len(disappeared)+0.12*len(appeared))
            old=self._hidden_prep_suspicion[actor]
            suspicion=(max(0.0,min(1.0,old*0.50+transition_signal))
                       if self.difficulty != "easy" else 0.0)
            self._hidden_prep_suspicion[actor]=suspicion
            self._public_intel_history[actor].append({
                "global_turn":snap.get("global_turn"),
                "inferred_budget":budget,
                "start":[list(x) for x in sorted(sp)],
                "end":[list(x) for x in sorted(ep)],
                "disappeared":[list(x) for x in disappeared],
                "appeared":[list(x) for x in appeared],
                "concealed_preparation":round(suspicion,4),
            })
            self._public_intel_history[actor]=self._public_intel_history[actor][-6:]
        self._safe_snapshot_index=len(snaps)

        fights=view.get("fights",[])
        for ev in fights[self._safe_fight_index:]:
            pub=ev.get("public",{})
            attacker=pub.get("attacker"); defender=pub.get("defender")
            winner=pub.get("winner"); loc=pub.get("location")
            is_base=bool(pub.get("base"))
            if not is_base and winner is not None and loc is not None:
                evidence=self._evidence[(winner,tuple(loc))]
                evidence["fight_wins"]=evidence.get("fight_wins",0)+1
                if winner==attacker:
                    evidence["initiated_fight"]=evidence.get("initiated_fight",0)+1

            # Participants alone receive combat values/casualties.
            private=ev.get("private")
            if private:
                losses=private.get("losses",[])
                for owner,kinds in losses:
                    self._apply_known_losses(owner,kinds)
                if (not is_base and winner is not None and winner!=self.player
                        and loc is not None):
                    initial=(private.get("atk") if winner==attacker else private.get("def"))
                    if initial is not None:
                        winner_losses=[]
                        for owner,kinds in losses:
                            if owner==winner: winner_losses.extend(kinds)
                        final_atk=initial-winner_losses.count("pawn")-2*winner_losses.count("leader")
                        self._evidence[(winner,tuple(loc))]["exact_atk"]=max(0,final_atk)
        self._safe_fight_index=len(fights)

        self._observe_public_board(g)
        self._belief_cache_key=None

    def _remaining_material(self,p):
        total=self._material[p]
        lost=self._known_losses[p]
        return {
            "pawns":max(0,total["pawns"]-lost["pawns"]),
            "leader":max(0,total["leader"]-lost["leader"]),
            "saboteur":max(0,total["saboteur"]-lost["saboteur"]),
            "vehicles":max(0,total["vehicles"]-lost["vehicles"]),
        }

    # ================================================================
    # HIDDEN-STATE ENUMERATION
    # ================================================================

    def _possible_states(self,remaining):
        """All legal compositions ONE generic enemy circle could represent."""
        states=[]

        def add(name,atk,p=0,l=0,s=0,v=0,vehicle=False,occupied=False):
            states.append({
                "name":name,"atk":atk,
                "pawns":p,"leader":l,"saboteur":s,"vehicles":v,
                "vehicle":vehicle,"occupied_vehicle":occupied,
            })

        if remaining["pawns"]>0:
            add("pawn",1,p=1)
        if remaining["leader"]>0:
            add("leader",2,l=1)
        if remaining["saboteur"]>0:
            add("saboteur",0,s=1)

        if remaining["vehicles"]>0:
            add("empty_vehicle",0,v=1,vehicle=True,occupied=False)

            # Vehicle occupants: pawns and optionally leader, never Saboteur.
            for pawns in range(1,min(4,remaining["pawns"])+1):
                add(f"vehicle_{pawns}p",pawns,p=pawns,v=1,
                    vehicle=True,occupied=True)

            if remaining["leader"]>0:
                add("vehicle_L",2,l=1,v=1,vehicle=True,occupied=True)
                for pawns in range(1,min(3,remaining["pawns"])+1):
                    add(f"vehicle_L{pawns}p",2+pawns,p=pawns,l=1,v=1,
                        vehicle=True,occupied=True)

        return states

    def _state_weight(self,p,pos,state):
        """Soft behavioural evidence. Never turns a guess into certainty."""
        w=1.0
        evidence=self._evidence.get((p,pos),{})
        stationary=self._stationary.get((p,pos),0)

        exact=evidence.get("exact_atk")
        if exact is not None and state["atk"]!=exact:
            return 0.0

        tc=self._transition_constraints.get((p,pos))
        if tc:
            if tc.get("require_leader") and not state["leader"]:
                return 0.0
            if tc.get("require_vehicle") and not state["vehicle"]:
                return 0.0
            if state["pawns"] < int(tc.get("min_pawns",0)):
                return 0.0
            if state["pawns"] > int(tc.get("max_pawns",99)):
                return 0.0
            legal_counts=tc.get("legal_pawn_counts")
            if legal_counts is not None and state["pawns"] not in legal_counts:
                return 0.0
            # Among legal opening histories, prefer efficient preparation but
            # never turn a merely rational choice into certainty.
            if tc.get("opening_origin") and state["leader"] and state["vehicle"]:
                if state["pawns"]>0:
                    w*=float(tc.get("rational_pawn_loading_prior",4.0))**state["pawns"]

        wins=int(evidence.get("fight_wins",0) or 0)
        initiated=int(evidence.get("initiated_fight",0) or 0)

        # V1.7: combat history is likelihood evidence, not a generic "danger"
        # modifier.  Voluntarily initiating an UNKNOWN field fight and then
        # surviving/winning is powerful evidence against a lone pawn: that is
        # legal (the victim might have been a Saboteur) but behaviourally rare.
        # Conversely ATK2+ teams are much more plausible attackers.  These are
        # deliberately soft likelihoods: no public combat result reveals the
        # hidden composition to a non-participant.
        paired=min(wins,initiated)
        if paired:
            atk=int(state["atk"])
            if state["name"]=="empty_vehicle":
                factor=0.002
            elif state["name"]=="saboteur":
                # A blind Saboteur attack can work if the target was a vehicle,
                # but an observer does not know that target identity.
                factor=0.12
            elif atk<=1:
                factor=0.035
            elif atk==2:
                factor=1.00
            elif atk==3:
                factor=7.00
            else:
                factor=9.00
            w*=factor**paired
            wins-=paired
            initiated-=paired

        # Unpaired evidence is weaker.  This matters when a token won as the
        # defender, or initiated a fight but did not produce a surviving win.
        if wins:
            if state["name"]=="empty_vehicle":
                w*=0.02**wins
            elif state["name"]=="saboteur":
                w*=0.30**wins
            elif state["name"]=="pawn":
                w*=0.42**wins
            elif state["occupied_vehicle"]:
                w*=1.35**wins
            elif state["atk"]>=2:
                w*=1.18**wins

        if initiated:
            if state["name"]=="empty_vehicle":
                w*=0.01**initiated
            elif state["name"]=="saboteur":
                w*=0.35**initiated
            elif state["name"]=="pawn":
                w*=0.22**initiated
            elif state["occupied_vehicle"]:
                w*=1.22**initiated
            elif state["atk"]>=2:
                w*=1.12**initiated

        # Long inactivity is compatible with many plans, so this is deliberately
        # weak. It merely raises the empty-vehicle bluff hypothesis over time.
        if stationary>=2 and state["name"]=="empty_vehicle":
            w*=min(3.0,1.0+0.28*stationary)

        return w

    @staticmethod
    def _usage(state):
        return (
            state["pawns"],state["leader"],
            state["saboteur"],state["vehicles"]
        )

    @staticmethod
    def _fits(usage,limit):
        return all(a<=b for a,b in zip(usage,limit))

    def _beliefs_for_player(self,g,p):
        current=g.observer_view(self.player)["current"]
        positions=sorted(tuple(x) for x in current["outside"].get(p,[]))
        remaining=self._remaining_material(p)
        limit=(remaining["pawns"],remaining["leader"],
               remaining["saboteur"],remaining["vehicles"])

        if not positions:
            return {}

        states=self._possible_states(remaining)
        weighted=[]
        for pos in positions:
            opts=[]
            for st in states:
                w=self._state_weight(p,pos,st)
                if w>0 and self._fits(self._usage(st),limit):
                    opts.append((st,w))
            weighted.append(opts)

        # Forward dynamic program over resource usage.
        forward=[{(0,0,0,0):1.0}]
        for opts in weighted:
            nxt=defaultdict(float)
            for used,base_w in forward[-1].items():
                for st,w in opts:
                    u=self._usage(st)
                    nu=tuple(used[i]+u[i] for i in range(4))
                    if self._fits(nu,limit):
                        nxt[nu]+=base_w*w
            forward.append(dict(nxt))

        # Backward DP.
        n=len(positions)
        backward=[None]*(n+1)
        backward[n]={(0,0,0,0):1.0}
        for i in range(n-1,-1,-1):
            cur=defaultdict(float)
            for st,w in weighted[i]:
                u=self._usage(st)
                for post,post_w in backward[i+1].items():
                    nu=tuple(u[j]+post[j] for j in range(4))
                    if self._fits(nu,limit):
                        cur[nu]+=w*post_w
            backward[i]=dict(cur)

        # Leader cannot be hidden in a base/reserve: if the opponent is alive,
        # exactly one visible circle must account for the living leader.
        required_leader=1 if g.alive[p] and remaining["leader"]>0 else 0

        def final_ok(used):
            return used[1]==required_leader

        total=sum(w for used,w in forward[n].items() if final_ok(used))

        # Defensive fallback if public-known bookkeeping becomes inconsistent.
        if total<=0:
            result={}
            for pos,opts in zip(positions,weighted):
                z=sum(w for _,w in opts) or 1.0
                result[pos]=self._summarize_state_probs(
                    [(st,w/z) for st,w in opts]
                )
            return result

        results={}
        for i,pos in enumerate(positions):
            state_mass=defaultdict(float)
            for st,sw in weighted[i]:
                su=self._usage(st)
                mass=0.0
                for pre,pw in forward[i].items():
                    base=tuple(pre[j]+su[j] for j in range(4))
                    if not self._fits(base,limit):
                        continue
                    for post,qw in backward[i+1].items():
                        final=tuple(base[j]+post[j] for j in range(4))
                        if self._fits(final,limit) and final_ok(final):
                            mass+=pw*sw*qw
                if mass:
                    state_mass[st["name"]]+=mass

            # map state names back to state objects
            probs=[]
            by_name={st["name"]:st for st in states}
            z=sum(state_mass.values()) or 1.0
            for name,mass in state_mass.items():
                probs.append((by_name[name],mass/z))
            results[pos]=self._summarize_state_probs(probs)

        return results

    def _summarize_state_probs(self,probs):
        atk=defaultdict(float)
        p_leader=p_sab=p_vehicle=p_occ=p_empty=0.0
        detailed=[]
        expected=0.0

        for st,prob in probs:
            atk[int(st["atk"])]+=prob
            expected+=st["atk"]*prob
            if st["leader"]: p_leader+=prob
            if st["saboteur"]: p_sab+=prob
            if st["vehicle"]: p_vehicle+=prob
            if st["occupied_vehicle"]: p_occ+=prob
            if st["name"]=="empty_vehicle": p_empty+=prob
            detailed.append((st["name"],prob,st["atk"],bool(st["leader"])))

        detailed.sort(key=lambda x:x[1],reverse=True)
        return {
            "expected_atk":expected,
            "atk_probs":dict(sorted(atk.items())),
            "p_leader":p_leader,
            "p_saboteur":p_sab,
            "p_vehicle":p_vehicle,
            "p_occupied_vehicle":p_occ,
            "p_empty_vehicle":p_empty,
            "states":detailed,
        }

    def _all_beliefs(self,g):
        safe=g.observer_view(self.player)
        key=(
            g.turn,len(safe.get("snapshots",[])),len(safe.get("fights",[])),
            tuple((p,tuple(pos)) for p,poses in sorted(safe["current"]["outside"].items()) if p!=self.player for pos in sorted(poses))
        )
        if key==self._belief_cache_key:
            return self._belief_cache

        result={}
        for p in range(g.players):
            if p==self.player or not g.alive[p]:
                continue
            result[p]=self._beliefs_for_player(g,p)

        self._belief_cache_key=key
        self._belief_cache=result
        return result

    def _belief_for(self,g,owner,pos):
        return self._all_beliefs(g).get(owner,{}).get(tuple(pos),{
            "expected_atk":1.5,
            "atk_probs":{0:0.15,1:0.35,2:0.30,3:0.15,4:0.05},
            "p_leader":0.20,
            "p_saboteur":0.20,
            "p_vehicle":0.30,
            "p_occupied_vehicle":0.22,
            "p_empty_vehicle":0.08,
            "states":[],
        })

    # ================================================================
    # STRATEGIC HELPERS
    # ================================================================

    def _active_harvests(self,g,player=None):
        p=self.player if player is None else player
        return [h for h in g.harvest_tiles if g.harvest_active[p].get(h,False)]

    def _owned_corner_count(self,g,player):
        m=g.grid-1
        corners=[(0,0),(m,0),(m,m),(0,m)]
        owners=g.observer_view(self.player)["current"]["base_owners"]
        return sum(1 for pos in corners if owners.get(f"{pos[0]},{pos[1]}")==player)

    def _opponent_threat(self,g,player):
        """Threat estimate from safe public board + public fight outcomes only."""
        if player==self.player or not g.alive[player]:
            return 0.0
        view=g.observer_view(self.player)["current"]
        visible=len(view["outside"].get(player,[]))
        owned=sum(1 for owner in view["base_owners"].values() if owner==player)
        wins=sum(int(ev.get("fight_wins",0) or 0)
                 for (owner,_),ev in self._evidence.items() if owner==player)
        return visible*5.0 + owned*14.0 + wins*18.0

    def _critical_enemy_harvests(self,g):
        # No engine harvest marks/status for opponents. A future Hard inference
        # may reconstruct harvest history from safe end-of-turn screenshots, but
        # until then we prefer ignorance to a hidden-information shortcut.
        return {}

    def _starting_visible_baseline(self,g):
        return 1 + (1 if getattr(g,"starting_vehicle",True) else 0)

    def _corner_position(self,g,p):
        m=g.grid-1
        for pos in ((0,0),(m,0),(m,m),(0,m)):
            b=g.bases.get(pos)
            if b is not None and b.owner==p:
                return pos
        return None

    def _opening_leader_harvest_penalty(self,g,token,dest):
        """Early harvest rushes by an exposed leader are conditional, not default.

        At the very start, information is unusually clean. A neighboring faction
        showing MORE field units than its normal leader+vehicle baseline has
        publicly mobilized material. That is a red flag for sending a naked
        leader deep onto a harvest tile.

        No hidden composition is read here.
        """
        if (
            getattr(g,"global_turn",99)>2
            or token.vehicle
            or not token.has_leader()
            or dest not in self._active_harvests(g)
        ):
            return 0.0

        # Opening player gets the initiative before anyone has shown a plan.
        if getattr(g,"global_turn",1)==1 and self.player==getattr(g,"starting_player",-1):
            return 0.0

        home=self._corner_position(g,self.player)
        if home is None:
            return 0.0

        edge=g.grid-1
        baseline=self._starting_visible_baseline(g)
        penalty=0.0

        for enemy in range(g.players):
            if enemy==self.player or not g.alive[enemy]:
                continue
            enemy_home=self._corner_position(g,enemy)
            if enemy_home is None:
                continue

            # Only the two edge-neighbors are immediate opening threats.
            if self._manhattan(home,enemy_home)!=edge:
                continue

            extra=max(0,g.visible_units(enemy)-baseline)
            if extra:
                # One deployed extra unit is a warning; two is a clear
                # mobilization/consolidation signal like the CIA death match.
                penalty += 48.0 + 34.0*extra

        return penalty

    # ================================================================
    # OWN LEADER
    # ================================================================

    def _leader_token(self,g):
        for t in g.tokens:
            if t.owner==self.player and t.has_leader():
                return t
        return None

    def _leader_is_concealed(self,token):
        return bool(token is not None and token.vehicle)

    def _update_leader_memory(self,g):
        if self._last_memory_turn==g.turn:
            return
        self._last_memory_turn=g.turn
        leader=self._leader_token(g)
        if leader is None:
            return
        pos=(leader.x,leader.y)
        if pos==self._leader_last_pos:
            self._leader_stationary_turns+=1
        else:
            self._leader_stationary_turns=0
        self._leader_last_pos=pos
        if self._leader_is_concealed(leader):
            self._leader_exposed_turns=0
        else:
            self._leader_exposed_turns+=1

    def _enemy_proximity_penalty(self,g,pos,severe=False):
        view=g.observer_view(self.player)["current"]
        dists=[self._manhattan(pos,tuple(epos))
               for p,poses in view["outside"].items() if p!=self.player and g.alive[p]
               for epos in poses]
        if not dists: return 0.0
        d=min(dists)
        nearby=sum(1 for x in dists if x<=2)
        if d<=1: penalty=96 if severe else 40
        elif d==2: penalty=50 if severe else 22
        elif d==3: penalty=18 if severe else 8
        else: penalty=0
        if nearby>=2: penalty+=15 if severe else 7
        return penalty

    def _leader_danger_penalty(self,g,token,pos):
        if not token.has_leader(): return 0.0
        penalty=self._enemy_proximity_penalty(g,pos,severe=True)
        if not token.vehicle:
            penalty+=20+min(30,self._leader_exposed_turns*6)
        return penalty

    # ================================================================
    # PROBABILISTIC COMBAT
    # ================================================================

    def _attack_evaluation(self,g,token,target,dest):
        belief=self._belief_for(g,target.owner,dest)
        own=token.strength()
        atk_probs=belief["atk_probs"]

        if token.has_saboteur():
            # Special wins only against occupied vehicle.
            p_win=belief["p_occupied_vehicle"]
            p_tie=0.0
            p_loss=1.0-p_win
        else:
            p_win=sum(prob for atk,prob in atk_probs.items() if atk<own)
            p_tie=atk_probs.get(own,0.0)
            p_loss=sum(prob for atk,prob in atk_probs.items() if atk>own)

        p_leader_kill=0.0
        for name,prob,atk,has_leader in belief["states"]:
            if not has_leader:
                continue
            if token.has_saboteur():
                if name.startswith("vehicle_") or name=="vehicle_L":
                    p_leader_kill+=prob
            elif own>atk:
                p_leader_kill+=prob

        threat=self._opponent_threat(g,target.owner)

        # Expected-value attack score. All factions use the same probabilities;
        # personality only changes how much uncertainty/risk they accept.
        risk=self._pw("risk_tolerance")
        safety=self._pw("leader_safety")
        leader_reward=self._pw("leader_kill_reward")

        score=-22
        score+=115*p_win
        score-=(78/risk)*p_loss
        score-=(50/risk)*p_tie
        score+=70*leader_reward*p_leader_kill
        score+=0.32*threat

        # Don't gamble the own leader casually. FBI is more conservative;
        # Italian Mafia is a little more willing to accept a high-payoff shot.
        if token.has_leader():
            score-=75*safety*(p_loss+p_tie)
            if token.vehicle:
                score-=18*safety*(1-p_win)

        # Saboteur is valuable but its one-shot payoff can justify a strong read.
        if token.has_saboteur():
            score-=35*(1-p_win)
            score+=60*belief["p_occupied_vehicle"]

        # A field attack at ATK 3+ necessarily reveals "occupied vehicle" to
        # the defender, because exposed units can only be pawn=1, leader=2,
        # Saboteur=0. This creates a very real counter-Saboteur risk.
        reveal_penalty=0.0
        reveal_p_sab=0.0
        reveal_sources=[]
        if token.vehicle and own>2 and target.owner is not None:
            reveal_p_sab,reveal_sources=self._saboteur_threat_from_player_at(
                g,target.owner,dest
            )
            pawns=sum(
                1 for x in token.people
                if not x.leader and not getattr(x,"saboteur",False)
            )
            cargo_value=28 + 24*pawns + (145 if token.has_leader() else 0)

            # Risk only exists if the vehicle survives and the defender faction
            # survives the attack. Revelation makes that Saboteur much more
            # actionable, hence the modest 1.25 multiplier.
            counter_window=p_win*max(0.0,1.0-p_leader_kill)
            reveal_penalty=counter_window*reveal_p_sab*cargo_value*1.25
            score-=reveal_penalty

        detail={
            "target":[dest[0],dest[1]],
            "target_player":target.owner,
            "own_atk":own,
            "p_win":p_win,
            "p_tie":p_tie,
            "p_loss":p_loss,
            "p_leader_kill":p_leader_kill,
            "belief":belief,
            "vehicle_attack_reveals":bool(token.vehicle and own>2),
            "post_attack_reveal_risk":{
                "p_reachable_defender_saboteur":reveal_p_sab,
                "penalty":reveal_penalty,
                "sources":[
                    {"pos":[pos[0],pos[1]],"weighted_p":q}
                    for pos,q in reveal_sources
                ],
            },
            "score":score,
        }
        return score,detail

    # ================================================================
    # POSITION / BASE SCORING
    # ================================================================

    def _public_enemy_move_budget(self,g,p):
        # Infer MOV exactly as a player does from the current screenshot.
        view=g.observer_view(self.player)["current"]
        visible=len(view["outside"].get(p,[]))
        owned=sum(1 for owner in view["base_owners"].values() if owner==p)
        return int(getattr(g,"base_move",1))+owned+visible

    def _saboteur_threat_at(self,g,dest):
        total_survival=1.0
        sources=[]
        beliefs=self._all_beliefs(g)

        for p,by_pos in beliefs.items():
            if not g.alive[p]:
                continue
            budget=self._public_enemy_move_budget(g,p)
            for pos,b in by_pos.items():
                ps=b.get("p_saboteur",0.0)
                if ps<=0:
                    continue
                dist=self._manhattan(pos,dest)
                if dist<=budget:
                    reach_factor=1.0 if dist<=max(1,budget-1) else 0.72
                    q=max(0.0,min(1.0,ps*reach_factor))
                    total_survival*=1.0-q
                    sources.append((p,pos,q))

        return 1.0-total_survival,sources

    def _saboteur_threat_from_player_at(self,g,enemy,dest):
        """Probability that THIS specific enemy has a Saboteur able to reach
        dest next turn, using only this bot's belief state."""
        if enemy is None or not g.alive[enemy]:
            return 0.0,[]

        by_pos=self._all_beliefs(g).get(enemy,{})
        budget=self._public_enemy_move_budget(g,enemy)
        total_survival=1.0
        sources=[]

        for pos,belief in by_pos.items():
            ps=belief.get("p_saboteur",0.0)
            if ps<=0:
                continue
            dist=self._manhattan(pos,dest)
            if dist<=budget:
                reach_factor=1.0 if dist<=max(1,budget-1) else 0.72
                q=max(0.0,min(1.0,ps*reach_factor))
                total_survival*=1.0-q
                sources.append((pos,q))

        return 1.0-total_survival,sources

    def _projected_load_exposure(self,g,vehicle,person):
        """Penalty for creating a Saboteur jackpot by loading this person.

        Uses only public enemy beliefs + public next-turn MOV.  This is not a
        ban on leader vehicles: it prices the *consequence* of concentrating
        valuable cargo where a plausible Saboteur can reach next global turn.
        """
        if vehicle is None or not getattr(vehicle,"vehicle",False):
            return 0.0,{}
        projected=list(vehicle.people)+[person]
        has_leader=any(x.leader for x in projected)
        pawns=sum(1 for x in projected if x.regular)
        if not has_leader:
            return 0.0,{}
        p_sab,sources=self._saboteur_threat_at(g,(vehicle.x,vehicle.y))
        if p_sab<=0:
            return 0.0,{}

        # Losing a leader ends the game, so leader+cargo concentration deserves
        # a real alarm.  Still probabilistic: a remote/weak Saboteur hypothesis
        # can be accepted when the offensive payoff is genuinely strong.
        catastrophe_value=185.0+34.0*pawns
        penalty=p_sab*catastrophe_value
        if pawns>=2 and p_sab>=0.15:
            penalty+=22.0
        if pawns>=3 and p_sab>=0.20:
            penalty+=18.0
        return penalty,{
            "p_reachable_saboteur":p_sab,
            "projected_pawns":pawns,
            "projected_leader":True,
            "penalty":penalty,
            "sources":[
                {"player":pl,"pos":[pos[0],pos[1]],"weighted_p":q}
                for pl,pos,q in sources
            ],
        }

    def _vehicle_destination_risk(self,g,token,dest):
        if not token.vehicle or not token.people:
            return 0.0,{}

        p_sab,sources=self._saboteur_threat_at(g,dest)
        pawns=sum(1 for x in token.people
                  if not x.leader and not getattr(x,"saboteur",False))
        has_leader=token.has_leader()

        cargo_value=28 + 24*pawns + (145 if has_leader else 0)
        penalty=p_sab*cargo_value

        return penalty,{
            "saboteur_threat":p_sab,
            "cargo_pawns":pawns,
            "contains_leader":has_leader,
            "penalty":penalty,
            "sources":[
                {"player":p,"pos":[pos[0],pos[1]],"weighted_p":q}
                for p,pos,q in sources
            ],
        }

    def _nearest_objective_distance(self,g,pos):
        goals=list(self._active_harvests(g))
        goals += [p for p,b in g.bases.items() if b.owner is None]

        # Defend the territorial clock.
        if self._owned_corner_count(g,self.player)<4:
            m=g.grid-1
            corners=[(0,0),(m,0),(m,m),(0,m)]
            for enemy in range(g.players):
                if enemy==self.player or not g.alive[enemy]:
                    continue
                if self._owned_corner_count(g,enemy)>=3:
                    goals += [c for c in corners if g.bases[c].owner!=enemy]

        return min((self._manhattan(pos,h) for h in goals),default=0)

    def _score_empty_destination(self,g,token,dest):
        score=0.0
        active=self._active_harvests(g)
        if dest in active:
            marks=g.harvest_marks[self.player]
            harvest_w=self._pw("harvest")
            score+=(96+marks*30)*harvest_w
            if marks>=3: score+=58*harvest_w
        else:
            before=self._nearest_objective_distance(g,(token.x,token.y))
            after=self._nearest_objective_distance(g,dest)
            score+=(before-after)*11

        urgent=self._critical_enemy_harvests(g)
        if dest in urgent:
            score+=urgent[dest]*self._pw("harvest_block")

        c=g.grid//2
        score+=(
            max(0,4-self._manhattan(dest,(c,c)))
            *1.2*self._pw("center")
        )

        if token.has_leader():
            # Leader safety is a persistent personality trait, not something
            # used only while evaluating combat. FBI therefore reacts more
            # strongly to exposed destinations; Italian Mafia accepts a little
            # more positional risk.
            score-=(
                self._leader_danger_penalty(g,token,dest)
                * self._pw("leader_safety")
            )
            score-=(
                self._opening_leader_harvest_penalty(g,token,dest)
                * self._pw("leader_safety")
            )
            if not token.vehicle and (token.x,token.y)!=dest:
                score+=min(24,6+self._leader_stationary_turns*5)
        else:
            score-=self._enemy_proximity_penalty(g,dest,False)*0.20

        if token.vehicle and token.people:
            risk,_meta=self._vehicle_destination_risk(g,token,dest)
            score-=risk


        return score

    def _post_capture_approach(self,g,token,dest):
        """Publicly calculable square where an assault survivor will end.

        The real resolver leaves the attacker on the last traversable square
        before the base. Using the normal public pathfinder here mirrors that
        geometry without looking at hidden enemy information.
        """
        path=g.find_path((token.x,token.y),dest,self.player)
        if not path:
            return (token.x,token.y)
        return path[-2] if len(path)>=2 else (token.x,token.y)

    def _post_capture_leader_threat(self,g,token,dest):
        """Forecast danger AFTER a successful base capture.

        Capturing a base unloads every non-leader occupant into the base.
        Therefore a leader assault ends with:
          - naked leader outside, or
          - leader-only occupied vehicle outside (strength/DEF 2).

        That temporary split can turn a safe ATK 3/4/5 vehicle into an exposed
        leader before the bot gets another turn. We estimate, from public
        positions + this bot's beliefs, the probability that at least one enemy
        can reach and defeat that resulting leader token.

        No enemy hidden state is read.
        """
        detail={
            "applies":False,
            "approach":None,
            "post_strength":None,
            "p_lethal_counter":0.0,
            "p_saboteur_counter":0.0,
            "penalty":0.0,
            "sources":[],
        }

        if not token.has_leader():
            return 0.0,detail

        approach=self._post_capture_approach(g,token,dest)
        post_vehicle=bool(token.vehicle)

        # All non-leaders enter the captured base; leader remains outside.
        post_strength=2
        total_survival=1.0
        total_sab_survival=1.0
        sources=[]
        beliefs=self._all_beliefs(g)

        for enemy,by_pos in beliefs.items():
            if enemy==self.player or not g.alive[enemy]:
                continue

            budget=self._public_enemy_move_budget(g,enemy)

            for pos,b in by_pos.items():
                # Approximate one-turn reach from public geometry. Manhattan is
                # deliberately a little conservative here: a leader's life is
                # worth checking even when a route may later be obstructed.
                dist=self._manhattan(pos,approach)
                if dist>budget:
                    continue

                reach_factor=1.0 if dist<=max(1,budget-1) else 0.72
                atk_probs=b.get("atk_probs",{})

                if getattr(g,"draw_winner","defender")=="attacker":
                    p_normal=sum(
                        prob for atk,prob in atk_probs.items()
                        if atk>=post_strength
                    )
                else:
                    p_normal=sum(
                        prob for atk,prob in atk_probs.items()
                        if atk>post_strength
                    )

                # A Saboteur is uniquely lethal against the leader-only vehicle.
                p_sab=b.get("p_saboteur",0.0) if post_vehicle else 0.0

                # Avoid double-counting the Saboteur state inside atk_probs:
                # its ATK is zero, so it is not included in p_normal anyway.
                p_lethal=max(0.0,min(1.0,(p_normal+p_sab)*reach_factor))
                p_sab_r=max(0.0,min(1.0,p_sab*reach_factor))

                if p_lethal>0:
                    total_survival*=1.0-p_lethal
                    total_sab_survival*=1.0-p_sab_r
                    sources.append({
                        "player":enemy,
                        "pos":[pos[0],pos[1]],
                        "distance":dist,
                        "move_budget":budget,
                        "p_normal_lethal":p_normal*reach_factor,
                        "p_saboteur_lethal":p_sab_r,
                        "p_lethal":p_lethal,
                    })

        p_lethal=1.0-total_survival
        p_sab=1.0-total_sab_survival

        # Existential risk deserves a large cost, but it is not an absolute
        # prohibition: a near-winning territorial capture can still outweigh it.
        # Personality changes how heavily that danger is treated.
        safety=self._pw("leader_safety")
        penalty=p_lethal*185.0*safety

        # A leader-only vehicle is additionally vulnerable to the special
        # Saboteur one-shot and has just lost the protection of its pawns.
        if post_vehicle:
            penalty+=p_sab*70.0*safety

        detail={
            "applies":True,
            "approach":[approach[0],approach[1]],
            "post_strength":post_strength,
            "post_vehicle":post_vehicle,
            "p_lethal_counter":p_lethal,
            "p_saboteur_counter":p_sab,
            "penalty":penalty,
            "sources":sources,
        }
        return penalty,detail

    def _base_mobility_capture_value(self,g,p_win=1.0):
        """Direct value of a base under the public +1 MOV-per-base rule.

        This is a V3.6 donor trait: it values the rule consequence itself,
        without adding the later last-base survival machinery.
        """
        if not getattr(g,"base_movement",False):
            return 0.0
        visible=min(g.visible_units(self.player),g.unit_cap)
        value=22.0 + min(12.0,visible*2.0)
        return value*p_win*self._pw("base_control")

    def _base_attack_score(self,g,token,base,dest):
        own=token.strength()
        exposure_penalty,exposure=self._post_capture_leader_threat(
            g,token,dest
        )

        if base.owner is None:
            p_win=1.0 if own>1 else 0.0
            p_tie=1.0 if own==1 else 0.0
            p_loss=0.0 if (p_win or p_tie) else 1.0

            score=(105*p_win-80*p_tie)*self._pw("base_control")
            if dest==(g.grid//2,g.grid//2):
                score+=10*self._pw("center")
            score+=self._base_mobility_capture_value(g,p_win)
            if token.has_leader():
                score-=120*p_tie

            # Exposure exists only if the capture actually succeeds.
            score-=exposure_penalty*p_win

            return score,{
                "target":[dest[0],dest[1]],
                "owner":None,
                "own_atk":own,
                "p_win":p_win,
                "p_tie":p_tie,
                "p_loss":p_loss,
                "post_capture_exposure":exposure,
                "score":score,
            }

        enemy=base.owner
        threat=self._opponent_threat(g,enemy)

        # Enemy base contents are not visible. Owner is public; occupants are not.
        p_def_ge2=0.38

        p2=min(0.65,p_def_ge2)
        p3=min(0.22,max(0.0,p_def_ge2-0.35))
        p4=min(0.10,max(0.0,p_def_ge2-0.58))
        p5=min(0.04,max(0.0,p_def_ge2-0.75))
        p1=max(0.0,1.0-(p2+p3+p4+p5))
        dist={1:p1,2:p2,3:p3,4:p4,5:p5}
        z=sum(dist.values()) or 1.0
        dist={k:v/z for k,v in dist.items()}

        p_win=sum(p for d,p in dist.items() if own>d)
        p_tie=dist.get(own,0.0)
        p_loss=sum(p for d,p in dist.items() if own<d)

        risk=self._pw("risk_tolerance")
        score=(105*p_win-(72/risk)*p_loss-(58/risk)*p_tie)
        score*=self._pw("base_control")
        score+=0.38*threat
        score+=self._base_mobility_capture_value(g,p_win)

        own_corners=self._owned_corner_count(g,self.player)
        enemy_corners=self._owned_corner_count(g,enemy)
        if own_corners>=3 and dest!=(g.grid//2,g.grid//2):
            score+=150*self._pw("base_control")
        if enemy_corners>=3 and dest!=(g.grid//2,g.grid//2):
            score+=120*self._pw("base_control")

        if token.has_leader():
            score-=180*self._pw("leader_safety")*(p_tie+p_loss)

        # Winning can itself create an existentially bad state when the assault
        # splits pawns into the base and leaves the leader outside.
        score-=exposure_penalty*p_win

        return score,{
            "target":[dest[0],dest[1]],
            "owner":enemy,
            "own_atk":own,
            "p_win":p_win,
            "p_tie":p_tie,
            "p_loss":p_loss,
            "post_capture_exposure":exposure,
            "score":score,
        }

    def _friendly_interaction_score(self,g,token,target):
        if target is None:
            return -999.0

        # Reverse boarding: occupied vehicle drives onto a friendly pawn/leader.
        if token.vehicle and not target.vehicle:
            if not token.people or target.has_saboteur():
                return -999.0
            if len(token.people)+len(target.people)>4:
                return -999.0
            # Same strategic result as the person boarding the vehicle, but may
            # be much cheaper in movement cost.
            bonus=38.0*self._pw("concentration")
            if target.has_leader():
                bonus+=18.0*self._pw("concentration")
            return bonus

        if not target.vehicle:
            return -999.0
        if token.has_saboteur() or token.vehicle:
            return -999.0

        # Leader + empty vehicle has almost no upside in Mini:
        # no secrecy gain, no ATK gain, one fewer visible unit/move source,
        # and new Saboteur vulnerability.
        if token.has_leader():
            if not target.people:
                visible=sum(1 for t in g.tokens if t.owner==self.player)
                cap_pressure=max(0,visible-(g.unit_cap-1))
                return -58.0 + 22.0*cap_pressure
            return 72.0*self._pw("concentration")

        if not target.people:
            return 56.0*self._pw("concentration")
        return 31.0*self._pw("concentration")

    # ================================================================
    # CANDIDATE GENERATION
    # ================================================================

    def _leader_threat_snapshot(self,g,dest=None):
        """One-global-turn public threat forecast for our leader.

        This is intentionally not a survival planner.  It identifies credible
        immediate danger so the old aggressive brain can answer it with
        movement, decoys, development, counter-force or a first strike.
        """
        leader=self._leader_token(g)
        if leader is None:
            return {"risk":0.0,"sources":[],"max_reach":0,"recent_killer":False}
        if dest is None:
            dest=(leader.x,leader.y)
        own_def=leader.strength()
        in_vehicle=bool(leader.vehicle)
        sources=[]
        survival=1.0
        recent=False
        for enemy,by_pos in self._all_beliefs(g).items():
            if enemy==self.player or not g.alive[enemy]:
                continue
            budget=self._public_enemy_move_budget(g,enemy)
            prep=self._hidden_prep_suspicion.get(enemy,0.0)
            for pos,b in by_pos.items():
                dist=self._manhattan(pos,dest)
                if dist>budget:
                    continue
                reach=1.0 if dist<=max(1,budget-1) else 0.72
                ev=self._evidence.get((enemy,pos),{})
                wins=int(ev.get("fight_wins",0) or 0)
                if wins:
                    recent=True
                if in_vehicle:
                    p_kill=float(b.get("p_saboteur",0.0))
                else:
                    probs=b.get("atk_probs",{})
                    if getattr(g,"draw_winner","defender")=="attacker":
                        p_kill=sum(prob for atk,prob in probs.items() if atk>=own_def)
                    else:
                        p_kill=sum(prob for atk,prob in probs.items() if atk>own_def)
                # A demonstrated winner and unexplained MOV are legitimate
                # reasons to take the upper end of uncertainty more seriously.
                intent=min(1.0,0.62+0.13*min(2,wins)+0.22*prep)
                q=max(0.0,min(1.0,p_kill*reach*intent))
                if q<=0:
                    continue
                survival*=1.0-q
                sources.append({"player":enemy,"pos":pos,"distance":dist,
                                "budget":budget,"p_kill":q,"wins":wins,
                                "prep":prep})
        return {"risk":1.0-survival,"sources":sources,
                "max_reach":max((x["budget"] for x in sources),default=0),
                "recent_killer":recent}

    def _apply_survival_with_teeth(self,g,candidates):
        """Turn-local leader emergency response.

        Hard does not create a persistent revenge/counter-push objective.  On
        every action it re-reads the current SAFE-VIEW and, when the leader is
        credibly killable next global turn, follows a very small tactical order:

          1. identify the concrete threatening public circles;
          2. if one can be credibly destroyed *now*, prefer that first strike;
          3. otherwise make the cheapest leader move that gets out of lethal
             reach (or, if none is fully safe, the cheapest best risk reduction);
          4. as soon as the leader is safe this gate disappears and the old V3.4
             brain freely spends any remaining MOV from the new board state.

        Knowledge persists through the normal belief ledger; emergency intent
        does not.  This deliberately avoids a multi-turn counter-push planner.
        """
        leader=self._leader_token(g)
        if leader is None or not candidates:
            return candidates

        now=self._leader_threat_snapshot(g)
        risk=float(now.get("risk",0.0))
        alarm_threshold={"easy":0.28,"medium":0.21,"hard":0.18}[self.difficulty]
        if risk<alarm_threshold:
            return candidates

        sources={tuple(x["pos"]):x for x in now.get("sources",[])}

        # KILL FIRST.  Only an attack against an identified threat source can
        # satisfy the emergency, and only when our existing combat evaluator
        # says the destruction attempt is credible.  Do not hand +80 to generic
        # loading/deployment merely because an alarm exists.
        neutralizers=[]
        for item in candidates:
            score,kind,obj,payload,reason=item
            if kind!="move" or tuple(payload) not in sources:
                continue
            target=g.token_at(*payload)
            if target is None or target.owner==self.player:
                continue
            detail=self._candidate_meta.get((id(obj),tuple(payload)),{})
            p_win=float(detail.get("p_win",0.0) or 0.0)
            # A 65% floor keeps this an actual solution rather than a desperate
            # coin flip.  The old brain may still choose risky attacks normally
            # when no leader emergency is active.
            kill_floor={"easy":0.72,"medium":0.68,"hard":0.65}[self.difficulty]
            if p_win>=kill_floor:
                src=sources[tuple(payload)]
                threat_weight=float(src.get("p_kill",0.0) or 0.0)
                bonus=70.0+45.0*threat_weight+25.0*p_win
                neutralizers.append((score+bonus,kind,obj,payload,
                                     reason+f" [EMERGENCY KILL {p_win:.0%} +{bonus:.0f}]"))
        if neutralizers:
            return neutralizers

        # ESCAPE SECOND.  Find leader moves that actually change the forecast.
        # Prefer a genuinely safe result, then the minimum MOV cost required to
        # achieve it.  Among equally cheap escapes the original V3.4 score is
        # still sovereign.
        moves=[]
        for item in candidates:
            score,kind,obj,payload,reason=item
            if kind!="move" or obj is not leader:
                continue
            dest=tuple(payload)
            after=float(self._leader_threat_snapshot(g,dest).get("risk",0.0))
            path=g.find_path((leader.x,leader.y),dest,self.player)
            cost=len(path) if path is not None else 999
            improvement=risk-after
            if improvement>1e-9:
                moves.append((item,after,cost,improvement))

        if moves:
            # "Safe" is deliberately relative as well as absolute: if the
            # current forecast is extreme, cutting it below 35% of its old value
            # is enough to count, while <=10% always counts as safe.
            safe_abs={"easy":0.16,"medium":0.12,"hard":0.10}[self.difficulty]
            safe_ratio={"easy":0.45,"medium":0.40,"hard":0.35}[self.difficulty]
            safe=[m for m in moves if m[1]<=safe_abs or m[1]<=risk*safe_ratio]
            pool=safe if safe else moves
            if safe:
                min_cost=min(m[2] for m in pool)
                pool=[m for m in pool if m[2]==min_cost]
            else:
                # No complete escape exists: maximize actual risk reduction;
                # only then prefer the cheapest way to obtain it.
                best=max(m[3] for m in pool)
                pool=[m for m in pool if m[3]>=best-0.02]
                min_cost=min(m[2] for m in pool)
                pool=[m for m in pool if m[2]==min_cost]

            gated=[]
            for item,after,cost,improvement in pool:
                score,kind,obj,payload,reason=item
                # Small deterministic credit; the important behavior comes from
                # gating, not score inflation.  Once this action makes us safe,
                # the next step returns to ordinary V3.4 scoring.
                bonus=18.0+30.0*improvement
                gated.append((score+bonus,kind,obj,payload,
                              reason+f" [EMERGENCY ESCAPE risk {risk:.0%}->{after:.0%}, MOV {cost}]"))
            return gated

        # If there is literally no leader move that improves the forecast and no
        # credible immediate kill, do not fabricate a response.  Fall back to
        # the old candidate set; this is a genuinely trapped/exceptional state.
        return candidates

    def _token_candidates(self,g):
        out=[]
        self._candidate_meta={}

        for token in list(g.tokens):
            if token.owner!=self.player:
                continue
            if token.vehicle and not token.people:
                continue

            for dest in g.reachable_empty_tiles(token):
                score=self._score_empty_destination(g,token,dest)
                path=g.find_path((token.x,token.y),dest,self.player)
                cost=len(path) if path is not None else 99
                score-=cost*0.30

                reason=f"POSITION -> {dest}"
                if dest in self._active_harvests(g):
                    reason=f"COMPLETE HARVEST -> {dest}"
                elif dest in self._critical_enemy_harvests(g):
                    reason=f"BLOCK HARVEST -> {dest}"
                elif token.has_leader() and not token.vehicle:
                    reason=f"REPOSITION LEADER -> {dest}"

                out.append((score,"move",token,dest,reason))

            friendly,hostile=g.reachable_interaction_targets(token)

            for dest in hostile:
                target=g.token_at(*dest)
                base=g.bases.get(dest)

                if target is not None:
                    public_target=type("PublicEnemy",(),{"owner":target.owner})()
                    score,detail=self._attack_evaluation(g,token,public_target,dest)
                    reason=(
                        f"ATTACK {faction_name(target.owner)} -> {dest} "
                        f"[win {detail['p_win']:.0%}, tie {detail['p_tie']:.0%}, "
                        f"leader {detail['belief']['p_leader']:.0%}]"
                    )
                    self._candidate_meta[(id(token),tuple(dest))]=detail
                    out.append((score,"move",token,dest,reason))

                elif base is not None:
                    score,detail=self._base_attack_score(g,token,base,dest)
                    owner="NEUTRAL" if base.owner is None else faction_name(base.owner)
                    self._candidate_meta[(id(token),tuple(dest))]=detail
                    out.append((score,"move",token,dest,f"PRESS {owner} BASE -> {dest}"))

            for dest in friendly:
                target=g.token_at(*dest)
                if target is None:
                    # friendly base transfer
                    score=10
                    reason=f"FRIENDLY BASE -> {dest}"
                else:
                    score=self._friendly_interaction_score(g,token,target)
                    if token.vehicle and not target.vehicle:
                        label="LEADER" if target.has_leader() else "PAWN"
                        reason=f"VEHICLE PICKS UP {label} -> {dest}"
                    else:
                        reason=(f"HIDE LEADER IN VEHICLE -> {dest}"
                                if token.has_leader()
                                else f"BOARD VEHICLE -> {dest}")
                out.append((score,"move",token,dest,reason))

        return out

    def _container_candidates(self,g):
        out=[]
        containers=list(g.bases.values())+[t for t in g.tokens if t.vehicle]
        urgent=self._critical_enemy_harvests(g)

        for obj in containers:
            if getattr(obj,"owner",None)!=self.player:
                continue
            people=g.container_people(obj)
            if not people:
                continue

            for idx,person in enumerate(list(people)):
                if hasattr(g,"reachable_container_destinations"):
                    empty,friendly=g.reachable_container_destinations(obj,idx)
                else:
                    empty,friendly=set(),set()

                for dest in empty:
                    score=0.0
                    if dest in self._active_harvests(g):
                        score+=(90+g.harvest_marks[self.player]*28)*self._pw("harvest")
                    else:
                        before=self._nearest_objective_distance(g,(obj.x,obj.y))
                        after=self._nearest_objective_distance(g,dest)
                        score+=(before-after)*10
                    if dest in urgent:
                        score+=urgent[dest]*self._pw("harvest_block")

                    # Field-presence personality. This is deliberately modest:
                    # Italian Mafia is more willing to empty a base when doing so
                    # creates another mobile threat / movement-pool contributor.
                    # FBI is slightly less eager to strip base garrisons.
                    if not getattr(obj,"vehicle",False):
                        visible=sum(1 for t in g.tokens if t.owner==self.player)
                        if visible<g.unit_cap:
                            field_delta=(self._pw("field_presence")-1.0)
                            score+=42.0*field_delta
                            # Strongest when this deployment would leave a thin
                            # or empty base, precisely where personalities differ.
                            remaining=max(0,len(people)-1)
                            if remaining<=1:
                                score+=26.0*field_delta

                    if person.leader:
                        if getattr(obj,"vehicle",False): score-=88
                        score-=self._enemy_proximity_penalty(g,dest,True)

                    label="LEADER" if person.leader else (
                        "SABOTEUR" if getattr(person,"saboteur",False) else "PAWN"
                    )
                    out.append((score,"deploy",obj,(idx,dest),f"DEPLOY {label} -> {dest}"))

                for dest in friendly:
                    target=g.token_at(*dest)
                    if getattr(person,"saboteur",False) and target is not None:
                        continue
                    if target is not None and target.vehicle:
                        if person.leader:
                            if not target.people:
                                visible=sum(1 for t in g.tokens if t.owner==self.player)
                                cap_pressure=max(0,visible-(g.unit_cap-1))
                                score=-58+22*cap_pressure
                                reason=f"LEADER -> EMPTY VEHICLE -> {dest}"
                            else:
                                score=72*self._pw("concentration")
                                reason=f"LEADER JOINS LOADED VEHICLE -> {dest}"
                        else:
                            base_score=56 if not target.people else 31
                            score=base_score*self._pw("concentration")
                            reason=f"LOAD VEHICLE -> {dest}"
                    else:
                        score=14
                        reason=f"TRANSFER -> {dest}"

                    # Survival-with-teeth extension: before creating a loaded
                    # leader vehicle, price the public next-turn Saboteur risk.
                    # This is candidate-local consequence evaluation, not a
                    # global cowardice modifier and not a hard prohibition.
                    if target is not None and target.vehicle:
                        exposure,detail=self._projected_load_exposure(g,target,person)
                        if exposure>0:
                            score-=exposure
                            reason+=f" [CATASTROPHIC EXPOSURE -{exposure:.0f}]"
                    out.append((score,"deploy",obj,(idx,dest),reason))

        return out

    # ================================================================
    # REINFORCEMENT / TURN POLICY
    # ================================================================

    def _should_bank_block(self,g):
        urgent=self._critical_enemy_harvests(g)
        if not urgent or not g.action_taken:
            return None
        for t in g.tokens:
            if t.owner==self.player and (t.x,t.y) in urgent:
                return (t.x,t.y)
        return None

    def _own_pawn_count(self,g):
        total=0
        for b in g.controlled_bases(self.player):
            total+=b.regular_count()
        for t in g.tokens:
            if t.owner==self.player:
                total+=t.regular_count()
        total+=g.reserve[self.player]
        return total

    def _choose_mid_harvest(self,g):
        """Current harvest checkpoints, kept separate from combat/movement instinct."""
        p=self.player
        mode=getattr(g,"harvest_reward_mode","progressive")
        marks=g.harvest_marks[p]
        pawns=self._own_pawn_count(g)
        visible=g.visible_units(p)
        own_vehicles=(sum(1 for t in g.tokens if t.owner==p and t.vehicle)
                      + g.reserve_vehicles[p])
        can_recover_sab=(g.saboteur_lost[p]
                         and any(len(base.people)<4 for base in g.controlled_bases(p)))

        if mode=="clean_choice" and marks==2:
            if can_recover_sab:
                choice="saboteur"; reason="2 HARVESTS — RECOVER SABOTEUR"
            elif own_vehicles==0:
                choice="vehicle"; reason="2 HARVESTS — TAKE VEHICLE"
            elif pawns<=2:
                choice="cashout"; reason="2 HARVESTS — TAKE +1 PAWN"
            else:
                push_chance={0:0.58,1:0.64,2:0.69,3:0.70}.get(self.faction_id,0.64)
                if visible>=g.unit_cap-1: push_chance=min(0.88,push_chance+0.10)
                choice="push" if self.rng.random()<push_chance else "vehicle"
                reason="PUSH HARVEST TO 4" if choice=="push" else "2 HARVESTS — TAKE VEHICLE"
        elif mode=="ladder" and marks==3:
            if can_recover_sab:
                choice="saboteur"; reason="3 HARVESTS — RECOVER SABOTEUR"
            elif own_vehicles==0 and pawns>=3:
                choice="vehicle"; reason="3 HARVESTS — TAKE VEHICLE"
            else:
                push_chance=0.82 if pawns<=3 else 0.58
                if visible>=g.unit_cap-1: push_chance=max(0.42,push_chance-0.08)
                choice="push" if self.rng.random()<push_chance else "vehicle"
                reason="PUSH HARVEST 3→4 FOR +3 PAWNS" if choice=="push" else "3 HARVESTS — TAKE VEHICLE"
        else:
            target=3 if mode=="ladder" else 4
            if can_recover_sab or own_vehicles==0:
                choice="push"; reason=f"PUSH HARVEST TO {target} — specialist option needed"
            elif pawns<=2:
                choice="cashout"; reason="CASH OUT 2 HARVESTS — replenish pawn"
            else:
                chances={0:0.70,1:0.75,2:0.78,3:0.80} if mode=="ladder" else {0:0.66,1:0.72,2:0.76,3:0.78}
                push_chance=chances.get(self.faction_id,0.75 if mode=="ladder" else 0.72)
                if mode!="ladder" and visible>=g.unit_cap-1: push_chance=min(0.92,push_chance+0.12)
                choice="push" if self.rng.random()<push_chance else "cashout"
                reason=f"PUSH HARVEST TO {target}" if choice=="push" else "CASH OUT 2 HARVESTS"

        g.resolve_mid_harvest_choice(choice)
        self._announce(g,reason,115 if choice=="push" else 105)
        if g.end_turn_allowed():
            g.next_turn()

    def _choose_reinforcement(self,g):
        p=self.player

        if (g.saboteur_lost[p]
                and any(len(b.people)<4 for b in g.controlled_bases(p))):
            g.spawn_reinforcement("saboteur")
            self._announce(g,"RECOVER SABOTEUR",140)
            return

        own_vehicles=(
            sum(1 for t in g.tokens if t.owner==p and t.vehicle)
            + g.reserve_vehicles[p]
        )

        progressive=(getattr(g,"harvest_reward_mode","classic") in ("progressive","ladder","clean_choice"))
        full_cycles=(
            g.harvest_full_cycles[p]
            if hasattr(g,"harvest_full_cycles") else 0
        )

        # In the new rule the first +3 pawn reward is intentionally attractive.
        # Later cycles tilt more toward rebuilding/adding vehicles as pawn mass
        # becomes less scarce and the six-visible-unit cap starts to matter.
        if progressive and full_cycles<=1 and self._own_pawn_count(g)<=4:
            choice="pawns"
        else:
            vehicle_chance={
                0:0.58,  # FBI
                1:0.76,  # Russian Mafia
                2:0.56,  # Italian Mafia
                3:0.54,  # CIA
            }.get(p,0.65)

            if progressive and full_cycles>=2:
                vehicle_chance=min(0.90,vehicle_chance+0.14)

            choice=(
                "vehicle"
                if own_vehicles==0 and self.rng.random()<vehicle_chance
                else "pawns"
            )

        g.spawn_reinforcement(choice)
        pawn_n=3 if progressive else 2
        label=(f"+{pawn_n} PAWNS" if choice=="pawns" else "+1 VEHICLE")
        self._announce(g,f"REINFORCE {label}",100)

    # ================================================================
    # LOGGING
    # ================================================================

    def _ledger_snapshot(self,g):
        out={}
        for p in range(g.players):
            if p==self.player:
                continue
            view=g.observer_view(self.player)["current"]
            out[str(p+1)]={
                "material_rule_baseline":dict(self._material[p]),
                "participant_known_losses":dict(self._known_losses[p]),
                "remaining_rule_upper_bound":self._remaining_material(p),
                "visible_unknown_tokens":len(view["outside"].get(p,[])),
                "bases":sum(1 for owner in view["base_owners"].values() if owner==p),
                "corner_bases":self._owned_corner_count(g,p),
                "alive":g.alive[p],
            }
        return out

    def _belief_inference_trace(self,g,p,pos,b):
        """Human-auditable explanation using SAFE-VIEW evidence only."""
        ev=dict(self._evidence.get((p,pos),{}))
        rem=self._remaining_material(p)
        impossible=[atk for atk in range(6) if b["atk_probs"].get(atk,0.0)<=1e-12]
        trace={
            "public_fight_evidence":ev,
            "remaining_material_upper_bound":dict(rem),
            "zero_probability_atk":impossible,
            "method":"global material constraints + SAFE-VIEW legal-transition constraints + fight likelihoods",
        }
        tc=self._transition_constraints.get((p,pos))
        if tc:
            trace["legal_transition_constraint"]=dict(tc)
        hist=self._public_intel_history.get(p,[])
        if hist:
            last=hist[-1]
            trace["latest_public_transition"]={
                "global_turn":last.get("global_turn"),
                "inferred_mov_budget":last.get("inferred_budget"),
                "start":last.get("start"),
                "end":last.get("end"),
            }
        if ev.get("initiated_fight") and ev.get("fight_wins"):
            trace["behavioural_read"]=(
                "initiated+won makes lone-pawn/empty-vehicle hypotheses rare, "
                "not impossible; ATK2+ becomes more plausible"
            )
        return trace

    def _serialize_beliefs(self,g):
        raw=self._all_beliefs(g)
        out={}
        for p,by_pos in raw.items():
            p_out={}
            for pos,b in by_pos.items():
                p_out[f"{pos[0]},{pos[1]}"]={
                    "expected_atk":round(b["expected_atk"],4),
                    "atk_probs":{str(k):round(v,5) for k,v in b["atk_probs"].items()},
                    "leader_probability":round(b["p_leader"],5),
                    "saboteur_probability":round(b["p_saboteur"],5),
                    "vehicle_probability":round(b["p_vehicle"],5),
                    "occupied_vehicle_probability":round(b["p_occupied_vehicle"],5),
                    "empty_vehicle_probability":round(b["p_empty_vehicle"],5),
                    "top_hypotheses":[
                        {"state":name,"p":round(prob,5),"atk":atk}
                        for name,prob,atk,_ in b["states"][:6]
                    ],
                    "stationary_age":self._stationary.get((p,pos),0),
                    "evidence":dict(self._evidence.get((p,pos),{})),
                    "inference_trace":self._belief_inference_trace(g,p,pos,b),
                }
            out[str(p+1)]=p_out
        return out

    def _prepare_candidate_log(self,g,candidates):
        ranked=sorted(candidates,key=lambda x:x[0],reverse=True)[:12]
        rows=[]
        for score,kind,obj,payload,reason in ranked:
            row={
                "score":round(score,3),
                "kind":kind,
                "reason":reason,
            }
            if kind=="move":
                row["from"]=[getattr(obj,"x",None),getattr(obj,"y",None)]
                row["to"]=list(payload)

                if getattr(obj,"vehicle",False) and getattr(obj,"people",None):
                    _penalty,_risk=self._vehicle_destination_risk(g,obj,tuple(payload))
                    row["vehicle_saboteur_risk"]={
                        "p_reachable_saboteur":round(_risk.get("saboteur_threat",0.0),5),
                        "penalty":round(_risk.get("penalty",0.0),3),
                        "contains_leader":bool(_risk.get("contains_leader",False)),
                        "cargo_pawns":int(_risk.get("cargo_pawns",0)),
                    }

                meta=self._candidate_meta.get((id(obj),tuple(payload)))
                if meta:
                    # Field-combat candidates and base-assault candidates share
                    # the same metadata table, but their schemas are different.
                    # Log each defensively instead of assuming combat-only keys.
                    if "belief" in meta and "p_leader_kill" in meta:
                        row["combat_probability"]={
                            "p_win":round(meta.get("p_win",0.0),5),
                            "p_tie":round(meta.get("p_tie",0.0),5),
                            "p_loss":round(meta.get("p_loss",0.0),5),
                            "p_leader_kill":round(meta.get("p_leader_kill",0.0),5),
                            "target_expected_atk":round(
                                meta.get("belief",{}).get("expected_atk",0.0),5
                            ),
                        }
                    elif "post_capture_exposure" in meta:
                        row["base_assault_probability"]={
                            "p_win":round(meta.get("p_win",0.0),5),
                            "p_tie":round(meta.get("p_tie",0.0),5),
                            "p_loss":round(meta.get("p_loss",0.0),5),
                            "own_atk":meta.get("own_atk"),
                            "owner":meta.get("owner"),
                        }

                    if meta.get("vehicle_attack_reveals"):
                        rr=meta.get("post_attack_reveal_risk",{})
                        row["vehicle_revelation_risk"]={
                            "reveals_vehicle":True,
                            "p_reachable_defender_saboteur":round(
                                rr.get("p_reachable_defender_saboteur",0.0),5
                            ),
                            "penalty":round(rr.get("penalty",0.0),3),
                        }

                    if meta.get("post_capture_exposure",{}).get("applies"):
                        pc=meta["post_capture_exposure"]
                        row["post_capture_exposure"]={
                            "approach":pc.get("approach"),
                            "post_strength":pc.get("post_strength"),
                            "post_vehicle":pc.get("post_vehicle",False),
                            "p_lethal_counter":round(
                                pc.get("p_lethal_counter",0.0),5
                            ),
                            "p_saboteur_counter":round(
                                pc.get("p_saboteur_counter",0.0),5
                            ),
                            "penalty":round(pc.get("penalty",0.0),3),
                        }
            rows.append(row)
        self._last_candidate_log=rows

    def _announce(self,g,reason,score):
        self.last_reason=reason
        entry={
            "turn":g.turn,
            "player":self.player,
            "faction":faction_name(self.player),
            "personality":dict(self.personality),
            "reason":reason,
            "score":round(float(score),3),
            "ledger":self._ledger_snapshot(g),
            "beliefs":self._serialize_beliefs(g),
            "top_candidates":self._last_candidate_log,
        }
        if hasattr(g,"ai_log"):
            g.ai_log.append(entry)
        try:
            g.log_event("bot_decision",reason=reason,score=round(score,2),
                        bot_version=BOT_VERSION)
        except Exception:
            pass
        print(f"[BasicBot {BOT_VERSION} P{self.player+1}] {reason} | {score:.1f}")

    # ================================================================
    # STEP
    # ================================================================

    def step(self,g):
        if g.current!=self.player or g.winner is not None or g.draw:
            self.end_after_combat=False
            return "idle"

        self._process_new_events(g)
        self._update_leader_memory(g)
        self._last_candidate_log=[]

        # Modern Mini can pause an attempted end-turn to resolve a harvest
        # checkpoint/reinforcement.  These blockers must take priority over the
        # transplanted V3.4.1 end-after-combat state; otherwise the old brain can
        # repeatedly request END TURN while the modern rules correctly refuse it.
        if getattr(g,"harvest_mid_offer",[False]*g.players)[self.player]:
            self._choose_mid_harvest(g)
            return "harvest_decision"

        if g.reinforcement_credits[self.player]>0 and g.controlled_bases(self.player):
            self._choose_reinforcement(g)
            return "reinforcement"

        if self.end_after_combat:
            self.end_after_combat=False
            if g.end_turn_allowed():
                self._announce(g,"END TURN AFTER COMBAT",0)
                g.next_turn()
                return "end"
            # Do not consume the combat-end request if a modern rule temporarily
            # blocks the transition.  Continue into normal action resolution.

        for t in g.tokens:
            if (t.owner==self.player
                    and (t.x,t.y) in self._active_harvests(g)
                    and g.action_taken):
                self._announce(g,f"BANK HARVEST {(t.x,t.y)}",130)
                g.next_turn()
                return "end"

        block=self._should_bank_block(g)
        if block is not None:
            self._announce(g,f"HOLD HARVEST BLOCK {block}",115)
            g.next_turn()
            return "end"

        if g.move_left<=0:
            if g.action_taken:
                # Normally legal. If modern reward bookkeeping is blocking the
                # transition, resolve it on the next bot step instead of spamming
                # END TURN forever.
                if not g.end_turn_allowed():
                    if getattr(g,"harvest_mid_offer",[False]*g.players)[self.player]:
                        self._choose_mid_harvest(g)
                        return "harvest_decision"
                    if g.reinforcement_credits[self.player]>0 and g.controlled_bases(self.player):
                        self._choose_reinforcement(g)
                        return "reinforcement"
                    self._announce(g,"TURN BLOCKED — modern rule state",0)
                    return "idle"
                self._announce(g,"END TURN",0)
                g.next_turn()
                return "end"
            return "idle"

        candidates=self._token_candidates(g)+self._container_candidates(g)
        candidates=self._apply_survival_with_teeth(g,candidates)
        self._prepare_candidate_log(g,candidates)

        if not candidates:
            if g.action_taken:
                self._announce(g,"END TURN — no useful action",0)
                g.next_turn()
                return "end"
            # minimal legal fallback
            for token in g.tokens:
                if token.owner!=self.player:
                    continue
                spots=list(g.reachable_empty_tiles(token))
                if spots:
                    dest=self.rng.choice(spots)
                    self._announce(g,f"FALLBACK MOVE -> {dest}",0)
                    g.try_move_or_interact(token,*dest)
                    return "action"
            return "idle"

        scored=[]
        for item in candidates:
            # V3.6 donor behavior: tiny noise only. Strategy dominates; this is
            # not an opening-randomizer or a second decision layer.
            scored.append((item[0]+self.rng.uniform(-1.5,1.5),item))
        scored.sort(key=lambda x:x[0],reverse=True)
        score,item=scored[0]
        _,kind,obj,payload,reason=item

        if g.action_taken and score<7:
            self._announce(g,"END TURN — preserve position",score)
            g.next_turn()
            return "end"

        before_fights=len(g.observer_view(self.player).get("fights",[]))
        if kind=="move":
            g.try_move_or_interact(obj,*payload)
        else:
            idx,dest=payload
            g.deploy_selected_person(obj,idx,*dest)

        self._announce(g,reason,score)

        after_fights=len(g.observer_view(self.player).get("fights",[]))
        if after_fights>before_fights and g.winner is None and not g.draw:
            self.end_after_combat=True
            return "combat"

        return "action"
