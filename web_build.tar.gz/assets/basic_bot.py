"""GDG Mini BasicBot V3.6.4 — Saboteur destroys enemy Vehicles.

This bot is intentionally INFORMATION-HONEST.

It never reads an enemy token's hidden vehicle flag, occupants, strength,
leader status, or Saboteur status when making strategic decisions.

Instead it:
- keeps a public material ledger for every opponent,
- subtracts only casualties it was entitled to learn,
- records public reinforcements and vehicle captures,
- enumerates legal hidden compositions for every visible enemy circle,
- produces marginal probabilities (leader / Saboteur / vehicle / ATK),
- uses those probabilities for risk-aware combat choices,
- writes detailed reasoning to g.ai_log for post-match study.

Non-participant combats provide only participants, location, and winner.
"""

import random
from collections import defaultdict

BOT_VERSION="V3.6.4-SABOTEUR-VEHICLE-DESTRUCTION"

FACTION_NAMES=["FBI","RUSSIAN MAFIA","ITALIAN MAFIA","CIA"]

# Same rational core for every faction. These are intentionally MICRO biases,
# mostly +/- 10–20%, so personality changes preference rather than competence.
FACTION_PERSONALITIES={
    # NW / blue — cautious territorial controller.
    0:{
        "name":"FBI",
        "risk_tolerance":0.86,
        "leader_safety":1.18,
        "leader_kill_reward":0.92,
        "base_control":1.18,
        "harvest":0.94,
        "harvest_block":1.00,
        "center":0.96,
        "concentration":0.96,
        "field_presence":0.92,
    },

    # NE / amber — likes concentrated force, but Saboteur safety remains sacred.
    1:{
        "name":"RUSSIAN MAFIA",
        "risk_tolerance":0.98,
        "leader_safety":1.04,
        "leader_kill_reward":1.04,
        "base_control":0.98,
        "harvest":0.94,
        "harvest_block":0.98,
        "center":1.00,
        "concentration":1.18,
        "field_presence":0.94,
    },

    # SE / magenta — opportunistic, harder to read, more willing to empty bases
    # when that creates useful independent threats or an immediate attack.
    2:{
        "name":"ITALIAN MAFIA",
        "risk_tolerance":1.16,
        "leader_safety":0.92,
        "leader_kill_reward":1.18,
        "base_control":0.92,
        "harvest":0.98,
        "harvest_block":0.98,
        "center":1.00,
        "concentration":0.98,
        "field_presence":1.18,
    },

    # SW / green — objective/denial specialist.
    3:{
        "name":"CIA",
        "risk_tolerance":0.96,
        "leader_safety":1.02,
        "leader_kill_reward":1.00,
        "base_control":1.00,
        "harvest":1.20,
        "harvest_block":1.18,
        "center":1.16,
        "concentration":1.00,
        "field_presence":1.00,
    },
}

def faction_name(p):
    return "NEUTRAL" if p is None else FACTION_NAMES[p]


class BasicBot:
    def __init__(self, player=1, seed=None, faction_id=None):
        # player = live game seat / owner id.
        # faction_id = personality identity. Keeping these separate lets
        # reduced-player BotLab matches sample any faction into any active seat.
        self.player=player
        self.faction_id=player if faction_id is None else int(faction_id)
        self.rng=random.Random(seed)
        self.personality=dict(FACTION_PERSONALITIES.get(
            self.faction_id,FACTION_PERSONALITIES[0]
        ))
        self.last_reason=""
        self.end_after_combat=False

        self._initialized=False
        self._log_index=0
        self._material={}
        self._known_losses={}
        self._stationary={}
        self._previous_positions={}
        self._evidence=defaultdict(dict)
        self._base_evidence=defaultdict(dict)
        self._belief_cache_key=None
        self._belief_cache={}
        self._candidate_meta={}

        # Per-state cache for expensive last-base threat analysis.
        # Keyed by public game-state counters that change whenever a new action/
        # turn can invalidate the result.
        self._base_survival_cache={}
        self._last_candidate_log=[]

        # Own leader memory is private information and therefore fair.
        self._last_memory_turn=None
        self._leader_last_pos=None
        self._leader_stationary_turns=0
        self._leader_exposed_turns=0

    @staticmethod
    def _manhattan(a,b):
        return abs(a[0]-b[0])+abs(a[1]-b[1])

    def _pw(self,key):
        """Faction personality weight, defaulting to neutral 1.0."""
        return float(self.personality.get(key,1.0))

    # ================================================================
    # PUBLIC INFORMATION LEDGER
    # ================================================================

    def _ensure_initialized(self,g):
        if self._initialized:
            return
        self._initialized=True
        for p in range(g.players):
            self._material[p]={
                "pawns":int(g.starting_pawns),
                "leader":1,
                "saboteur":1,
                "vehicles":1 if g.starting_vehicle else 0,
            }
            self._known_losses[p]={
                "pawns":0,"leader":0,"saboteur":0,"vehicles":0
            }
            self._previous_positions[p]=set()
        self._observe_public_board(g)

    def _observe_public_board(self,g):
        """Only owner+coordinates are read for enemies."""
        for p in range(g.players):
            if p==self.player:
                continue
            current={(t.x,t.y) for t in g.tokens if t.owner==p}
            old=self._previous_positions.get(p,set())
            new_age={}
            for pos in current:
                key=(p,pos)
                age=self._stationary.get(key,0)+1 if pos in old else 0
                new_age[key]=age
            # Drop stale position evidence. Identity is NOT magically tracked
            # through unseen movement.
            for key in [k for k in self._stationary if k[0]==p]:
                self._stationary.pop(key,None)
            self._stationary.update(new_age)
            self._previous_positions[p]=current

            # Evidence attached to a square only survives while that opponent
            # still visibly occupies the square.
            for key in list(self._evidence):
                op,pos=key
                if op==p and pos not in current:
                    del self._evidence[key]

    @staticmethod
    def _loss_key(kind):
        return {
            "pawn":"pawns","leader":"leader",
            "saboteur":"saboteur","vehicle":"vehicles"
        }.get(kind)

    def _apply_known_losses(self,owner,kinds):
        if owner is None or owner==self.player:
            return
        for kind in kinds:
            key=self._loss_key(kind)
            if key:
                self._known_losses[owner][key]+=1

    def _process_new_events(self,g):
        """Consume only the information this bot is entitled to know."""
        self._ensure_initialized(g)

        for ev in g.log[self._log_index:]:
            kind=ev.get("kind")
            actor=ev.get("player")

            if kind=="reinforcement" and actor is not None:
                r=ev.get("reinforcement_type")
                if r=="2_pawns":
                    self._material[actor]["pawns"]+=2
                elif r=="vehicle":
                    self._material[actor]["vehicles"]+=1
                elif r=="recover_saboteur":
                    # Unique piece: recovery cancels one known death if we knew it.
                    self._known_losses[actor]["saboteur"]=max(
                        0,self._known_losses[actor]["saboteur"]-1
                    )

            elif kind=="vehicle_captured":
                old=ev.get("from_player")
                if old is not None and actor is not None and old!=actor:
                    # Ownership transfer is public on the resulting board.
                    self._material[old]["vehicles"]=max(
                        0,self._material[old]["vehicles"]-1
                    )
                    self._material[actor]["vehicles"]+=1

            elif kind=="leader_killed":
                victim=ev.get("victim")
                if victim is not None:
                    self._known_losses[victim]["leader"]=1

            elif kind=="base_captured":
                pos=ev.get("base")
                capturer=actor
                previous=ev.get("previous_owner")
                if pos is not None and capturer is not None:
                    key=tuple(pos)
                    e=self._base_evidence[key]
                    e["owner"]=capturer
                    e["captured_turn"]=ev.get("turn",g.turn)
                    e["previous_owner"]=previous
                    if previous is not None and previous!=capturer:
                        e["likely_occupied"]=0.82
                        e["likely_def_ge_2"]=0.72
                    else:
                        e["likely_occupied"]=0.68
                        e["likely_def_ge_2"]=0.55

            elif kind=="combat_result":
                pub=ev.get("public",{})
                attacker=pub.get("attacker")
                defender=pub.get("defender")
                winner=pub.get("winner")
                loc=pub.get("location")
                is_base=bool(pub.get("base"))
                private_for=ev.get("private_for",[])

                # Everybody may remember that a surviving FIELD token just won
                # at this square. This is soft evidence, not composition reveal.
                if (not is_base and winner is not None and loc is not None):
                    pos=tuple(loc)
                    evidence=self._evidence[(winner,pos)]
                    evidence["fight_wins"]=evidence.get("fight_wins",0)+1
                    if winner==attacker:
                        evidence["initiated_fight"]=evidence.get("initiated_fight",0)+1

                # Only participants receive ATK/DEF and casualty details.
                if self.player in private_for:
                    private=ev.get("private",{})
                    losses=private.get("losses",[])
                    for owner,kinds in losses:
                        self._apply_known_losses(owner,kinds)

                    # If an enemy survived this field fight, we can derive its
                    # post-combat ATK from the values/casualties we personally saw.
                    if (not is_base and winner is not None and winner!=self.player
                            and loc is not None):
                        initial=(private.get("atk") if winner==attacker
                                 else private.get("def"))
                        if initial is not None:
                            winner_losses=[]
                            for owner,kinds in losses:
                                if owner==winner:
                                    winner_losses.extend(kinds)
                            final_atk=initial
                            final_atk-=winner_losses.count("pawn")
                            final_atk-=2*winner_losses.count("leader")
                            self._evidence[(winner,tuple(loc))]["exact_atk"]=max(0,final_atk)

        self._log_index=len(g.log)
        self._observe_public_board(g)
        self._belief_cache_key=None

    def _remaining_material(self,p):
        total=self._material[p]
        lost=self._known_losses[p]
        return {
            "pawns":max(0,total["pawns"]-lost["pawns"]),
            "leader":max(0,total["leader"]-lost["leader"]),
            "saboteur":max(0,total["saboteur"]-lost["saboteur"]),
            "vehicles":max(0,total["vehicles"]-lost["vehicles"]),
        }

    # ================================================================
    # HIDDEN-STATE ENUMERATION
    # ================================================================

    def _possible_states(self,remaining):
        """All legal compositions ONE generic enemy circle could represent."""
        states=[]

        def add(name,atk,p=0,l=0,s=0,v=0,vehicle=False,occupied=False):
            states.append({
                "name":name,"atk":atk,
                "pawns":p,"leader":l,"saboteur":s,"vehicles":v,
                "vehicle":vehicle,"occupied_vehicle":occupied,
            })

        if remaining["pawns"]>0:
            add("pawn",1,p=1)
        if remaining["leader"]>0:
            add("leader",2,l=1)
        if remaining["saboteur"]>0:
            add("saboteur",0,s=1)

        if remaining["vehicles"]>0:
            add("empty_vehicle",0,v=1,vehicle=True,occupied=False)

            # Vehicle occupants: pawns and optionally leader, never Saboteur.
            for pawns in range(1,min(4,remaining["pawns"])+1):
                add(f"vehicle_{pawns}p",pawns,p=pawns,v=1,
                    vehicle=True,occupied=True)

            if remaining["leader"]>0:
                add("vehicle_L",2,l=1,v=1,vehicle=True,occupied=True)
                for pawns in range(1,min(3,remaining["pawns"])+1):
                    add(f"vehicle_L{pawns}p",2+pawns,p=pawns,l=1,v=1,
                        vehicle=True,occupied=True)

        return states

    def _state_weight(self,p,pos,state):
        """Soft behavioural evidence. Never turns a guess into certainty."""
        w=1.0
        evidence=self._evidence.get((p,pos),{})
        stationary=self._stationary.get((p,pos),0)

        exact=evidence.get("exact_atk")
        if exact is not None and state["atk"]!=exact:
            return 0.0

        wins=evidence.get("fight_wins",0)
        if wins:
            if state["name"]=="empty_vehicle":
                w*=0.015**wins
            elif state["name"]=="saboteur":
                # A Saboteur can win by striking a vehicle, so never impossible.
                w*=0.20**wins
            elif state["name"]=="pawn":
                # Pawn can have killed a Saboteur; possible but less likely.
                w*=0.60**wins
            elif state["occupied_vehicle"]:
                w*=1.35**wins
            else:
                w*=1.08**wins

        if evidence.get("initiated_fight",0):
            n=evidence["initiated_fight"]
            if state["name"]=="empty_vehicle":
                w*=0.02**n
            elif state["name"]=="saboteur":
                w*=0.45**n
            elif state["name"]=="pawn":
                w*=0.72**n
            elif state["occupied_vehicle"]:
                w*=1.18**n

        # Long inactivity is compatible with many plans, so this is deliberately
        # weak. It merely raises the empty-vehicle bluff hypothesis over time.
        if stationary>=2 and state["name"]=="empty_vehicle":
            w*=min(3.0,1.0+0.28*stationary)

        return w

    @staticmethod
    def _usage(state):
        return (
            state["pawns"],state["leader"],
            state["saboteur"],state["vehicles"]
        )

    @staticmethod
    def _fits(usage,limit):
        return all(a<=b for a,b in zip(usage,limit))

    def _beliefs_for_player(self,g,p):
        positions=sorted((t.x,t.y) for t in g.tokens if t.owner==p)
        remaining=self._remaining_material(p)
        limit=(remaining["pawns"],remaining["leader"],
               remaining["saboteur"],remaining["vehicles"])

        if not positions:
            return {}

        states=self._possible_states(remaining)
        weighted=[]
        for pos in positions:
            opts=[]
            for st in states:
                w=self._state_weight(p,pos,st)
                if w>0 and self._fits(self._usage(st),limit):
                    opts.append((st,w))
            weighted.append(opts)

        # Forward dynamic program over resource usage.
        forward=[{(0,0,0,0):1.0}]
        for opts in weighted:
            nxt=defaultdict(float)
            for used,base_w in forward[-1].items():
                for st,w in opts:
                    u=self._usage(st)
                    nu=tuple(used[i]+u[i] for i in range(4))
                    if self._fits(nu,limit):
                        nxt[nu]+=base_w*w
            forward.append(dict(nxt))

        # Backward DP.
        n=len(positions)
        backward=[None]*(n+1)
        backward[n]={(0,0,0,0):1.0}
        for i in range(n-1,-1,-1):
            cur=defaultdict(float)
            for st,w in weighted[i]:
                u=self._usage(st)
                for post,post_w in backward[i+1].items():
                    nu=tuple(u[j]+post[j] for j in range(4))
                    if self._fits(nu,limit):
                        cur[nu]+=w*post_w
            backward[i]=dict(cur)

        # Leader cannot be hidden in a base/reserve: if the opponent is alive,
        # exactly one visible circle must account for the living leader.
        required_leader=1 if g.alive[p] and remaining["leader"]>0 else 0

        def final_ok(used):
            return used[1]==required_leader

        total=sum(w for used,w in forward[n].items() if final_ok(used))

        # Defensive fallback if public-known bookkeeping becomes inconsistent.
        if total<=0:
            result={}
            for pos,opts in zip(positions,weighted):
                z=sum(w for _,w in opts) or 1.0
                result[pos]=self._summarize_state_probs(
                    [(st,w/z) for st,w in opts]
                )
            return result

        results={}
        for i,pos in enumerate(positions):
            state_mass=defaultdict(float)
            for st,sw in weighted[i]:
                su=self._usage(st)
                mass=0.0
                for pre,pw in forward[i].items():
                    base=tuple(pre[j]+su[j] for j in range(4))
                    if not self._fits(base,limit):
                        continue
                    for post,qw in backward[i+1].items():
                        final=tuple(base[j]+post[j] for j in range(4))
                        if self._fits(final,limit) and final_ok(final):
                            mass+=pw*sw*qw
                if mass:
                    state_mass[st["name"]]+=mass

            # map state names back to state objects
            probs=[]
            by_name={st["name"]:st for st in states}
            z=sum(state_mass.values()) or 1.0
            for name,mass in state_mass.items():
                probs.append((by_name[name],mass/z))
            results[pos]=self._summarize_state_probs(probs)

        return results

    def _summarize_state_probs(self,probs):
        atk=defaultdict(float)
        p_leader=p_sab=p_vehicle=p_occ=p_empty=0.0
        detailed=[]
        expected=0.0

        for st,prob in probs:
            atk[int(st["atk"])]+=prob
            expected+=st["atk"]*prob
            if st["leader"]: p_leader+=prob
            if st["saboteur"]: p_sab+=prob
            if st["vehicle"]: p_vehicle+=prob
            if st["occupied_vehicle"]: p_occ+=prob
            if st["name"]=="empty_vehicle": p_empty+=prob
            detailed.append((st["name"],prob,st["atk"],bool(st["leader"])))

        detailed.sort(key=lambda x:x[1],reverse=True)
        return {
            "expected_atk":expected,
            "atk_probs":dict(sorted(atk.items())),
            "p_leader":p_leader,
            "p_saboteur":p_sab,
            "p_vehicle":p_vehicle,
            "p_occupied_vehicle":p_occ,
            "p_empty_vehicle":p_empty,
            "states":detailed,
        }

    def _all_beliefs(self,g):
        key=(
            g.turn,len(g.log),
            tuple(sorted((t.owner,t.x,t.y) for t in g.tokens if t.owner!=self.player))
        )
        if key==self._belief_cache_key:
            return self._belief_cache

        result={}
        for p in range(g.players):
            if p==self.player or not g.alive[p]:
                continue
            result[p]=self._beliefs_for_player(g,p)

        self._belief_cache_key=key
        self._belief_cache=result
        return result

    def _belief_for(self,g,owner,pos):
        return self._all_beliefs(g).get(owner,{}).get(tuple(pos),{
            "expected_atk":1.5,
            "atk_probs":{0:0.15,1:0.35,2:0.30,3:0.15,4:0.05},
            "p_leader":0.20,
            "p_saboteur":0.20,
            "p_vehicle":0.30,
            "p_occupied_vehicle":0.22,
            "p_empty_vehicle":0.08,
            "states":[],
        })

    # ================================================================
    # STRATEGIC HELPERS
    # ================================================================

    def _active_harvests(self,g,player=None):
        p=self.player if player is None else player
        return [h for h in g.harvest_tiles if g.harvest_active[p].get(h,False)]

    def _owned_corner_count(self,g,player):
        m=g.grid-1
        corners=[(0,0),(m,0),(m,m),(0,m)]
        return sum(1 for pos in corners if g.bases[pos].owner==player)

    def _last_base_rule(self,g):
        return bool(getattr(g,"lose_last_base",False))

    def _base_survival_cache_key(self,g,p):
        """Cheap key that changes whenever tactical state can meaningfully change."""
        return (
            p,
            getattr(g,"turn",None),
            getattr(g,"global_turn",None),
            getattr(g,"current",None),
            getattr(g,"move_left",None),
            len(getattr(g,"log",[])),
            tuple(bool(x) for x in getattr(g,"alive",[])),
        )

    def _sole_base_status(self,g,player=None):
        p=self.player if player is None else player
        key=self._base_survival_cache_key(g,p)

        cached=self._base_survival_cache.get(key)
        if cached is not None:
            return cached

        result=self._sole_base_status_uncached(g,p)

        # Keep cache tiny: only current/recent states matter.
        if len(self._base_survival_cache)>24:
            self._base_survival_cache.clear()
        self._base_survival_cache[key]=result
        return result

    def _sole_base_status_uncached(self,g,player=None):
        """Estimate danger to our sole base using only public enemy information."""
        p=self.player if player is None else player
        info={
            "applies":False,"base":None,"defense":0,
            "danger":0.0,"near_danger":0.0,"sources":[]
        }

        if not self._last_base_rule(g) or not g.alive[p]:
            return info

        owned=list(g.controlled_bases(p))
        if len(owned)!=1:
            return info

        base=owned[0]
        pos=(base.x,base.y)
        defense=base.defense() if p==self.player else 1

        total_survival=1.0
        total_near_survival=1.0
        sources=[]

        if p==self.player:
            beliefs=self._all_beliefs(g)
            for enemy,by_pos in beliefs.items():
                if enemy==p or not g.alive[enemy]:
                    continue
                budget=self._public_enemy_move_budget(g,enemy)

                for epos,b in by_pos.items():
                    dist=self._manhattan(epos,pos)
                    probs=b.get("atk_probs",{})

                    if getattr(g,"draw_winner","defender")=="attacker":
                        p_take=sum(prob for atk,prob in probs.items()
                                   if atk>=defense)
                    else:
                        p_take=sum(prob for atk,prob in probs.items()
                                   if atk>defense)

                    if p_take<=0:
                        continue

                    q=0.0
                    if dist<=budget:
                        reach=1.0 if dist<=max(1,budget-1) else 0.72
                        q=max(0.0,min(1.0,p_take*reach))
                        total_survival*=1.0-q

                    near_q=0.0
                    if dist<=budget+max(2,g.base_move):
                        near_q=(max(q,p_take*0.72)
                                if dist<=budget else p_take*0.32)
                        near_q=max(0.0,min(1.0,near_q))
                        total_near_survival*=1.0-near_q

                    if q>0 or near_q>0:
                        sources.append({
                            "player":enemy,
                            "pos":[epos[0],epos[1]],
                            "distance":dist,
                            "move_budget":budget,
                            "p_take":round(p_take,5),
                            "immediate":round(q,5),
                            "near":round(near_q,5),
                        })

        info.update({
            "applies":True,
            "base":pos,
            "defense":defense,
            "danger":1.0-total_survival,
            "near_danger":1.0-total_near_survival,
            "sources":sources,
        })
        return info

    def _base_survival_priority(self,g):
        """Urgency of escaping/protecting a one-base existential state."""
        s=self._sole_base_status(g,self.player)
        if not s["applies"]:
            return 0.0,s

        # A second base always has insurance value. Tactical danger raises this
        # sharply, but does not hard-script the bot.
        urgency=0.24 + 0.76*max(s["danger"],0.60*s["near_danger"])
        return max(0.0,min(1.0,urgency)),s

    def _opponent_threat(self,g,player):
        if player==self.player or not g.alive[player]:
            return 0.0
        score=0.0
        score+=g.harvest_marks[player]*15
        bases=len(g.controlled_bases(player))
        score+=bases*9
        score+=self._owned_corner_count(g,player)*14
        if self._last_base_rule(g) and bases==1:
            score+=28
        score+=g.reinforcement_credits[player]*20
        if g.harvest_marks[player]>=3: score+=28
        if self._owned_corner_count(g,player)>=3: score+=85
        return score

    def _critical_enemy_harvests(self,g):
        urgent={}
        for p in range(g.players):
            if p==self.player or not g.alive[p]:
                continue
            if g.harvest_marks[p]<3:
                continue
            for h in self._active_harvests(g,p):
                urgent[h]=max(urgent.get(h,0),55+self._opponent_threat(g,p))
        return urgent

    def _nearest_objective_distance(self,g,pos):
        goals=list(self._active_harvests(g))
        goals += [p for p,b in g.bases.items() if b.owner is None]

        # Defend the territorial clock.
        if self._owned_corner_count(g,self.player)<4:
            m=g.grid-1
            corners=[(0,0),(m,0),(m,m),(0,m)]
            for enemy in range(g.players):
                if enemy==self.player or not g.alive[enemy]:
                    continue
                if self._owned_corner_count(g,enemy)>=3:
                    goals += [c for c in corners if g.bases[c].owner!=enemy]

        return min((self._manhattan(pos,h) for h in goals),default=0)

    def _starting_visible_baseline(self,g):
        return 1 + (1 if getattr(g,"starting_vehicle",True) else 0)

    def _corner_position(self,g,p):
        m=g.grid-1
        for pos in ((0,0),(m,0),(m,m),(0,m)):
            b=g.bases.get(pos)
            if b is not None and b.owner==p:
                return pos
        return None

    def _opening_leader_harvest_penalty(self,g,token,dest):
        """Early harvest rushes by an exposed leader are conditional, not default.

        At the very start, information is unusually clean. A neighboring faction
        showing MORE field units than its normal leader+vehicle baseline has
        publicly mobilized material. That is a red flag for sending a naked
        leader deep onto a harvest tile.

        No hidden composition is read here.
        """
        if (
            getattr(g,"global_turn",99)>2
            or token.vehicle
            or not token.has_leader()
            or dest not in self._active_harvests(g)
        ):
            return 0.0

        # Opening player gets the initiative before anyone has shown a plan.
        if getattr(g,"global_turn",1)==1 and self.player==getattr(g,"starting_player",-1):
            return 0.0

        home=self._corner_position(g,self.player)
        if home is None:
            return 0.0

        edge=g.grid-1
        baseline=self._starting_visible_baseline(g)
        penalty=0.0

        for enemy in range(g.players):
            if enemy==self.player or not g.alive[enemy]:
                continue
            enemy_home=self._corner_position(g,enemy)
            if enemy_home is None:
                continue

            # Only the two edge-neighbors are immediate opening threats.
            if self._manhattan(home,enemy_home)!=edge:
                continue

            extra=max(0,g.visible_units(enemy)-baseline)
            if extra:
                # One deployed extra unit is a warning; two is a clear
                # mobilization/consolidation signal like the CIA death match.
                penalty += 48.0 + 34.0*extra

        return penalty

    # ================================================================
    # OWN LEADER
    # ================================================================

    def _leader_token(self,g):
        for t in g.tokens:
            if t.owner==self.player and t.has_leader():
                return t
        return None

    def _leader_is_concealed(self,token):
        return bool(token is not None and token.vehicle)

    def _update_leader_memory(self,g):
        if self._last_memory_turn==g.turn:
            return
        self._last_memory_turn=g.turn
        leader=self._leader_token(g)
        if leader is None:
            return
        pos=(leader.x,leader.y)
        if pos==self._leader_last_pos:
            self._leader_stationary_turns+=1
        else:
            self._leader_stationary_turns=0
        self._leader_last_pos=pos
        if self._leader_is_concealed(leader):
            self._leader_exposed_turns=0
        else:
            self._leader_exposed_turns+=1

    def _enemy_proximity_penalty(self,g,pos,severe=False):
        dists=[
            self._manhattan(pos,(e.x,e.y))
            for e in g.tokens
            if e.owner!=self.player and g.alive[e.owner]
        ]
        if not dists: return 0.0
        d=min(dists)
        nearby=sum(1 for x in dists if x<=2)
        if d<=1: penalty=96 if severe else 40
        elif d==2: penalty=50 if severe else 22
        elif d==3: penalty=18 if severe else 8
        else: penalty=0
        if nearby>=2: penalty+=15 if severe else 7
        return penalty

    def _leader_danger_penalty(self,g,token,pos):
        if not token.has_leader(): return 0.0
        penalty=self._enemy_proximity_penalty(g,pos,severe=True)
        if not token.vehicle:
            penalty+=20+min(30,self._leader_exposed_turns*6)
        return penalty

    # ================================================================
    # PROBABILISTIC COMBAT
    # ================================================================

    def _attack_evaluation(self,g,token,target,dest):
        belief=self._belief_for(g,target.owner,dest)
        own=token.strength()
        atk_probs=belief["atk_probs"]

        if token.has_saboteur():
            # Any enemy Vehicle is destroyed by a Saboteur.
            # Occupied is the premium outcome; empty is useful denial but a
            # missed opportunity to steal the Vehicle with another unit.
            p_win=min(
                1.0,
                belief["p_occupied_vehicle"] + belief.get("p_empty_vehicle",0.0)
            )
            p_tie=0.0
            p_loss=1.0-p_win
        else:
            p_win=sum(prob for atk,prob in atk_probs.items() if atk<own)
            p_tie=atk_probs.get(own,0.0)
            p_loss=sum(prob for atk,prob in atk_probs.items() if atk>own)

        p_leader_kill=0.0
        for name,prob,atk,has_leader in belief["states"]:
            if not has_leader:
                continue
            if token.has_saboteur():
                if name.startswith("vehicle_") or name=="vehicle_L":
                    p_leader_kill+=prob
            elif own>atk:
                p_leader_kill+=prob

        threat=self._opponent_threat(g,target.owner)

        # Expected-value attack score. All factions use the same probabilities;
        # personality only changes how much uncertainty/risk they accept.
        risk=self._pw("risk_tolerance")
        safety=self._pw("leader_safety")
        leader_reward=self._pw("leader_kill_reward")

        score=-22
        score+=115*p_win
        score-=(78/risk)*p_loss
        score-=(50/risk)*p_tie
        score+=70*leader_reward*p_leader_kill
        score+=0.32*threat

        # Don't gamble the own leader casually. FBI is more conservative;
        # Italian Mafia is a little more willing to accept a high-payoff shot.
        if token.has_leader():
            score-=75*safety*(p_loss+p_tie)
            if token.vehicle:
                score-=18*safety*(1-p_win)

        # Saboteur is valuable but its one-shot payoff can justify a strong read.
        if token.has_saboteur():
            score-=35*(1-p_win)
            score+=60*belief["p_occupied_vehicle"]
            # Destroying an empty Vehicle is still useful, but deliberately
            # worth less than preserving it for capture by a Pawn/Leader.
            score+=14*belief.get("p_empty_vehicle",0.0)

        # A field attack at ATK 3+ necessarily reveals "occupied vehicle" to
        # the defender, because exposed units can only be pawn=1, leader=2,
        # Saboteur=0. This creates a very real counter-Saboteur risk.
        reveal_penalty=0.0
        reveal_p_sab=0.0
        reveal_sources=[]
        if token.vehicle and own>2 and target.owner is not None:
            reveal_p_sab,reveal_sources=self._saboteur_threat_from_player_at(
                g,target.owner,dest
            )
            pawns=sum(
                1 for x in token.people
                if not x.leader and not getattr(x,"saboteur",False)
            )
            cargo_value=28 + 24*pawns + (145 if token.has_leader() else 0)

            # Risk only exists if the vehicle survives and the defender faction
            # survives the attack. Revelation makes that Saboteur much more
            # actionable, hence the modest 1.25 multiplier.
            counter_window=p_win*max(0.0,1.0-p_leader_kill)
            reveal_penalty=counter_window*reveal_p_sab*cargo_value*1.25
            score-=reveal_penalty

        detail={
            "target":[dest[0],dest[1]],
            "target_player":target.owner,
            "own_atk":own,
            "p_win":p_win,
            "p_tie":p_tie,
            "p_loss":p_loss,
            "p_leader_kill":p_leader_kill,
            "belief":belief,
            "vehicle_attack_reveals":bool(token.vehicle and own>2),
            "post_attack_reveal_risk":{
                "p_reachable_defender_saboteur":reveal_p_sab,
                "penalty":reveal_penalty,
                "sources":[
                    {"pos":[pos[0],pos[1]],"weighted_p":q}
                    for pos,q in reveal_sources
                ],
            },
            "score":score,
        }
        return score,detail

    # ================================================================
    # POSITION / BASE SCORING
    # ================================================================

    def _public_enemy_move_budget(self,g,p):
        visible=sum(1 for t in g.tokens if t.owner==p)
        visible=min(visible,g.unit_cap)
        if getattr(g,"base_movement",False):
            return 1 + len(g.controlled_bases(p)) + visible
        return g.base_move + visible

    def _saboteur_threat_at(self,g,dest):
        total_survival=1.0
        sources=[]
        beliefs=self._all_beliefs(g)

        for p,by_pos in beliefs.items():
            if not g.alive[p]:
                continue
            budget=self._public_enemy_move_budget(g,p)
            for pos,b in by_pos.items():
                ps=b.get("p_saboteur",0.0)
                if ps<=0:
                    continue
                dist=self._manhattan(pos,dest)
                if dist<=budget:
                    reach_factor=1.0 if dist<=max(1,budget-1) else 0.72
                    q=max(0.0,min(1.0,ps*reach_factor))
                    total_survival*=1.0-q
                    sources.append((p,pos,q))

        return 1.0-total_survival,sources

    def _saboteur_threat_from_player_at(self,g,enemy,dest):
        """Probability that THIS specific enemy has a Saboteur able to reach
        dest next turn, using only this bot's belief state."""
        if enemy is None or not g.alive[enemy]:
            return 0.0,[]

        by_pos=self._all_beliefs(g).get(enemy,{})
        budget=self._public_enemy_move_budget(g,enemy)
        total_survival=1.0
        sources=[]

        for pos,belief in by_pos.items():
            ps=belief.get("p_saboteur",0.0)
            if ps<=0:
                continue
            dist=self._manhattan(pos,dest)
            if dist<=budget:
                reach_factor=1.0 if dist<=max(1,budget-1) else 0.72
                q=max(0.0,min(1.0,ps*reach_factor))
                total_survival*=1.0-q
                sources.append((pos,q))

        return 1.0-total_survival,sources

    def _vehicle_destination_risk(self,g,token,dest):
        if not token.vehicle or not token.people:
            return 0.0,{}

        p_sab,sources=self._saboteur_threat_at(g,dest)
        pawns=sum(1 for x in token.people
                  if not x.leader and not getattr(x,"saboteur",False))
        has_leader=token.has_leader()

        cargo_value=28 + 24*pawns + (145 if has_leader else 0)
        penalty=p_sab*cargo_value

        return penalty,{
            "saboteur_threat":p_sab,
            "cargo_pawns":pawns,
            "contains_leader":has_leader,
            "penalty":penalty,
            "sources":[
                {"player":p,"pos":[pos[0],pos[1]],"weighted_p":q}
                for p,pos,q in sources
            ],
        }

    def _score_empty_destination(self,g,token,dest):
        score=0.0
        active=self._active_harvests(g)
        if dest in active:
            marks=g.harvest_marks[self.player]
            harvest_w=self._pw("harvest")
            score+=(96+marks*30)*harvest_w
            if marks>=3: score+=58*harvest_w
        else:
            before=self._nearest_objective_distance(g,(token.x,token.y))
            after=self._nearest_objective_distance(g,dest)
            score+=(before-after)*11

        urgent=self._critical_enemy_harvests(g)
        if dest in urgent:
            score+=urgent[dest]*self._pw("harvest_block")

        c=g.grid//2
        score+=(
            max(0,4-self._manhattan(dest,(c,c)))
            *1.2*self._pw("center")
        )

        if token.has_leader():
            # Leader safety is a persistent personality trait, not something
            # used only while evaluating combat. FBI therefore reacts more
            # strongly to exposed destinations; Italian Mafia accepts a little
            # more positional risk.
            score-=(
                self._leader_danger_penalty(g,token,dest)
                * self._pw("leader_safety")
            )
            score-=(
                self._opening_leader_harvest_penalty(g,token,dest)
                * self._pw("leader_safety")
            )
            if not token.vehicle and (token.x,token.y)!=dest:
                score+=min(24,6+self._leader_stationary_turns*5)
        else:
            score-=self._enemy_proximity_penalty(g,dest,False)*0.20

        if token.vehicle and token.people:
            risk,_meta=self._vehicle_destination_risk(g,token,dest)
            score-=risk

        # When losing the sole base means elimination, nearby field units are
        # pulled toward it in proportion to the estimated threat.
        urgency,bs=self._base_survival_priority(g)
        if urgency>0 and bs["base"] is not None:
            before=self._manhattan((token.x,token.y),bs["base"])
            after=self._manhattan(dest,bs["base"])
            if after<before:
                score+=(before-after)*(16+34*urgency)*self._pw("base_control")
            elif after>before and bs["danger"]>0.20:
                score-=(after-before)*(10+32*urgency)*self._pw("base_control")

        return score

    def _post_capture_approach(self,g,token,dest):
        """Publicly calculable square where an assault survivor will end.

        The real resolver leaves the attacker on the last traversable square
        before the base. Using the normal public pathfinder here mirrors that
        geometry without looking at hidden enemy information.
        """
        path=g.find_path((token.x,token.y),dest,self.player)
        if not path:
            return (token.x,token.y)
        return path[-2] if len(path)>=2 else (token.x,token.y)

    def _post_capture_leader_threat(self,g,token,dest):
        """Forecast danger AFTER a successful base capture.

        Capturing a base unloads every non-leader occupant into the base.
        Therefore a leader assault ends with:
          - naked leader outside, or
          - leader-only occupied vehicle outside (strength/DEF 2).

        That temporary split can turn a safe ATK 3/4/5 vehicle into an exposed
        leader before the bot gets another turn. We estimate, from public
        positions + this bot's beliefs, the probability that at least one enemy
        can reach and defeat that resulting leader token.

        No enemy hidden state is read.
        """
        detail={
            "applies":False,
            "approach":None,
            "post_strength":None,
            "p_lethal_counter":0.0,
            "p_saboteur_counter":0.0,
            "penalty":0.0,
            "sources":[],
        }

        if not token.has_leader():
            return 0.0,detail

        approach=self._post_capture_approach(g,token,dest)
        post_vehicle=bool(token.vehicle)

        # All non-leaders enter the captured base; leader remains outside.
        post_strength=2
        total_survival=1.0
        total_sab_survival=1.0
        sources=[]
        beliefs=self._all_beliefs(g)

        for enemy,by_pos in beliefs.items():
            if enemy==self.player or not g.alive[enemy]:
                continue

            budget=self._public_enemy_move_budget(g,enemy)

            for pos,b in by_pos.items():
                # Approximate one-turn reach from public geometry. Manhattan is
                # deliberately a little conservative here: a leader's life is
                # worth checking even when a route may later be obstructed.
                dist=self._manhattan(pos,approach)
                if dist>budget:
                    continue

                reach_factor=1.0 if dist<=max(1,budget-1) else 0.72
                atk_probs=b.get("atk_probs",{})

                if getattr(g,"draw_winner","defender")=="attacker":
                    p_normal=sum(
                        prob for atk,prob in atk_probs.items()
                        if atk>=post_strength
                    )
                else:
                    p_normal=sum(
                        prob for atk,prob in atk_probs.items()
                        if atk>post_strength
                    )

                # A Saboteur is uniquely lethal against the leader-only vehicle.
                p_sab=b.get("p_saboteur",0.0) if post_vehicle else 0.0

                # Avoid double-counting the Saboteur state inside atk_probs:
                # its ATK is zero, so it is not included in p_normal anyway.
                p_lethal=max(0.0,min(1.0,(p_normal+p_sab)*reach_factor))
                p_sab_r=max(0.0,min(1.0,p_sab*reach_factor))

                if p_lethal>0:
                    total_survival*=1.0-p_lethal
                    total_sab_survival*=1.0-p_sab_r
                    sources.append({
                        "player":enemy,
                        "pos":[pos[0],pos[1]],
                        "distance":dist,
                        "move_budget":budget,
                        "p_normal_lethal":p_normal*reach_factor,
                        "p_saboteur_lethal":p_sab_r,
                        "p_lethal":p_lethal,
                    })

        p_lethal=1.0-total_survival
        p_sab=1.0-total_sab_survival

        # Existential risk deserves a large cost, but it is not an absolute
        # prohibition: a near-winning territorial capture can still outweigh it.
        # Personality changes how heavily that danger is treated.
        safety=self._pw("leader_safety")
        penalty=p_lethal*185.0*safety

        # A leader-only vehicle is additionally vulnerable to the special
        # Saboteur one-shot and has just lost the protection of its pawns.
        if post_vehicle:
            penalty+=p_sab*70.0*safety

        detail={
            "applies":True,
            "approach":[approach[0],approach[1]],
            "post_strength":post_strength,
            "post_vehicle":post_vehicle,
            "p_lethal_counter":p_lethal,
            "p_saboteur_counter":p_sab,
            "penalty":penalty,
            "sources":sources,
        }
        return penalty,detail

    def _base_mobility_capture_value(self,g,p_win=1.0):
        if not getattr(g,"base_movement",False):
            return 0.0
        visible=min(g.visible_units(self.player),g.unit_cap)
        value=22.0 + min(12.0,visible*2.0)
        return value*p_win*self._pw("base_control")

    def _base_attack_score(self,g,token,base,dest):
        own=token.strength()
        exposure_penalty,exposure=self._post_capture_leader_threat(
            g,token,dest
        )

        if base.owner is None:
            p_win=1.0 if own>1 else 0.0
            p_tie=1.0 if own==1 else 0.0
            p_loss=0.0 if (p_win or p_tie) else 1.0

            score=(105*p_win-80*p_tie)*self._pw("base_control")
            if dest==(g.grid//2,g.grid//2):
                score+=10*self._pw("center")
            score+=self._base_mobility_capture_value(g,p_win)
            if token.has_leader():
                score-=120*p_tie

            # A second base removes the instant-elimination vulnerability.
            urgency,_bs=self._base_survival_priority(g)
            if urgency>0:
                score+=(55+125*urgency)*p_win*self._pw("base_control")

            # Exposure exists only if the capture actually succeeds.
            score-=exposure_penalty*p_win

            return score,{
                "target":[dest[0],dest[1]],
                "owner":None,
                "own_atk":own,
                "p_win":p_win,
                "p_tie":p_tie,
                "p_loss":p_loss,
                "post_capture_exposure":exposure,
                "score":score,
            }

        enemy=base.owner
        threat=self._opponent_threat(g,enemy)

        # Never read hidden occupants. Use public capture history as soft evidence.
        ev=self._base_evidence.get(tuple(dest),{})
        age=max(0,g.turn-ev.get("captured_turn",g.turn))
        recent_factor=max(0.0,1.0-age/8.0)

        p_def_ge2=0.38
        if ev.get("owner")==enemy:
            p_def_ge2=max(
                p_def_ge2,
                ev.get("likely_def_ge_2",0.0)*recent_factor
            )

        p2=min(0.65,p_def_ge2)
        p3=min(0.22,max(0.0,p_def_ge2-0.35))
        p4=min(0.10,max(0.0,p_def_ge2-0.58))
        p5=min(0.04,max(0.0,p_def_ge2-0.75))
        p1=max(0.0,1.0-(p2+p3+p4+p5))
        dist={1:p1,2:p2,3:p3,4:p4,5:p5}
        z=sum(dist.values()) or 1.0
        dist={k:v/z for k,v in dist.items()}

        p_win=sum(p for d,p in dist.items() if own>d)
        p_tie=dist.get(own,0.0)
        p_loss=sum(p for d,p in dist.items() if own<d)

        risk=self._pw("risk_tolerance")
        score=(105*p_win-(72/risk)*p_loss-(58/risk)*p_tie)
        score*=self._pw("base_control")
        score+=0.38*threat
        score+=self._base_mobility_capture_value(g,p_win)

        own_corners=self._owned_corner_count(g,self.player)
        enemy_corners=self._owned_corner_count(g,enemy)
        if own_corners>=3 and dest!=(g.grid//2,g.grid//2):
            score+=150*self._pw("base_control")
        if enemy_corners>=3 and dest!=(g.grid//2,g.grid//2):
            score+=120*self._pw("base_control")

        if self._last_base_rule(g):
            own_bases=len(g.controlled_bases(self.player))
            enemy_bases=len(g.controlled_bases(enemy))

            # Capturing an enemy's final base is an elimination attack.
            if enemy_bases==1:
                score+=190*p_win*self._pw("base_control")

            # Capturing any second base is also emergency insurance when our
            # own sole base is exposed.
            if own_bases==1:
                urgency,_bs=self._base_survival_priority(g)
                score+=(60+135*urgency)*p_win*self._pw("base_control")

        if token.has_leader():
            score-=180*self._pw("leader_safety")*(p_tie+p_loss)

        # Winning can itself create an existentially bad state when the assault
        # splits pawns into the base and leaves the leader outside.
        score-=exposure_penalty*p_win

        return score,{
            "target":[dest[0],dest[1]],
            "owner":enemy,
            "own_atk":own,
            "p_win":p_win,
            "p_tie":p_tie,
            "p_loss":p_loss,
            "post_capture_exposure":exposure,
            "score":score,
        }

    def _friendly_interaction_score(self,g,token,target):
        if target is None:
            return -999.0

        # Reverse boarding: occupied vehicle drives onto a friendly pawn/leader.
        if token.vehicle and not target.vehicle:
            if not token.people or target.has_saboteur():
                return -999.0
            if len(token.people)+len(target.people)>4:
                return -999.0
            # Same strategic result as the person boarding the vehicle, but may
            # be much cheaper in movement cost.
            bonus=38.0*self._pw("concentration")
            if target.has_leader():
                bonus+=18.0*self._pw("concentration")
            return bonus

        if not target.vehicle:
            return -999.0
        if token.has_saboteur() or token.vehicle:
            return -999.0

        # Leader + empty vehicle has almost no upside in Mini:
        # no secrecy gain, no ATK gain, one fewer visible unit/move source,
        # and new Saboteur vulnerability.
        if token.has_leader():
            if not target.people:
                visible=sum(1 for t in g.tokens if t.owner==self.player)
                cap_pressure=max(0,visible-(g.unit_cap-1))
                return -58.0 + 22.0*cap_pressure
            return 72.0*self._pw("concentration")

        if not target.people:
            return 56.0*self._pw("concentration")
        return 31.0*self._pw("concentration")

    # ================================================================
    # CANDIDATE GENERATION
    # ================================================================

    def _token_candidates(self,g):
        out=[]
        self._candidate_meta={}

        for token in list(g.tokens):
            if token.owner!=self.player:
                continue
            if token.vehicle and not token.people:
                continue

            for dest in g.reachable_empty_tiles(token):
                score=self._score_empty_destination(g,token,dest)
                path=g.find_path((token.x,token.y),dest,self.player)
                cost=len(path) if path is not None else 99
                score-=cost*0.30

                reason=f"POSITION -> {dest}"
                if dest in self._active_harvests(g):
                    reason=f"COMPLETE HARVEST -> {dest}"
                elif dest in self._critical_enemy_harvests(g):
                    reason=f"BLOCK HARVEST -> {dest}"
                elif token.has_leader() and not token.vehicle:
                    reason=f"REPOSITION LEADER -> {dest}"

                out.append((score,"move",token,dest,reason))

            friendly,hostile=g.reachable_interaction_targets(token)

            for dest in hostile:
                target=g.token_at(*dest)
                base=g.bases.get(dest)

                if target is not None:
                    score,detail=self._attack_evaluation(g,token,target,dest)
                    reason=(
                        f"ATTACK {faction_name(target.owner)} -> {dest} "
                        f"[win {detail['p_win']:.0%}, tie {detail['p_tie']:.0%}, "
                        f"leader {detail['belief']['p_leader']:.0%}]"
                    )
                    self._candidate_meta[(id(token),tuple(dest))]=detail
                    out.append((score,"move",token,dest,reason))

                elif base is not None:
                    score,detail=self._base_attack_score(g,token,base,dest)
                    owner="NEUTRAL" if base.owner is None else faction_name(base.owner)
                    self._candidate_meta[(id(token),tuple(dest))]=detail
                    out.append((score,"move",token,dest,f"PRESS {owner} BASE -> {dest}"))

            for dest in friendly:
                target=g.token_at(*dest)
                if target is None:
                    # friendly base transfer
                    score=10
                    reason=f"FRIENDLY BASE -> {dest}"

                    urgency,bs=self._base_survival_priority(g)
                    if urgency>0 and bs["base"]==tuple(dest):
                        score+=(65+155*urgency)*self._pw("base_control")
                        reason=f"DEFEND LAST BASE -> {dest}"
                else:
                    score=self._friendly_interaction_score(g,token,target)
                    if token.vehicle and not target.vehicle:
                        label="LEADER" if target.has_leader() else "PAWN"
                        reason=f"VEHICLE PICKS UP {label} -> {dest}"
                    else:
                        reason=(f"HIDE LEADER IN VEHICLE -> {dest}"
                                if token.has_leader()
                                else f"BOARD VEHICLE -> {dest}")
                out.append((score,"move",token,dest,reason))

        return out

    def _container_candidates(self,g):
        out=[]
        containers=list(g.bases.values())+[t for t in g.tokens if t.vehicle]
        urgent=self._critical_enemy_harvests(g)

        for obj in containers:
            if getattr(obj,"owner",None)!=self.player:
                continue
            people=g.container_people(obj)
            if not people:
                continue

            for idx,person in enumerate(list(people)):
                if hasattr(g,"reachable_container_destinations"):
                    empty,friendly=g.reachable_container_destinations(obj,idx)
                else:
                    empty,friendly=set(),set()

                for dest in empty:
                    score=0.0
                    if dest in self._active_harvests(g):
                        score+=(90+g.harvest_marks[self.player]*28)*self._pw("harvest")
                    else:
                        before=self._nearest_objective_distance(g,(obj.x,obj.y))
                        after=self._nearest_objective_distance(g,dest)
                        score+=(before-after)*10
                    if dest in urgent:
                        score+=urgent[dest]*self._pw("harvest_block")

                    # Field-presence personality. This is deliberately modest:
                    # Italian Mafia is more willing to empty a base when doing so
                    # creates another mobile threat / movement-pool contributor.
                    # FBI is slightly less eager to strip base garrisons.
                    if not getattr(obj,"vehicle",False):
                        visible=sum(1 for t in g.tokens if t.owner==self.player)
                        if visible<g.unit_cap:
                            field_delta=(self._pw("field_presence")-1.0)
                            score+=42.0*field_delta
                            # Strongest when this deployment would leave a thin
                            # or empty base, precisely where personalities differ.
                            remaining=max(0,len(people)-1)
                            if remaining<=1:
                                score+=26.0*field_delta

                    # Avoid stripping useful DEF out of the sole base when
                    # that base is an elimination condition.
                    if (self._last_base_rule(g)
                            and not getattr(obj,"vehicle",False)):
                        owned=list(g.controlled_bases(self.player))
                        if len(owned)==1 and obj is owned[0]:
                            urgency,bs=self._base_survival_priority(g)
                            removed=getattr(person,"strength",0)
                            if removed>0:
                                score-=(38+125*urgency)*removed*self._pw("base_control")
                            elif bs["danger"]>0.25:
                                score-=18*urgency

                    if person.leader:
                        if getattr(obj,"vehicle",False): score-=88
                        score-=self._enemy_proximity_penalty(g,dest,True)

                    label="LEADER" if person.leader else (
                        "SABOTEUR" if getattr(person,"saboteur",False) else "PAWN"
                    )
                    out.append((score,"deploy",obj,(idx,dest),f"DEPLOY {label} -> {dest}"))

                for dest in friendly:
                    target=g.token_at(*dest)
                    if getattr(person,"saboteur",False) and target is not None:
                        continue
                    if target is not None and target.vehicle:
                        if person.leader:
                            if not target.people:
                                visible=sum(1 for t in g.tokens if t.owner==self.player)
                                cap_pressure=max(0,visible-(g.unit_cap-1))
                                score=-58+22*cap_pressure
                                reason=f"LEADER -> EMPTY VEHICLE -> {dest}"
                            else:
                                score=72*self._pw("concentration")
                                reason=f"LEADER JOINS LOADED VEHICLE -> {dest}"
                        else:
                            base_score=56 if not target.people else 31
                            score=base_score*self._pw("concentration")
                            reason=f"LOAD VEHICLE -> {dest}"
                    else:
                        score=14
                        reason=f"TRANSFER -> {dest}"
                    out.append((score,"deploy",obj,(idx,dest),reason))

        return out

    # ================================================================
    # REINFORCEMENT / TURN POLICY
    # ================================================================

    def _should_bank_block(self,g):
        urgent=self._critical_enemy_harvests(g)
        if not urgent or not g.action_taken:
            return None
        for t in g.tokens:
            if t.owner==self.player and (t.x,t.y) in urgent:
                return (t.x,t.y)
        return None

    def _own_pawn_count(self,g):
        total=0
        for b in g.controlled_bases(self.player):
            total+=b.regular_count()
        for t in g.tokens:
            if t.owner==self.player:
                total+=t.regular_count()
        total+=g.reserve[self.player]
        return total

    def _choose_mid_harvest(self,g):
        """Choose +1 now versus committing to the 4-mark reward."""
        p=self.player
        pawns=self._own_pawn_count(g)
        visible=g.visible_units(p)

        # Losing the Saboteur or all vehicles makes the full reward strategically
        # valuable enough that we normally push.
        if g.saboteur_lost[p]:
            choice="push"
            reason="PUSH HARVEST TO 4 — recover Saboteur option"
        else:
            own_vehicles=sum(
                1 for t in g.tokens if t.owner==p and t.vehicle
            ) + g.reserve_vehicles[p]

            if own_vehicles==0:
                choice="push"
                reason="PUSH HARVEST TO 4 — vehicle option needed"
            elif pawns<=2:
                choice="cashout"
                reason="CASH OUT 2 HARVESTS — replenish pawn"
            else:
                # Healthy armies usually accept the risk premium. Personality
                # adds only a little texture rather than creating a new brain.
                push_chance={
                    0:0.66,  # FBI
                    1:0.72,  # Russian Mafia
                    2:0.76,  # Italian Mafia
                    3:0.78,  # CIA
                }.get(p,0.72)

                # If already near the visible cap, an immediate extra pawn is
                # less urgent; the vehicle/Saboteur options at four gain value.
                if visible>=g.unit_cap-1:
                    push_chance=min(0.92,push_chance+0.12)

                choice="push" if self.rng.random()<push_chance else "cashout"
                reason=(
                    "PUSH HARVEST TO 4"
                    if choice=="push"
                    else "CASH OUT 2 HARVESTS"
                )

        g.resolve_mid_harvest_choice(choice)
        self._announce(g,reason,115 if choice=="push" else 105)

        # The harvest was triggered by an attempted end turn. Once the decision
        # is made, actually finish that turn rather than exploiting leftover move.
        if g.end_turn_allowed():
            g.next_turn()

    def _choose_reinforcement(self,g):
        p=self.player

        if (g.saboteur_lost[p]
                and any(len(b.people)<4 for b in g.controlled_bases(p))):
            g.spawn_reinforcement("saboteur")
            self._announce(g,"RECOVER SABOTEUR",140)
            return

        own_vehicles=(
            sum(1 for t in g.tokens if t.owner==p and t.vehicle)
            + g.reserve_vehicles[p]
        )

        progressive=(getattr(g,"harvest_reward_mode","classic")=="progressive")
        full_cycles=(
            g.harvest_full_cycles[p]
            if hasattr(g,"harvest_full_cycles") else 0
        )

        # In the new rule the first +3 pawn reward is intentionally attractive.
        # Later cycles tilt more toward rebuilding/adding vehicles as pawn mass
        # becomes less scarce and the six-visible-unit cap starts to matter.
        if progressive and full_cycles<=1 and self._own_pawn_count(g)<=4:
            choice="pawns"
        else:
            vehicle_chance={
                0:0.58,  # FBI
                1:0.76,  # Russian Mafia
                2:0.56,  # Italian Mafia
                3:0.54,  # CIA
            }.get(p,0.65)

            if progressive and full_cycles>=2:
                vehicle_chance=min(0.90,vehicle_chance+0.14)

            choice=(
                "vehicle"
                if own_vehicles==0 and self.rng.random()<vehicle_chance
                else "pawns"
            )

        g.spawn_reinforcement(choice)
        pawn_n=3 if progressive else 2
        label=(f"+{pawn_n} PAWNS" if choice=="pawns" else "+1 VEHICLE")
        self._announce(g,f"REINFORCE {label}",100)

    # ================================================================
    # LOGGING
    # ================================================================

    def _base_survival_log_snapshot(self,g):
        if not self._last_base_rule(g):
            return {"rule_on":False}
        s=self._sole_base_status(g,self.player)
        return {
            "rule_on":True,
            "sole_base":list(s["base"]) if s["base"] is not None else None,
            "danger":round(s["danger"],5),
            "near_danger":round(s["near_danger"],5),
        }

    def _ledger_snapshot(self,g):
        out={}
        for p in range(g.players):
            if p==self.player:
                continue
            out[str(p+1)]={
                "material_total":dict(self._material[p]),
                "known_losses":dict(self._known_losses[p]),
                "remaining_upper_bound":self._remaining_material(p),
                "visible_unknown_tokens":len([t for t in g.tokens if t.owner==p]),
                "bases":len(g.controlled_bases(p)),
                "corner_bases":self._owned_corner_count(g,p),
                "harvest_marks":g.harvest_marks[p],
                "harvest_committed_to_four":(
                    g.harvest_committed_to_four[p]
                    if hasattr(g,"harvest_committed_to_four") else False
                ),
                "alive":g.alive[p],
            }
        return out

    def _serialize_beliefs(self,g):
        raw=self._all_beliefs(g)
        out={}
        for p,by_pos in raw.items():
            p_out={}
            for pos,b in by_pos.items():
                p_out[f"{pos[0]},{pos[1]}"]={
                    "expected_atk":round(b["expected_atk"],4),
                    "atk_probs":{str(k):round(v,5) for k,v in b["atk_probs"].items()},
                    "leader_probability":round(b["p_leader"],5),
                    "saboteur_probability":round(b["p_saboteur"],5),
                    "vehicle_probability":round(b["p_vehicle"],5),
                    "occupied_vehicle_probability":round(b["p_occupied_vehicle"],5),
                    "empty_vehicle_probability":round(b["p_empty_vehicle"],5),
                    "top_hypotheses":[
                        {"state":name,"p":round(prob,5),"atk":atk}
                        for name,prob,atk,_ in b["states"][:6]
                    ],
                    "stationary_age":self._stationary.get((p,pos),0),
                    "evidence":dict(self._evidence.get((p,pos),{})),
                }
            out[str(p+1)]=p_out
        return out

    def _prepare_candidate_log(self,g,candidates):
        ranked=sorted(candidates,key=lambda x:x[0],reverse=True)[:12]
        rows=[]
        for score,kind,obj,payload,reason in ranked:
            row={
                "score":round(score,3),
                "kind":kind,
                "reason":reason,
            }
            if kind=="move":
                row["from"]=[getattr(obj,"x",None),getattr(obj,"y",None)]
                row["to"]=list(payload)

                if getattr(obj,"vehicle",False) and getattr(obj,"people",None):
                    _penalty,_risk=self._vehicle_destination_risk(g,obj,tuple(payload))
                    row["vehicle_saboteur_risk"]={
                        "p_reachable_saboteur":round(_risk.get("saboteur_threat",0.0),5),
                        "penalty":round(_risk.get("penalty",0.0),3),
                        "contains_leader":bool(_risk.get("contains_leader",False)),
                        "cargo_pawns":int(_risk.get("cargo_pawns",0)),
                    }

                meta=self._candidate_meta.get((id(obj),tuple(payload)))
                if meta:
                    # Field-combat candidates and base-assault candidates share
                    # the same metadata table, but their schemas are different.
                    # Log each defensively instead of assuming combat-only keys.
                    if "belief" in meta and "p_leader_kill" in meta:
                        row["combat_probability"]={
                            "p_win":round(meta.get("p_win",0.0),5),
                            "p_tie":round(meta.get("p_tie",0.0),5),
                            "p_loss":round(meta.get("p_loss",0.0),5),
                            "p_leader_kill":round(meta.get("p_leader_kill",0.0),5),
                            "target_expected_atk":round(
                                meta.get("belief",{}).get("expected_atk",0.0),5
                            ),
                        }
                    elif "post_capture_exposure" in meta:
                        row["base_assault_probability"]={
                            "p_win":round(meta.get("p_win",0.0),5),
                            "p_tie":round(meta.get("p_tie",0.0),5),
                            "p_loss":round(meta.get("p_loss",0.0),5),
                            "own_atk":meta.get("own_atk"),
                            "owner":meta.get("owner"),
                        }

                    if meta.get("vehicle_attack_reveals"):
                        rr=meta.get("post_attack_reveal_risk",{})
                        row["vehicle_revelation_risk"]={
                            "reveals_vehicle":True,
                            "p_reachable_defender_saboteur":round(
                                rr.get("p_reachable_defender_saboteur",0.0),5
                            ),
                            "penalty":round(rr.get("penalty",0.0),3),
                        }

                    if meta.get("post_capture_exposure",{}).get("applies"):
                        pc=meta["post_capture_exposure"]
                        row["post_capture_exposure"]={
                            "approach":pc.get("approach"),
                            "post_strength":pc.get("post_strength"),
                            "post_vehicle":pc.get("post_vehicle",False),
                            "p_lethal_counter":round(
                                pc.get("p_lethal_counter",0.0),5
                            ),
                            "p_saboteur_counter":round(
                                pc.get("p_saboteur_counter",0.0),5
                            ),
                            "penalty":round(pc.get("penalty",0.0),3),
                        }
            rows.append(row)
        self._last_candidate_log=rows

    def _announce(self,g,reason,score):
        self.last_reason=reason
        entry={
            "turn":g.turn,
            "player":self.player,
            "faction":faction_name(self.player),
            "personality":dict(self.personality),
            "reason":reason,
            "score":round(float(score),3),
            "base_survival":self._base_survival_log_snapshot(g),
            "ledger":self._ledger_snapshot(g),
            "beliefs":self._serialize_beliefs(g),
            "top_candidates":self._last_candidate_log,
        }
        if hasattr(g,"ai_log"):
            g.ai_log.append(entry)
        try:
            g.log_event("bot_decision",reason=reason,score=round(score,2),
                        bot_version=BOT_VERSION,
                        bot_faction_id=self.faction_id,
                        bot_faction_name=self.personality.get("name","UNKNOWN"))
        except Exception:
            pass
        print(
            f"[BasicBot {BOT_VERSION} P{self.player+1} "
            f"{self.personality.get('name','UNKNOWN')}] {reason} | {score:.1f}"
        )

    # ================================================================
    # STEP
    # ================================================================

    def step(self,g):
        if g.current!=self.player or g.winner is not None or g.draw:
            self.end_after_combat=False
            return "idle"

        self._process_new_events(g)
        self._update_leader_memory(g)
        self._last_candidate_log=[]

        if self.end_after_combat:
            self.end_after_combat=False
            if g.end_turn_allowed():
                self._announce(g,"END TURN AFTER COMBAT",0)
                g.next_turn()
            return "end"

        if (
            getattr(g,"harvest_reward_mode","classic")=="progressive"
            and getattr(g,"harvest_mid_offer",[False]*g.players)[self.player]
        ):
            self._choose_mid_harvest(g)
            return "harvest_decision"

        if g.reinforcement_credits[self.player]>0 and g.controlled_bases(self.player):
            self._choose_reinforcement(g)
            return "reinforcement"

        for t in g.tokens:
            if (t.owner==self.player
                    and (t.x,t.y) in self._active_harvests(g)
                    and g.action_taken):
                self._announce(g,f"BANK HARVEST {(t.x,t.y)}",130)
                g.next_turn()
                return "end"

        block=self._should_bank_block(g)
        if block is not None:
            self._announce(g,f"HOLD HARVEST BLOCK {block}",115)
            g.next_turn()
            return "end"

        if g.move_left<=0:
            if g.action_taken:
                self._announce(g,"END TURN",0)
                g.next_turn()
                return "end"
            return "idle"

        candidates=self._token_candidates(g)+self._container_candidates(g)
        self._prepare_candidate_log(g,candidates)

        if not candidates:
            if g.action_taken:
                self._announce(g,"END TURN — no useful action",0)
                g.next_turn()
                return "end"
            # minimal legal fallback
            for token in g.tokens:
                if token.owner!=self.player:
                    continue
                spots=list(g.reachable_empty_tiles(token))
                if spots:
                    dest=self.rng.choice(spots)
                    self._announce(g,f"FALLBACK MOVE -> {dest}",0)
                    g.try_move_or_interact(token,*dest)
                    return "action"
            return "idle"

        scored=[]
        for item in candidates:
            # Very small noise: probabilities/strategy should dominate.
            scored.append((item[0]+self.rng.uniform(-1.5,1.5),item))
        scored.sort(key=lambda x:x[0],reverse=True)
        score,item=scored[0]
        _,kind,obj,payload,reason=item

        if g.action_taken and score<7:
            self._announce(g,"END TURN — preserve position",score)
            g.next_turn()
            return "end"

        before_log=len(g.log)
        if kind=="move":
            g.try_move_or_interact(obj,*payload)
        else:
            idx,dest=payload
            g.deploy_selected_person(obj,idx,*dest)

        self._announce(g,reason,score)

        new_events=g.log[before_log:]
        if any(e.get("kind") in ("combat","combat_result","saboteur_strike")
               for e in new_events) and g.winner is None and not g.draw:
            self.end_after_combat=True
            return "combat"

        return "action"
